// Marie
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/com/IShellLink.c"


#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/bmp/ui/progressbar.c"
#include "../nonnon/neutral/png.c"
#include "../nonnon/neutral/jpg.c"
#include "../nonnon/win32/wic.c"

#include "../nonnon/neutral/ini.c"

#include "../nonnon/win32/ole/IDropTarget.c"
#include "../nonnon/win32/ole/IPicture.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_systray.c"

#include "../nonnon/win32/gdi.c"

#include "../nonnon/game/sound/vfw.c"


#include "../nonnon/project/macro.c"
#include "../nonnon/project/ini2gdi.c"




// [!] : Independent Components

#include "./_iconparade.c"
#include "./_jukebox.c"
#include "./_vfw_ui.c"




// [!] : Shared

#define N_MARIE_APPNAME                          "Marie"
#define N_MARIE_APPNAME_LITERAL n_posix_literal( "Marie" )


#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_MARIE ( 0 )

#endif // #ifndef NONNON_APPS


#define N_MARIE_PROGRESS_INTERVAL ( 50 )


static COLORREF         n_marie_color_corner;
static HWND             n_marie_hpopup        = NULL;
static n_win_scrollbar  n_marie_hscr;
static n_win_scrollbar  n_marie_vscr;
static n_vfw            n_marie_vfw;
static n_vfw_ui         n_marie_vfw_ui;
static n_jukebox        n_marie_jukebox;
static n_bool           n_marie_jukebox_onoff = n_false;
static int              n_marie_degree        = 0;
static n_bool           n_marie_nofile_onoff  = n_false;
static n_bool           n_marie_fit_onoff     = n_false;

static n_bmp           *n_marie_bmp_main;
static n_bmp            n_marie_bmp[ 2 ];
static n_win            n_marie_n_win;
static POINT            n_marie_point;
static n_type_gfx       n_marie_minsx;
static n_type_gfx       n_marie_minsy;
static n_bool           n_marie_iconparade_onoff;
static n_bool           n_marie_iconparade_resource;

static n_posix_char    *n_marie_exepath = NULL;

static UINT             n_marie_timer_id_vfw  = 0;
static UINT             n_marie_timer_id_tray = 0;

static u32              n_marie_color_bg      = n_bmp_white_invisible;




// [!] : Components

#include "./marie_grab_n_drag.c"
#include "./marie_popup.c"
#include "./marie_systray.c"




void
n_marie_killtimer( HWND hwnd )
{

	n_win_timer_exit( hwnd, n_marie_timer_id_vfw );

	return;
}

void
n_marie_settimer( HWND hwnd )
{

	n_bmp_ui_progressbar_animation          = N_BMP_UI_PROGRESSBAR_ANIMATION_ON_UP;
	n_bmp_ui_progressbar_animation_interval = N_MARIE_PROGRESS_INTERVAL;

	n_marie_killtimer( hwnd );

	if ( n_marie_timer_id_vfw == 0 ) { n_marie_timer_id_vfw = n_win_timer_id_get(); }
	n_win_timer_init( hwnd, n_marie_timer_id_vfw, n_bmp_ui_progressbar_animation_interval );

	return;
}

n_type_gfx
n_marie_minsize( HWND hwnd )
{

	n_type_gfx borders = GetSystemMetrics( SM_CXFIXEDFRAME ) * 2;
	n_type_gfx smlicon = GetSystemMetrics( SM_CXSMICON     ) * 1;
	n_type_gfx buttons = 0;
	n_type_gfx caption = 0;

	if ( n_false )//( n_sysinfo_version_vista_or_later() )
	{

		// [x] : .rgrect[] have zero always

		const UINT n_WM_GETTITLEBARINFOEX = 0x033F;

		typedef struct
		{
			DWORD cbSize;
			RECT  rcTitleBar;
			DWORD rgstate[ CCHILDREN_TITLEBAR + 1 ];
			RECT  rgrect [ CCHILDREN_TITLEBAR + 1 ];
		} n_TITLEBARINFOEX;

		int              cb = sizeof( n_TITLEBARINFOEX );
		n_TITLEBARINFOEX tbi; ZeroMemory( &tbi, cb );
		tbi.cbSize = cb;
		n_win_message_send( hwnd, n_WM_GETTITLEBARINFOEX, 0, &tbi );

		RECT r_min = tbi.rgrect[ 2 ];
		RECT r_max = tbi.rgrect[ 3 ];
		RECT r_cls = tbi.rgrect[ 5 ];

		buttons = ( r_min.right - r_min.left ) + ( r_max.right - r_max.left ) + ( r_cls.right - r_cls.left );
		caption = ( tbi.rcTitleBar.right - tbi.rcTitleBar.left ) - buttons;

	} else {

		// [x] : Win95 : GetTitleBarInfo() is not exist

		int          cb = sizeof( TITLEBARINFO );
		TITLEBARINFO tbi; ZeroMemory( &tbi, cb );
		tbi.cbSize = cb;

		HMODULE hmod = LoadLibrary( n_posix_literal( "User32.dll" ) );
		FARPROC func = GetProcAddress( hmod, "GetTitleBarInfo" );
		if ( func != NULL )
		{
			func( hwnd, &tbi );
		} else {
			tbi.rcTitleBar.right = 120;
		}
		FreeLibrary( hmod );
//n_posix_debug_literal( " %d ", tbi.rcTitleBar.right );

		buttons = GetSystemMetrics( SM_CXSIZE ) * 3;
		caption = ( tbi.rcTitleBar.right - tbi.rcTitleBar.left ) - buttons;

	}


	HDC hdc = GetDC( hwnd );


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, hwnd, L"CompositedWindow::Window" );


	HFONT hfont = n_uxtheme_hfont( &uxtheme, TMT_CAPTIONFONT );
	HFONT hfprv = SelectObject( hdc, hfont );

	SIZE size;
	GetTextExtentPoint32( hdc, N_MARIE_APPNAME_LITERAL, (int) n_posix_strlen( N_MARIE_APPNAME_LITERAL ), &size );

	caption = n_posix_max( caption, size.cx );

	SelectObject( hdc, hfprv );
	n_win_font_exit( hfont );


	n_uxtheme_exit( &uxtheme, hwnd );


	ReleaseDC( hwnd, hdc );


	return ( borders + smlicon + caption + buttons ); 
}

void
n_marie_client_refresh( HWND hwnd, n_bmp *bmp )
{

	// [Needed] : zero at the first time
/*
static int i = 0;
if( i == 0 )
{
	n_win_hwndprintf_literal( hwnd, " %d %d ", n_marie_n_win.rcsy, n_marie_n_win.csy );
}
i++;
*/
	if ( n_marie_n_win.rcsx == 0 ) { return; }
	if ( n_marie_n_win.rcsy == 0 ) { return; }
	if ( n_marie_n_win. csx == 0 ) { return; }
	if ( n_marie_n_win. csy == 0 ) { return; }


	if ( n_vfw_is_active( &n_marie_vfw ) )
	{

		n_vfw_refresh( &n_marie_vfw );

		n_vfw_ui_draw( &n_marie_vfw, &n_marie_vfw_ui, bmp );

		n_gdi_bitmap_draw
		(
			hwnd,
			bmp,
			0,0,
			n_marie_vfw_ui.band_sx, n_marie_vfw_ui.band_sy,
			n_marie_vfw_ui.band_x,  n_marie_vfw_ui.band_y
		);

	} else {

		// [Needed] : black screen at exit

		if ( n_bmp_error( bmp ) ) { return; }


		const n_type_gfx bmpsx = N_BMP_SX( bmp );
		const n_type_gfx bmpsy = N_BMP_SY( bmp );


		n_bool is_resized = n_false;
		n_bmp  b;

		if ( ( bmpsx < n_marie_minsx )&&( bmpsy < n_marie_minsy ) )
		{

			is_resized = n_true;

			n_bmp_carboncopy( bmp, &b );
			n_bmp_resizer( &b, n_marie_n_win.rcsx,n_marie_n_win.rcsy, n_bmp_black, N_BMP_RESIZER_CENTER );
			bmp = &b;

		} else
		if ( bmpsx < n_marie_minsx )
		{

			is_resized = n_true;

			u32 bg = n_bmp_black;
			if ( n_marie_iconparade_onoff ) { bg = n_marie_color_bg; }

			n_bmp_carboncopy( bmp, &b );
			n_bmp_resizer( &b, n_marie_n_win.rcsx,n_marie_n_win.rcsy, bg, N_BMP_RESIZER_CENTER );
			bmp = &b;

		}


		{

			n_type_gfx x = 0;

			if ( n_marie_vscr.show_onoff )
			{
				if ( n_win_is_lefthanded() ) { x = n_win_scrollbar_stdsize( &n_marie_vscr ); }
			}

			n_gdi_bitmap_draw
			(
				hwnd, bmp,
				//0,0,bmpsx,bmpsy, -n_marie_n_win.scrollx, -n_marie_n_win.scrolly
				n_marie_n_win.scrollx,n_marie_n_win.scrolly,n_marie_n_win.csx,n_marie_n_win.csy,
				x,0
			);

		}


		if ( is_resized ) { n_bmp_free( &b ); }


		n_win_scrollbar_client( &n_marie_hscr, &n_marie_vscr, &n_marie_n_win, n_marie_color_corner );

	}


	return;
}

void
n_marie_window_refresh( HWND hwnd, n_bmp *bmp, int nwin )
{

	n_type_gfx sx,sy;


	if ( n_vfw_is_active( &n_marie_vfw ) )
	{

		sx = n_marie_vfw_ui.band_sx;
		sy = n_marie_vfw_ui.band_sy + n_marie_vfw.csy;

	} else {

		nwin |= N_WIN_SET_CLIPPING | N_WIN_SET_SCROLLBAR;

		sx = N_BMP_SX( bmp );
		sy = N_BMP_SY( bmp );

		if (
			( sx < n_marie_minsx )
			&&
			( sy < n_marie_minsy )
		)
		{
			sx = n_marie_minsx;
			sy = n_marie_minsy;
		} else
		if ( sx < n_marie_minsx )
		{
			sx = n_marie_minsx;
		}

	}


	if ( nwin & N_WIN_SET_NEEDPOS )
	{

		const n_type_gfx BARY = GetSystemMetrics( SM_CYCAPTION    );
		const n_type_gfx FRMX = GetSystemMetrics( SM_CXFIXEDFRAME );
		const n_type_gfx FRMY = GetSystemMetrics( SM_CYFIXEDFRAME );
		const n_type_gfx NCX  =   ( FRMX * 2 );
		const n_type_gfx NCY  = ( ( FRMY * 2 ) + BARY );


		// [!] : remove centering

		nwin &= ~N_WIN_SET_CENTERING;


		n_marie_n_win.posx = n_marie_point.x - ( ( sx + NCX ) / 2 );
		n_marie_n_win.posy = n_marie_point.y - ( ( sy + NCY ) / 2 );

	}


	n_win_set( hwnd, &n_marie_n_win, sx,sy, nwin | N_WIN_SET_CALCONLY );

	if ( n_marie_n_win.posy < 0 )
	{
		nwin |= N_WIN_SET_NEEDPOS;
		n_marie_n_win.posy = 0;
	}

	n_win_set( hwnd, &n_marie_n_win, sx,sy, nwin );


	n_marie_client_refresh( hwnd, bmp );


	return;
}

// internal
void
n_marie_nofile( HWND hwnd, n_bmp *bmp )
{

	// [Needed] : anti-crash : for gdi.icon

	n_win_exedir2curdir();


	n_type_gfx ctl,m;
	n_win_stdsize( hwnd, &ctl, NULL, &m );
	ctl -= ( m * 2 );


	n_posix_char *exe = n_win_exepath_new();


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sy                 = n_marie_minsy;
	gdi.sx                 = (n_type_gfx) ( (n_type_real) gdi.sy * sqrt( 2 ) );
	gdi.style              = N_GDI_CLARITY | N_GDI_SINK | N_GDI_SMOOTH;

	gdi.base_color_fg      = n_win_dwm_windowcolor_arranged();
	gdi.base_color_bg      = n_bmp_blend_pixel( gdi.base_color_fg, n_bmp_black, 0.5 );
	gdi.base_style         = N_GDI_BASE_VERTICAL;

	if ( gdi.base_color_fg == n_bmp_black ) { gdi.base_color_fg = n_bmp_rgb( 10,10,10 ); }
	if ( gdi.base_color_bg == n_bmp_black ) { gdi.base_color_bg = n_bmp_rgb( 10,10,10 ); }

	gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	gdi.icon               = exe;
	gdi.icon_index         = N_APPS_ICON_OFFSET_MARIE;
	gdi.icon_color_sink_tl = n_bmp_rgb(   0, 10, 10 );
	gdi.icon_color_sink_br = n_bmp_rgb( 255,255,255 );
	gdi.icon_style         = N_GDI_ICON_RESOURCE;
	gdi.icon_fxsize2       = 1;

	gdi.text               = n_project_string_drophere;
	gdi.text_font          = n_project_stdfont();
	gdi.text_size          = ctl;
	gdi.text_color_main    = n_bmp_rgb( 255,255,255 );
	gdi.text_color_sink_tl = n_bmp_rgb(   0, 10, 10 );
	gdi.text_color_sink_br = n_bmp_rgb( 255,255,255 );
	gdi.text_style         = N_GDI_TEXT_BOLD;
	gdi.text_fxsize2       = 1;


	if ( n_project_dwm_is_on() )
	{
		gdi.base_color_bg = n_bmp_black_invisible;
		gdi.base_color_fg = n_bmp_black_invisible;
		gdi.base_style    = N_GDI_BASE_SOLID;
		//gdi.frame_style   = N_GDI_FRAME_SIMPLE;
	}


	n_bool p_is_ui = n_win_icon_init_is_ui;
	n_win_icon_init_is_ui = n_false;

	n_gdi_bmp( &gdi, bmp );

	n_win_icon_init_is_ui = p_is_ui;


	n_string_path_free( exe );


	return;
}

// internal
void
n_marie_resampler_condition( HWND hwnd, n_bmp *bmp )
{

	n_type_gfx desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );


	desktop_sx -= GetSystemMetrics( SM_CXFIXEDFRAME ) * 2;
	desktop_sy -= GetSystemMetrics( SM_CYFIXEDFRAME ) * 2;

	desktop_sy -= GetSystemMetrics( SM_CYCAPTION );

	if (
		( desktop_sx < N_BMP_SX( bmp ) )
		||
		( desktop_sy < N_BMP_SY( bmp ) )
	)
	{
		n_marie_fit_onoff = n_posix_true;
	}


	return;
}

// internal
void
n_marie_resampler( HWND hwnd, n_bmp *bmp )
{

	n_type_gfx desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );


	desktop_sx -= GetSystemMetrics( SM_CXFIXEDFRAME ) * 2;
	desktop_sy -= GetSystemMetrics( SM_CYFIXEDFRAME ) * 2;

	desktop_sy -= GetSystemMetrics( SM_CYCAPTION );


//u32 dw = n_posix_tickcount();

	if ( n_marie_fit_onoff )
	{

		n_type_real ratio_x = (n_type_real) desktop_sx / N_BMP_SX( bmp );
		n_type_real ratio_y = (n_type_real) desktop_sy / N_BMP_SY( bmp );

		n_type_real ratio = n_posix_min_n_type_real( ratio_x, ratio_y );

		n_bmp_resampler( bmp, ratio, ratio );
//n_bmp_resizer( bmp, maxclientsize.csx, maxclientsize.csy, n_bmp_white, 0 );

//n_win_hwndprintf_literal( hwnd, "%d", (int) n_posix_tickcount() - dw );
	}


	return;
}

//internal
n_bool
n_marie_iconparade_load_main( n_bmp *bmp, n_posix_char *fname )
{

	n_bool ret = n_marie_iconparade_load( bmp, fname, n_marie_iconparade_resource );

	if ( ret == n_false ) { n_marie_iconparade_onoff = n_true; }

	return ret;
}

//internal
n_bool
n_marie_picture_load( n_posix_char *fname )
{

	// [Patch] : Win9x
	//
	//	order : iconparade => ini2gdi
	//	because embedded INI text resource in EXE is loadable

	n_bool ret = n_false;

	if (
		( n_bmp_load( n_marie_bmp_main, fname ) )
		&&
		( n_png_png2bmp( fname, n_marie_bmp_main ) )
		&&
		( n_jpg_jpg2bmp( fname, n_marie_bmp_main ) )
		&&
		( n_wic_load( fname, n_marie_bmp_main ) )
		&&
		( n_IPicture_load( fname, n_marie_bmp_main ) )
		&&
		( n_marie_iconparade_load_main( n_marie_bmp_main, fname ) )
		&&
		( n_ini2gdi_load( fname, n_marie_bmp_main ) )
	)
	{

		// [!] : all failed

		ret = n_true;

	} else {

		// [!] : succeeded

		n_marie_jukebox_onoff = n_false;

		n_jukebox_free( &n_marie_jukebox );


		// [!] : alpha support

		n_bmp bg; n_bmp_zero( &bg );
		n_bmp_new_fast( &bg, N_BMP_SX( n_marie_bmp_main ), N_BMP_SY( n_marie_bmp_main ) );
		n_bmp_flush( &bg, n_marie_color_bg );

		u32 p_trans_f = n_bmp_transparent_onoff( n_marie_bmp_main, n_false );
		u32 p_trans_t = n_bmp_transparent_onoff(              &bg, n_false );

		n_bmp_flush_transcopy( n_marie_bmp_main, &bg );

		n_bmp_transparent_onoff( n_marie_bmp_main, p_trans_f );
		n_bmp_transparent_onoff( n_marie_bmp_main, p_trans_t );

		n_bmp_free_fast( n_marie_bmp_main );
		n_bmp_alias( &bg, n_marie_bmp_main );

	}


	return ret;
}

//internal
n_bool
n_marie_vfw_load( HWND hwnd, const n_posix_char *fname, n_bool is_dropped )
{

	n_posix_char *newname = n_string_path_carboncopy( fname );


	n_bool ret = n_false;
	n_posix_loop
	{

		// [!] : skip invalid files

		if ( n_false == n_vfw_load( &n_marie_vfw, hwnd, newname ) )
		{
			// [!] : succeeded
			n_string_path_free( newname );
			break;
		}

		if ( n_marie_jukebox_onoff == n_false )
		{

			n_string_path_free( newname );

			ret                   =  n_true;
			n_marie_jukebox_onoff = n_false;

			n_jukebox_free( &n_marie_jukebox );

			break;

		} else {

			if ( is_dropped ) { ret = n_true; break; }

			n_string_path_free( newname );
			newname = n_jukebox_next_new( &n_marie_jukebox );

			if ( n_string_is_empty( newname ) )
			{
				n_string_path_free( newname );
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
				break;
			}

		} 

	}


	return ret;
}

// internal
n_bool
n_marie_jukebox_load( HWND hwnd, n_posix_char *fname )
{

	if ( n_jukebox_load( &n_marie_jukebox, fname ) )
	{
		n_marie_jukebox_onoff = n_false;
		n_jukebox_free( &n_marie_jukebox );
	} else {
		n_marie_jukebox_onoff = n_true;
		n_marie_vfw_load( hwnd, fname, n_false );
	}


	return ( n_marie_jukebox_onoff == n_false );
}

// internal
void
n_marie_effect( HWND hwnd, int nwin )
{

	n_bmp_free_fast( &n_marie_bmp[ 1 ] );
	n_bmp_carboncopy( &n_marie_bmp[ 0 ], &n_marie_bmp[ 1 ] );

	n_marie_bmp_main = &n_marie_bmp[ 1 ];


	if ( n_marie_degree )
	{
		n_bmp_matrix_rotate( n_marie_bmp_main, n_marie_degree, n_marie_color_bg, n_true );
	}


	n_marie_resampler( hwnd, n_marie_bmp_main );


	if ( ( n_project_dwm_is_on() )&&( n_marie_nofile_onoff ) )
	{
		n_bmp_flush_replacer( n_marie_bmp_main, n_marie_color_bg, n_bmp_black_invisible );
	}


	n_marie_window_refresh( hwnd, n_marie_bmp_main, nwin );


	n_marie_n_win.scrollx = n_marie_n_win.scrolly = 0;

	n_win_scrollbar_reset( &n_marie_hscr );
	n_win_scrollbar_reset( &n_marie_vscr );

	n_win_scrollbar_window( &n_marie_hscr, &n_marie_vscr, &n_marie_n_win, n_marie_color_corner );

	n_win_scrollbar_refresh( &n_marie_hscr );
	n_win_scrollbar_refresh( &n_marie_vscr );


	return;
}

// internal
void
n_marie_newfile( HWND hwnd, const n_posix_char *fname, n_bool is_dropped, n_bool effect_onoff )
{

	n_vfw_free( &n_marie_vfw );


	n_posix_char *cmdline_new;

	if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, fname ) )
	{
		cmdline_new = n_string_path_new( N_ISHELLLINK_LNK2PATH_CCH_PATH );
		n_IShellLink_lnk2path( fname, cmdline_new, NULL, NULL, NULL );
	} else {
		cmdline_new = n_string_path_carboncopy( fname );
	}


	// [!] : reserve original name for rotation

	n_posix_char *newname = n_string_path_new( n_posix_strlen( cmdline_new ) + 100 );
	n_string_copy( cmdline_new, newname );

	n_string_path_free( cmdline_new );


	n_marie_iconparade_onoff = n_false;


	n_bmp_free( &n_marie_bmp[ 0 ] );
	n_bmp_free( &n_marie_bmp[ 1 ] );
	n_marie_bmp_main = &n_marie_bmp[ 0 ];

	if (
//(0)&&
		( n_marie_picture_load( newname ) )
		&&
		( n_marie_vfw_load( hwnd, newname, is_dropped ) )
		&&
		( n_marie_jukebox_load( hwnd, newname ) )
	)
	{
		n_marie_nofile( hwnd, n_marie_bmp_main );
		n_marie_nofile_onoff =  n_true;
	} else {
		n_marie_nofile_onoff = n_false;
	}

//n_posix_debug( newname );
	n_string_path_free( newname );


	n_marie_resampler_condition( hwnd, n_marie_bmp_main );


	n_marie_degree = 0;


	if ( n_vfw_is_active( &n_marie_vfw ) )
	{

		n_vfw_ui_reset( &n_marie_vfw, &n_marie_vfw_ui, n_marie_bmp_main );


		n_marie_settimer( hwnd );

		// [!] : n_vfw_play() is suspended here

		//n_vfw_play( &n_marie_vfw )

	} else {

		if ( n_project_dwm_is_on() )
		{
			n_win_dwm_transparent_on( hwnd );
		}

	}


	if ( effect_onoff ) { n_marie_effect( hwnd, N_WIN_SET_CENTERING ); }

	n_marie_window_refresh( hwnd, n_marie_bmp_main, N_WIN_SET_CALCONLY );


	n_marie_n_win.scrollx = n_marie_n_win.scrolly = 0;

	n_win_scrollbar_reset( &n_marie_hscr );
	n_win_scrollbar_reset( &n_marie_vscr );


	n_win_scrollbar_window( &n_marie_hscr, &n_marie_vscr, &n_marie_n_win, n_marie_color_corner );


	return;
}

// internal
void
n_marie_save( const n_bmp *bmp )
{

	n_posix_char *dirname = n_string_path_folder_current_new();
	n_posix_char *tmpname = n_string_path_tmpname_new( n_posix_literal( ".png\0\0" ) );
	n_posix_char *newname = n_string_path_make_new( dirname, tmpname );

//n_posix_debug_literal( "%s", newname ); return;


	n_bmp b; n_bmp_carboncopy( bmp, &b );

	{

		n_png png = n_png_template;

		n_png_compress( &png, &b );
		n_png_save( &png, newname );

		n_png_free( &png );

	}

	n_bmp_free( &b );


	n_string_path_free( dirname );
	n_string_path_free( tmpname );
	n_string_path_free( newname );


	return;
}

void
n_marie_on_timer( HWND hwnd )
{

	if ( n_marie_jukebox_onoff )
	{

		n_posix_char *nextname = n_jukebox_next_new( &n_marie_jukebox );

		if ( n_string_is_empty( nextname ) )
		{
			n_string_path_free( nextname );
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else {
			n_marie_newfile( hwnd, nextname, n_false, n_false );
			n_string_path_free( nextname );
			n_vfw_play( &n_marie_vfw );
		}

	} else
	if ( n_vfw_is_active( &n_marie_vfw ) )
	{

		//

	}


	return;
}

void
n_marie_mousegesture( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static POINT pt_prv = { -1,-1 };


	switch( msg ) {


	case WM_RBUTTONDOWN :

		if ( n_vfw_is_active( &n_marie_vfw ) ) { break; }

		if ( n_marie_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd ) ) { break; }
		if ( n_marie_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd ) ) { break; }


		SetCapture( hwnd );

		GetCursorPos( &pt_prv );

	break;


	case WM_RBUTTONUP :
	{

		if ( n_vfw_is_active( &n_marie_vfw ) ) { break; }

		if ( n_marie_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd ) ) { break; }
		if ( n_marie_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd ) ) { break; }


		ReleaseCapture();


		// [!] : only WM_LBUTTONUP will be sent when popup is ON

		if ( ( pt_prv.x == -1 )&&( pt_prv.y == -1 ) ) { break; }


		POINT pt_cur;
		GetCursorPos( &pt_cur );
//n_win_hwndprintf_literal( hwnd, "%d %d %d %d", pt_prv.x, pt_prv.y, pt_cur.x, pt_cur.y );


		n_type_gfx threshold_sx = 0;
		n_type_gfx threshold_sy = 0;
		n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

		threshold_sx *= 10;
		threshold_sy *= 10;
//n_win_hwndprintf_literal( hwnd, " %d %d ", threshold_sx, threshold_sy );


		n_type_gfx delta_x = abs( pt_prv.x - pt_cur.x );
		n_type_gfx delta_y = abs( pt_prv.y - pt_cur.y );


		int mirror = N_BMP_MIRROR_NONE;

		if ( delta_x >= threshold_sx )
		{
			mirror = N_BMP_MIRROR_LEFTSIDE_RIGHT;
		}

		if ( delta_y >= threshold_sy )
		{
			mirror = N_BMP_MIRROR_UPSIDE_DOWN;
		}


		if ( mirror != N_BMP_MIRROR_NONE )
		{

			n_bmp_flush_mirror( n_marie_bmp_main, mirror );

			n_marie_client_refresh( hwnd, n_marie_bmp_main );

		} else {

			n_win_gui( hwnd, WINDOW, n_marie_popup_wndproc, &n_marie_hpopup );

		}

		pt_prv.x = pt_prv.y = -1;

	}
	break;


	} // switch


	return;
}

LRESULT CALLBACK
n_marie_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		n_project_darkmode();

		n_marie_color_corner = n_win_darkmode_systemcolor( COLOR_BTNFACE );

		if ( n_vfw_is_active( &n_marie_vfw ) )
		{
			n_vfw_ui_reset( &n_marie_vfw, &n_marie_vfw_ui, n_marie_bmp_main );
		} else {
			n_marie_client_refresh( hwnd, n_marie_bmp_main );

			n_win_scrollbar_on_settingchange( &n_marie_hscr, n_true, n_true );
			n_win_scrollbar_on_settingchange( &n_marie_vscr, n_true, n_true );
		}

	break;


	case WM_CREATE :


		// Commane Line Option

		{

			n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_MARIE, cmdline );

#endif // #ifdef NONNON_APPS

			if ( n_string_commandline_option_literal( "-playlist:inner", cmdline ) )
			{
				n_jukebox_m3u_shuffle_save( cmdline,  n_true );
				n_string_path_free( cmdline );
				return -1;
			} else
			if ( n_string_commandline_option_literal( "-playlist",       cmdline ) )
			{
				n_jukebox_m3u_shuffle_save( cmdline, n_false );
				n_string_path_free( cmdline );
				return -1;
			}// else

			n_string_path_free( cmdline );

		}


		// Global

		n_bmp_safemode = n_false;

		n_win_icon_init_callback = n_project_system_icon_color;

		n_jukebox_zero( &n_marie_jukebox );
		n_vfw_zero( &n_marie_vfw );
		n_vfw_ui_zero( &n_marie_vfw_ui );


		n_bmp_zero( &n_marie_bmp[ 0 ] );
		n_bmp_zero( &n_marie_bmp[ 1 ] );

		n_marie_bmp_main = &n_marie_bmp[ 0 ];


		n_win_scrollbar_zero( &n_marie_hscr );
		n_win_scrollbar_zero( &n_marie_vscr );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_project_darkmode();

		n_win_ime_disable( hwnd );

		n_marie_timer_id_tray = N_PROJECT_SYSTRAY_ID_MARIE;


		n_marie_exepath = n_win_exepath_new();


		//n_win_desktop_size( &n_marie_minsx, &n_marie_minsy );
		//n_marie_minsx = n_posix_max_n_type_gfx( 160, (n_type_real) n_marie_minsx * 0.10 );

		//n_win_stdsize( hwnd, &n_marie_minsx, NULL, NULL );
		//n_marie_minsx = n_posix_max_n_type_gfx( 160, n_marie_minsx * 7 );

		n_marie_minsx = n_marie_minsize( hwnd );
		n_marie_minsy = n_marie_minsx;


		// Window

		n_win_init_literal( hwnd, N_MARIE_APPNAME, "MARIE_0_MAIN", "" );

		n_win_style_new( hwnd, N_WS_FIXEDWINDOW );
		n_win_sysmenu_disable( hwnd, 0,0,1, 0,1, 0, 0 );

		{

			int option = 0;

			option |= N_WIN_SCROLLBAR_OPTION_PAGER;
			option |= N_WIN_SCROLLBAR_OPTION_NO_ARROWS;

			n_win_scrollbar_init( &n_marie_hscr, hwnd, N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL, 0, option );
			n_win_scrollbar_init( &n_marie_vscr, hwnd, N_WIN_SCROLLBAR_LAYOUT_VERTICAL  , 0, option );

			n_marie_color_corner = n_win_darkmode_systemcolor( COLOR_BTNFACE );

			n_marie_hscr.color_edge_ul = n_marie_color_corner;
			n_marie_hscr.color_edge_ur = n_marie_color_corner;
			n_marie_hscr.color_edge_dl = n_marie_color_corner;
			n_marie_hscr.color_edge_dr = n_marie_color_corner;

			n_marie_vscr.color_edge_ul = n_marie_color_corner;
			n_marie_vscr.color_edge_ur = n_marie_color_corner;
			n_marie_vscr.color_edge_dl = n_marie_color_corner;
			n_marie_vscr.color_edge_dr = n_marie_color_corner;

		}


		// Init

		{
			n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_MARIE, cmdline );

#endif // #ifdef NONNON_APPS

			if ( n_string_commandline_option_literal( "-resource", cmdline ) )
			{
				n_marie_iconparade_resource = n_true;
			}

			n_marie_newfile( hwnd, cmdline, n_false, n_true );

			n_string_path_free( cmdline );
		}

		n_vfw_play( &n_marie_vfw );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_DROPFILES :
//break;
		{
			n_posix_char *cmdline = n_win_dropfiles_multiple_new( hwnd, wparam );

			n_marie_newfile( hwnd, cmdline, n_true, n_true );

			n_string_path_free( cmdline );
		}

		n_vfw_play( &n_marie_vfw );

	break;


	case WM_ERASEBKGND :

		return n_true;

	break;

	case WM_DISPLAYCHANGE :

		n_marie_window_refresh( hwnd, n_marie_bmp_main, N_WIN_SET_DEFAULT );

	break;

	case WM_PAINT :

		n_marie_client_refresh( hwnd, n_marie_bmp_main );

	break;

	case WM_MOVE :

		n_vfw_refresh( &n_marie_vfw );

	break;

	case WM_SIZE :

		if ( wparam != SIZE_MAXIMIZED ) { break; }

		if ( n_marie_n_win.state != SIZE_MAXIMIZED )
		{
			ShowWindow( hwnd, SW_NORMAL );
		}

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{

			// [Patch] : for internal error

			n_marie_on_timer( hwnd );

		} else
		if ( wparam == VK_RETURN )
		{

			if ( n_vfw_is_active( &n_marie_vfw ) ) { break; }

			n_marie_save( n_marie_bmp_main );

		} else
		if ( wparam == VK_LEFT )
		{

			if ( n_vfw_is_active( &n_marie_vfw ) ) { break; }

			n_marie_degree -= 10;
			n_marie_effect( hwnd, N_WIN_SET_CENTERING );

		} else
		if ( wparam == VK_RIGHT )
		{

			if ( n_vfw_is_active( &n_marie_vfw ) ) { break; }

			n_marie_degree += 10;
			n_marie_effect( hwnd, N_WIN_SET_CENTERING );

		}// else

//n_win_hwndprintf_literal( hwnd, "%d", n_marie_degree );

	break;


	case WM_MOUSEMOVE :

		if ( n_vfw_is_active( &n_marie_vfw ) )
		{

			// [Needed] : when hovering into VFW window

			n_win_on_mousemove( hwnd );

		} else {

			//

		}

	break;

	case WM_MOUSEHOVER :
	case WM_MOUSELEAVE :
//{ static int i = 0; n_win_hwndprintf_literal( hwnd, "%d, %d", msg, i ); i++; }

		if ( n_vfw_is_active( &n_marie_vfw ) )
		{

			int tmp = n_bmp_ui_progressbar_animation_interval;
			n_bmp_ui_progressbar_animation_interval = 0;

			// [!] : Win9x : prevent cursor flickering

			if ( n_vfw_ui_draw( &n_marie_vfw, &n_marie_vfw_ui, n_marie_bmp_main ) )
			{
				n_marie_client_refresh( hwnd, n_marie_bmp_main );
			}

			n_bmp_ui_progressbar_animation_interval = tmp;

		} else {

			//

		}

	break;

	case WM_LBUTTONDBLCLK :

		if ( n_vfw_is_active( &n_marie_vfw ) )
		{
			//
		} else {
			n_marie_window_refresh( hwnd, n_marie_bmp_main, N_WIN_SET_CENTERING );
		}

	break;

	case WM_LBUTTONUP :

		if ( n_vfw_is_active( &n_marie_vfw ) )
		{

			if ( n_vfw_ui_seek_is_hovered( &n_marie_vfw, &n_marie_vfw_ui ) )
			{

				n_type_gfx x = n_vfw_ui_seek_position( &n_marie_vfw, &n_marie_vfw_ui );

				n_vfw_seek( &n_marie_vfw, (n_type_real) x / n_marie_vfw_ui.seek_sx );
//n_win_hwndprintf_literal( hwnd, " %f ", (n_type_real) x / n_marie_vfw_ui.seek_sx );

				int tmp = n_bmp_ui_progressbar_animation_interval;
				n_bmp_ui_progressbar_animation_interval = 0;

				n_marie_client_refresh( hwnd, n_marie_bmp_main );

				n_bmp_ui_progressbar_animation_interval = tmp;

			}

		} else {

			//

		}

	break;

	case WM_LBUTTONDOWN :

		if ( n_vfw_is_active( &n_marie_vfw ) )
		{

			if ( n_vfw_ui_stop_is_hovered( &n_marie_vfw, &n_marie_vfw_ui ) )
			{

				n_marie_killtimer( hwnd );

				n_vfw_stop  ( &n_marie_vfw );
				n_vfw_rewind( &n_marie_vfw );

				n_marie_client_refresh( hwnd, n_marie_bmp_main );

			} else
			if ( n_vfw_ui_play_is_hovered( &n_marie_vfw, &n_marie_vfw_ui ) )
			{

				if ( n_vfw_is_stopped( &n_marie_vfw ) )
				{
					n_marie_settimer( hwnd );
					n_vfw_play( &n_marie_vfw );
				} else
				if ( n_vfw_is_playing( &n_marie_vfw ) )
				{
					n_marie_killtimer( hwnd );
					n_vfw_pause( &n_marie_vfw );
				} else
				if ( n_vfw_is_paused( &n_marie_vfw ) )
				{
					n_marie_settimer( hwnd );
					n_vfw_resume( &n_marie_vfw );
				}

				n_marie_client_refresh( hwnd, n_marie_bmp_main );

			}

/*
	n_posix_char str[ 100 ];
	MCIWndGetMode( n_marie_vfw.hwnd, str, 100 );
	n_win_text_set( hwnd, str );
*/

		} else {

			//

		}

	break;

	case WM_NCLBUTTONDOWN :

		// [Patch] : disable window moving

		if (
			( HTCAPTION == LOWORD( wparam ) )
			&&
			( n_marie_n_win.state == SIZE_MAXIMIZED )
		)
		{

			SetActiveWindow( hwnd );

			return 0;
		}

//n_win_hwndprintf( hwnd, "%d", LOWORD( wparam ) );

	break;


	case WM_COMMAND : 
	{

		HWND h = (HWND) lparam;

		if ( h == n_marie_hscr.hwnd )
		{
			n_marie_n_win.scrollx = (int) wparam;
			n_marie_client_refresh( hwnd, n_marie_bmp_main );
		} else
		if ( h == n_marie_vscr.hwnd )
		{
			n_marie_n_win.scrolly = (int) wparam;
			n_marie_client_refresh( hwnd, n_marie_bmp_main );
		}

	}
	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == n_marie_timer_id_vfw )
		{

			n_marie_client_refresh( hwnd, n_marie_bmp_main );

			if ( 100 > n_vfw_percent( &n_marie_vfw ) ) { break; }

			n_marie_killtimer( hwnd );
			n_vfw_stop( &n_marie_vfw );

			n_marie_client_refresh( hwnd, n_marie_bmp_main );

			n_marie_on_timer( hwnd );

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		if ( n_marie_jukebox_onoff )
		{
			n_win_systray_exit( &n_marie_systray_nid );
			n_win_timer_exit( hwnd, n_marie_systray_blink_id );
		}


		n_marie_killtimer( hwnd );


		n_win_scrollbar_exit( &n_marie_hscr );
		n_win_scrollbar_exit( &n_marie_vscr );


		n_jukebox_free( &n_marie_jukebox );
		n_vfw_free( &n_marie_vfw );


		n_bmp_free( &n_marie_bmp[ 0 ] );
		n_bmp_free( &n_marie_bmp[ 1 ] );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		n_string_path_free( n_marie_exepath );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_marie_mousegesture( hwnd, msg, wparam, lparam );


	n_marie_grab_n_drag_proc( hwnd, msg, wparam, lparam );


	if ( n_marie_jukebox_onoff )//( n_vfw_is_active( &n_marie_vfw ) )
	{
		n_marie_systray_proc( hwnd, msg, wparam, lparam );
	}


	n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &n_marie_hscr );
	n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &n_marie_vscr );

	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &n_marie_hscr );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &n_marie_vscr );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int
n_marie_main( void )
{


	WPARAM ret = n_win_main( NULL, n_marie_wndproc );


	return (int) ret;
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_marie_main();
}

#endif // #ifndef NONNON_APPS

