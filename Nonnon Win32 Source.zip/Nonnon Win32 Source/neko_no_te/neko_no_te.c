// Neko no Te
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : MinGW dropped multilingual support
//
//	gcc says "UTF-8 Only" but cannot compile UTF-8 text
//	reality is "ASCII only"
//	Shift-JIS : -finput-charset=cp932 -fexec-charset=cp932




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/com/IShellLink.c"

#include "../nonnon/win32/ole/IDropTarget.c"

#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_smallbutton_direct.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/win32/registry.c"

#include "../nonnon/neutral/path.c"

#include "../nonnon/project/small_find.c"
#include "../nonnon/project/small_save.c"
#include "../nonnon/project/macro.c"




// component

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NEKO_NO_TE ( 0 )

#endif // #ifndef NONNON_APPS


#include "./neko_no_te_new.c"




// shared resources

#define N_NEKONOTE_MAXBYTE         ( N_REGISTRY_ASSOCIATION_CCH_MAX * sizeof( n_posix_char ) )

#define N_NEKONOTE_MSG_EN          n_posix_literal( "Neko no Te" )

#ifdef UNICODE
#define N_NEKONOTE_MSG_JA          n_posix_literal( "\x732b\x306e\x624b" )       // Unicode LE
#else
#define N_NEKONOTE_MSG_JA          n_posix_literal( "\x94\x4c\x82\xcc\x8e\xe8" ) // Shift-JIS
#endif

#define N_NEKONOTE_MSG_ICO         n_posix_literal( "Icon"       )
#define N_NEKONOTE_MSG_EXE         n_posix_literal( "Exe"        )
#define N_NEKONOTE_MSG_EXT_LITERAL n_posix_literal( "Extensions" )
#define N_NEKONOTE_MSG_TYP_LITERAL n_posix_literal( "File Types" )


#define H_EXT_LINE     p->hgui[ 0 ]
#define H_EXT_ADD      p->hgui[ 1 ]
#define H_EXT_FIND     p->hgui[ 2 ]

#define H_TYP_LINE     p->hgui[ 3 ]
#define H_TYP_ADD      p->hgui[ 4 ]
#define H_TYP_FIND     p->hgui[ 5 ]

#define H_ICO_LABEL    p->hgui[ 6 ]

#define H_EXE_LABEL    p->hgui[ 7 ]

#define H_BTN_LINE     p->hgui[ 8 ]

#define GUI_MAX                 9


#define H_EXT_SYNC     p->hbtn[ 0 ]
#define H_BTN_ASSOC    p->hbtn[ 1 ]
#define BTN_MAX                 2




// Instance

typedef struct {

	HWND         hwnd;
	HWND         hgui[ GUI_MAX ];
	HWND         hpopup;
	n_win_button hbtn[ BTN_MAX ];
	n_bool       syncbutton_onoff;

	n_win_combo ext_combo;
	n_win_combo typ_combo;

	n_win_check ext_check;
	n_win_check typ_check;
	n_win_check ico_check;
	n_win_check exe_check;

	n_win_txtbox ext_input;
	n_win_txtbox typ_input;
	n_win_txtbox ico_input;
	n_win_txtbox exe_input;

	n_win_smallbutton_direct smallbutton_typ_save, smallbutton_typ_find;
	n_win_smallbutton_direct smallbutton_ext_save, smallbutton_ext_find;

	n_win_titlemenu  titlemenu;
	n_win_simplemenu simplemenu;

} n_nekonote;

#define n_nekonote_zero( p ) n_memory_zero( p, sizeof( n_nekonote ) )


static n_nekonote n_nekonote_instance;




// internal
void
n_nekonote_init( n_nekonote *p )
{

	HKEY  hkey;
	DWORD ret = RegOpenKeyEx( HKEY_CLASSES_ROOT, N_STRING_EMPTY, 0, KEY_ENUMERATE_SUB_KEYS, &hkey );
	if ( ret != ERROR_SUCCESS ) { return; }


	n_project_pleasewait_on( p->hwnd );


	n_posix_char ext[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( ext );
	n_posix_char typ[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( typ );

//n_vector_get_debug_onoff = 1;
	n_posix_sprintf_literal( ext, "%s", n_win_combo_selection_get( &p->ext_combo ) );
	n_posix_sprintf_literal( typ, "%s", n_win_combo_selection_get( &p->typ_combo ) );
//n_vector_get_debug_onoff = 0;

//n_posix_debug_literal( "%s\n%s", ext, typ );


	n_txt_new( &p->ext_combo.txt );
	n_txt_new( &p->typ_combo.txt );


	n_type_gfx ext_count = 0;
	n_type_gfx typ_count = 0;


	DWORD i = 0;
	n_posix_loop
	{//break;

		n_posix_char entry[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( entry, N_REGISTRY_ASSOCIATION_CCH_MAX );

		u32 byte = N_NEKONOTE_MAXBYTE;
		u32 ret  = RegEnumKeyEx( hkey, i, entry, &byte, NULL, NULL,NULL,NULL );
		if ( ret != ERROR_SUCCESS ) { break; }

		i++;


		if (
			( entry[ 0 ] == N_STRING_CHAR_DOT )
			||
			( entry[ 0 ] == N_STRING_CHAR_ASTERISK )
		)
		{

			n_txt_set( &p->ext_combo.txt, ext_count, entry ); ext_count++;

		} else {

			n_posix_char deficon[ N_PATH_MAX ]; n_posix_sprintf_literal( deficon, "%s\\DefaultIcon", entry );
			n_posix_char shell  [ N_PATH_MAX ]; n_posix_sprintf_literal(   shell, "%s\\shell",       entry );

			n_bool is_exist_1 = n_registry_is_exist( HKEY_CLASSES_ROOT, deficon, N_STRING_EMPTY );
			n_bool is_exist_2 = n_registry_is_exist( HKEY_CLASSES_ROOT,   shell, N_STRING_EMPTY );

			if ( ( is_exist_1 )||( is_exist_2 ) )
			{
				n_txt_set( &p->typ_combo.txt, typ_count, entry ); typ_count++;
			}

		}

	}

	RegCloseKey( hkey );


	n_win_hwndprintf_literal( H_EXT_LINE, "%s : %ld", N_NEKONOTE_MSG_EXT_LITERAL, ext_count );
	n_win_hwndprintf_literal( H_TYP_LINE, "%s : %ld", N_NEKONOTE_MSG_TYP_LITERAL, typ_count );


	n_win_combo_selection_set_by_string( &p->ext_combo, ext );
	n_win_combo_selection_set_by_string( &p->typ_combo, typ );


	n_project_pleasewait_off( p->hwnd );


	return;
}

#define N_NEKONOTE_ADD   0
#define N_NEKONOTE_FIND  1

#define N_NEKONOTE_EXT   0
#define N_NEKONOTE_TYP   1

#define n_nekonote_ext_add(  p ) n_nekonote_addfind( p, N_NEKONOTE_EXT, N_NEKONOTE_ADD , 0, 0 )
#define n_nekonote_typ_add(  p ) n_nekonote_addfind( p, N_NEKONOTE_TYP, N_NEKONOTE_ADD , 0, 0 )

#define n_nekonote_ext_find( p ) n_nekonote_addfind( p, N_NEKONOTE_EXT, N_NEKONOTE_FIND, 0, 0 )
#define n_nekonote_typ_find( p ) n_nekonote_addfind( p, N_NEKONOTE_TYP, N_NEKONOTE_FIND, 0, 0 )

// internal
void
n_nekonote_addfind( n_nekonote *p, int ext_or_typ, int add_or_find, n_posix_bool is_ext_combo, n_posix_bool is_typ_combo )
{
//n_posix_debug_literal( "" );

	n_posix_char str_ext[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
	n_posix_char str_typ[ N_REGISTRY_ASSOCIATION_CCH_MAX ];


	n_string_zero( str_ext, N_REGISTRY_ASSOCIATION_CCH_MAX );
	n_string_zero( str_typ, N_REGISTRY_ASSOCIATION_CCH_MAX );

	if ( is_ext_combo )
	{
		n_posix_sprintf_literal( str_ext, "%s", n_win_combo_selection_get( &p->ext_combo ) );
	} else {
		n_win_txtbox_selection_get( &p->ext_input, str_ext );
	}

	if ( is_typ_combo )
	{
		n_posix_sprintf_literal( str_typ, "%s", n_win_combo_selection_get( &p->typ_combo ) );
	} else {
		n_win_txtbox_selection_get( &p->typ_input, str_typ );
	}

//n_posix_debug_literal( "%s\n%s", str_ext, str_typ );
//n_win_hwndprintf_literal( p->hwnd, "%s", str_typ );


	if ( ext_or_typ == N_NEKONOTE_EXT )
	{

		if (
			( str_ext[ 0 ] != N_STRING_CHAR_NUL )
			&&
			( str_ext[ 0 ] != N_STRING_CHAR_DOT )
		)
		{
			n_posix_char s[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

			if ( N_REGISTRY_ASSOCIATION_CCH_MAX <= ( n_posix_strlen( str_ext ) + 1 ) ) { return; }

			n_posix_sprintf_literal( s, ".%s", str_ext );
			n_string_copy( s, str_ext );
		}

	} else {

		if (
			( str_typ[ 0 ] != N_STRING_CHAR_NUL )
			&&
			( str_typ[ 0 ] == N_STRING_CHAR_DOT )
		)
		{
			n_string_copy( &str_typ[ 1 ], &str_typ[ 0 ] );
		}

	}

//n_posix_debug_literal( "%s\n%s", str_ext, str_typ );


	//n_bool ret_ext = n_registry_is_exist( HKEY_CLASSES_ROOT, str_ext, N_STRING_EMPTY );
	//n_bool ret_typ = n_registry_is_exist( HKEY_CLASSES_ROOT, str_typ, N_STRING_EMPTY );

	if ( ext_or_typ == N_NEKONOTE_EXT )
	{

		if ( n_string_is_empty( str_ext ) ) { return; }

		if ( add_or_find == N_NEKONOTE_ADD )
		{

			n_registry_association_add( str_ext, N_STRING_EMPTY );

			n_nekonote_init( p );
			n_win_combo_selection_set_by_string( &p->ext_combo, str_ext );

			n_explorer_refresh( n_true );

		} else {

			n_nekonote_init( p );
			n_win_combo_selection_set_by_string( &p->ext_combo, str_ext );

			if ( p->syncbutton_onoff )
			{
				n_registry_read( HKEY_CLASSES_ROOT, str_ext, N_STRING_EMPTY, str_typ, N_NEKONOTE_MAXBYTE );
				n_win_combo_selection_set_by_string( &p->typ_combo, str_typ );

				n_posix_char typ[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( typ, N_REGISTRY_ASSOCIATION_CCH_MAX );
				n_posix_char ico[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( ico, N_REGISTRY_ASSOCIATION_CCH_MAX );
				n_posix_char exe[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( exe, N_REGISTRY_ASSOCIATION_CCH_MAX );

				n_string_copy( str_typ, typ );

				if ( n_false == n_string_is_empty( typ ) )
				{

					n_posix_char str[ N_PATH_MAX + N_REGISTRY_ASSOCIATION_CCH_MAX ];

					n_posix_sprintf_literal( str, "%s\\DefaultIcon", typ );
					n_registry_read( HKEY_CLASSES_ROOT, str, N_STRING_EMPTY, ico, N_NEKONOTE_MAXBYTE );

					n_posix_sprintf_literal( str, "%s\\shell\\open\\command", typ );
					n_registry_read( HKEY_CLASSES_ROOT, str, N_STRING_EMPTY, exe, N_NEKONOTE_MAXBYTE );

				}
//n_posix_debug_literal( "%s\n%s\n%s", typ, ico, exe );

				n_win_txtbox_line_set( &p->typ_input, 0, typ ); n_win_txtbox_select_tail_set( &p->typ_input );
				n_win_txtbox_line_set( &p->ico_input, 0, ico ); n_win_txtbox_select_tail_set( &p->ico_input );
				n_win_txtbox_line_set( &p->exe_input, 0, exe ); n_win_txtbox_select_tail_set( &p->exe_input );

				n_win_txtbox_refresh( &p->typ_input, N_WIN_TXTBOX_NEKO_NO_TE );
				n_win_txtbox_refresh( &p->ico_input, N_WIN_TXTBOX_NEKO_NO_TE );
				n_win_txtbox_refresh( &p->exe_input, N_WIN_TXTBOX_NEKO_NO_TE );
			}

		}

		n_win_txtbox_line_set( &p->ext_input, 0, str_ext );
		n_win_txtbox_select_tail_set( &p->ext_input );

		return;

	}


	if ( ext_or_typ  == N_NEKONOTE_TYP )
	{

		if ( n_string_is_empty( str_typ ) ) { return; }

		if ( add_or_find == N_NEKONOTE_ADD )
		{
//n_posix_debug_literal( "%s", caption );

			n_posix_char *ico = n_txt_get( &p->ico_input.txt, 0 );
			n_posix_char *exe = n_txt_get( &p->exe_input.txt, 0 );

			n_registry_filetype_reg( str_typ, NULL, ico, exe );

			n_nekonote_init( p );
			n_win_combo_selection_set_by_string( &p->typ_combo, str_typ );

			n_explorer_refresh( n_true );

		} else {

			n_nekonote_init( p );
			n_win_combo_selection_set_by_string( &p->typ_combo, str_typ );

//n_win_hwndprintf_literal( p->hwnd, "%s", str_typ );

			{

				n_posix_char typ[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( typ, N_REGISTRY_ASSOCIATION_CCH_MAX );
				n_posix_char ico[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( ico, N_REGISTRY_ASSOCIATION_CCH_MAX );
				n_posix_char exe[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_zero( exe, N_REGISTRY_ASSOCIATION_CCH_MAX );

				n_string_copy( str_typ, typ );

				if ( n_false == n_string_is_empty( typ ) )
				{

					n_posix_char str[ N_PATH_MAX + N_REGISTRY_ASSOCIATION_CCH_MAX ];

					n_posix_sprintf_literal( str, "%s\\DefaultIcon", typ );
					n_registry_read( HKEY_CLASSES_ROOT, str, N_STRING_EMPTY, ico, N_NEKONOTE_MAXBYTE );

					n_posix_sprintf_literal( str, "%s\\shell\\open\\command", typ );
					n_registry_read( HKEY_CLASSES_ROOT, str, N_STRING_EMPTY, exe, N_NEKONOTE_MAXBYTE );

				}
//n_posix_debug_literal( "%s\n%s\n%s", typ, ico, exe );

				n_win_txtbox_line_set( &p->typ_input, 0, typ ); n_win_txtbox_select_tail_set( &p->typ_input );
				n_win_txtbox_line_set( &p->ico_input, 0, ico ); n_win_txtbox_select_tail_set( &p->ico_input );
				n_win_txtbox_line_set( &p->exe_input, 0, exe ); n_win_txtbox_select_tail_set( &p->exe_input );

				n_win_txtbox_refresh( &p->typ_input, N_WIN_TXTBOX_NEKO_NO_TE );
				n_win_txtbox_refresh( &p->ico_input, N_WIN_TXTBOX_NEKO_NO_TE );
				n_win_txtbox_refresh( &p->exe_input, N_WIN_TXTBOX_NEKO_NO_TE );
			}

		}

		return;

	}


	return;
}

// internal
void
n_nekonote_delete( n_nekonote *p, n_win_combo *combo )
{

	n_posix_char *str = n_win_combo_selection_get( combo );

	if ( n_string_is_empty( str ) ) { return; }


	n_posix_char msg[ N_PATH_MAX + N_REGISTRY_ASSOCIATION_CCH_MAX ];

	n_posix_sprintf_literal( msg, "%s\n\n%s", n_project_string_really_ok, str );
	if ( n_project_dialog_yesno( p->hwnd, msg ) )
	{

		n_registry_association_del( str );

		n_nekonote_init( p );

	}


	return;
}

// internal
void
n_nekonote_assoc( n_nekonote *p )
{

	// [Needed] : zero-clear : strings will be invalid when not selected

	n_posix_char *ext = n_win_combo_selection_get( &p->ext_combo );
	n_posix_char *typ = n_win_combo_selection_get( &p->typ_combo );

//n_posix_debug( ext );
//n_posix_debug( typ );

	if ( n_string_is_empty( ext ) ) { return; }
	if ( n_string_is_empty( typ ) ) { return; }


	n_registry_association_add( ext, typ );


	n_registry_fileexts_clean( ext );
	n_explorer_refresh( n_true );


	n_nekonote_init( p );


	return;
}

void
n_nekonote_resize( n_nekonote *p, n_bool is_first )
{

	n_bool redraw = n_true;


	n_type_gfx ctl,m; n_win_stdsize( p->hwnd, &ctl, NULL, &m );


	n_type_gfx csx,csy;

	if ( is_first )
	{

		// [!] : for fixed/resizable window support

		static n_bool init = n_false;

		int nwset = N_WIN_SET_DEFAULT;
		if ( init == n_false )
		{
			init  = n_true;
			nwset = N_WIN_SET_CENTERING;
		}

		n_win_desktop_size( &csx, NULL );

		csx = n_posix_max_n_type_gfx( 333, (n_type_gfx) ( (n_type_real) csx * 0.33 ) );
		csy = ( ctl * 10 );

		if ( csx > csy )
		{
			csx = (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) );
		}

		n_win_set( p->hwnd, NULL, csx + m, csy + m, nwset );

	} else {

		// [!] : Neko no Te's UI is not suit for resizable window

		n_win w;
		n_win_set( p->hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		csx = w.csx - m;
		csy = w.csy - m;

	}


	n_type_gfx combo_count = 10;

	n_type_gfx bsx = csx;
	csx--;

	n_type_gfx u   = ( csx / 10 );
	n_type_gfx osx = ( csx % 10 ) + u;
	n_type_gfx isx = csx - osx;
	n_type_gfx msx = isx;
	n_type_gfx sx2 = ( 8 * u );

	n_type_gfx x   = 0;
	n_type_gfx y   = 0;

	n_win_move( H_EXT_LINE,  x,y, csx,ctl, redraw );

	x = osx; y += ctl;
	n_win_combo_move ( &p->ext_combo, x,y, msx,combo_count, redraw ); y += ctl;
	n_win_txtbox_move( &p->ext_input, x,y, isx,        ctl, redraw ); x += isx;
	n_win_txtbox_smallbutton_direct_embed( &p->ext_input, &p->smallbutton_ext_find, 0 );
	n_win_txtbox_smallbutton_direct_embed( &p->ext_input, &p->smallbutton_ext_save, 1 );

	n_win_smallbutton_direct_bitmap_init( &p->smallbutton_ext_find );
	n_win_smallbutton_direct_bitmap_init( &p->smallbutton_ext_save );

	x = 0; y += ctl;
	n_win_move( H_TYP_LINE,  x,y, csx,ctl, redraw );

	x = osx; y += ctl;
	n_win_combo_move ( &p->typ_combo, x,y, msx,combo_count, redraw ); y += ctl;
	n_win_txtbox_move( &p->typ_input, x,y, isx,  ctl,       redraw ); x += isx;
	n_win_txtbox_smallbutton_direct_embed( &p->typ_input, &p->smallbutton_typ_find, 0 );
	n_win_txtbox_smallbutton_direct_embed( &p->typ_input, &p->smallbutton_typ_save, 1 );

	n_win_smallbutton_direct_bitmap_init( &p->smallbutton_typ_find );
	n_win_smallbutton_direct_bitmap_init( &p->smallbutton_typ_save );

	x = osx; y += ctl;
	n_win_move       (  H_ICO_LABEL , x,y, 1*u,ctl, redraw ); x += 1*u;
	n_win_txtbox_move( &p->ico_input, x,y, sx2,ctl, redraw );

	x = osx; y += ctl;
	n_win_move       (  H_EXE_LABEL , x,y, 1*u,ctl, redraw ); x += 1*u;
	n_win_txtbox_move( &p->exe_input, x,y, sx2,ctl, redraw );

	x = 0; y += ctl;
	n_win_move( H_BTN_LINE       , x,y, csx,ctl, redraw );

	x = 0; y += ctl;
	n_win_button_move( &H_BTN_ASSOC , x,y, bsx,ctl, redraw );

	n_type_gfx chk = n_win_stdsize_check( p->hwnd ) + ( m * 2 ) + ( m * 2 );

	n_type_gfx o = ( ctl - chk ) / 2;

	x = ( u - ctl ) / 2; y = 0;
	n_win_button_move( &H_EXT_SYNC       , x,  (1*ctl), ctl,ctl, redraw );
	n_win_move       (  p->ext_check.hwnd, x,o+(2*ctl), chk,chk, redraw );
	n_win_move       (  p->typ_check.hwnd, x,o+(5*ctl), chk,chk, redraw );
	n_win_move       (  p->ico_check.hwnd, x,o+(6*ctl), chk,chk, redraw );
	n_win_move       (  p->exe_check.hwnd, x,o+(7*ctl), chk,chk, redraw );


	return;
}

void
n_nekonote_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_nekonote *p )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_combo_on_settingchange( &p->ext_combo );
		n_win_combo_on_settingchange( &p->typ_combo );

		n_win_check_on_settingchange( &p->ext_check );
		n_win_check_on_settingchange( &p->typ_check );
		n_win_check_on_settingchange( &p->ico_check );
		n_win_check_on_settingchange( &p->exe_check );

		n_win_txtbox_on_settingchange( &p->ext_input );
		n_win_txtbox_on_settingchange( &p->typ_input );
		n_win_txtbox_on_settingchange( &p->ico_input );
		n_win_txtbox_on_settingchange( &p->exe_input );

		n_win_smallbutton_direct_on_settingchange( &p->smallbutton_ext_save, n_project_small_save );
		n_win_smallbutton_direct_on_settingchange( &p->smallbutton_ext_find, n_project_small_find );
		n_win_smallbutton_direct_on_settingchange( &p->smallbutton_typ_save, n_project_small_save );
		n_win_smallbutton_direct_on_settingchange( &p->smallbutton_typ_find, n_project_small_find );

		n_win_button_on_settingchange( &H_EXT_SYNC  );
		n_win_button_on_settingchange( &H_BTN_ASSOC );

		n_win_stdfont_init( p->hgui, GUI_MAX );

		// [!] : use n_true for N_WS_FIXEDWINDOW

		//n_nekonote_resize( p, n_false );
		n_nekonote_resize( p, n_true );

	break;


	} // switch


}

LRESULT CALLBACK
n_nekonote_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_nekonote *p = &n_nekonote_instance;


	n_nekonote_on_settingchange( hwnd, msg, wparam, lparam, p );


	switch( msg ) {


	case WM_CREATE :


		// Global

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_ime_disable( hwnd );


		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;


		n_nekonote_zero( p );

		p->hwnd             = hwnd;
		p->syncbutton_onoff = n_false;


		// Window

		if ( 932 == GetACP() )
		{
			n_win_init( hwnd, N_NEKONOTE_MSG_JA, n_posix_literal( "NEKONOTE_0_MAIN" ), N_STRING_EMPTY );
		} else {
			n_win_init( hwnd, N_NEKONOTE_MSG_EN, n_posix_literal( "NEKONOTE_0_MAIN" ), N_STRING_EMPTY );
		}

		n_win_gui_literal( hwnd, CANVAS,  "", &H_EXT_LINE  );
		n_win_button_init( &H_EXT_SYNC , hwnd, N_STRING_EMPTY, PBS_PRESSED );
		n_win_combo_init( &p->ext_combo, hwnd );
		n_win_check_init( &p->ext_check, hwnd, N_STRING_EMPTY, CBS_UNCHECKEDNORMAL );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_EXT_ADD   );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_EXT_FIND  );

		n_win_gui_literal( hwnd, CANVAS,  "", &H_TYP_LINE  );
		n_win_combo_init( &p->typ_combo, hwnd );
		n_win_check_init( &p->typ_check, hwnd, N_STRING_EMPTY, CBS_UNCHECKEDNORMAL );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_TYP_ADD   );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_TYP_FIND  );

		n_win_gui_literal( hwnd, LABEL,   "", &H_ICO_LABEL );
		n_win_check_init( &p->ico_check, hwnd, N_STRING_EMPTY, CBS_UNCHECKEDNORMAL );

		n_win_gui_literal( hwnd, LABEL,   "", &H_EXE_LABEL );
		n_win_check_init( &p->exe_check, hwnd, N_STRING_EMPTY, CBS_UNCHECKEDNORMAL );

		n_win_gui_literal( hwnd, CANVAS,  "", &H_BTN_LINE  );
		n_win_button_init( &H_BTN_ASSOC, hwnd, n_project_string_go, PBS_NORMAL );

		n_win_text_set( H_ICO_LABEL, N_NEKONOTE_MSG_ICO  );
		n_win_text_set( H_EXE_LABEL, N_NEKONOTE_MSG_EXE  );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;
			//option |= N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE;
			//option |= N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT;

			if ( n_win_fluent_ui_onoff )
			{
				option |= N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE;
			}

			n_win_txtbox_init( &p->ext_input, hwnd, style, option );
			n_win_txtbox_init( &p->typ_input, hwnd, style, option );
			n_win_txtbox_init( &p->ico_input, hwnd, style, option );
			n_win_txtbox_init( &p->exe_input, hwnd, style, option );

//n_win_txtbox_debug_instance = &p->ext_input;
		}


		// Style

		n_win_style_new( hwnd, N_WS_FIXEDWINDOW );
		n_win_sysmenu_disable( hwnd, 0,0,1, 0,1, 0, 0 );

		n_win_smallbutton_direct_init_by_data( &p->smallbutton_ext_save, p->ext_input.hwnd, hwnd, hwnd, 1, n_project_small_save );
		n_win_smallbutton_direct_init_by_data( &p->smallbutton_ext_find, p->ext_input.hwnd, hwnd, hwnd, 2, n_project_small_find );
		n_win_smallbutton_direct_init_by_data( &p->smallbutton_typ_save, p->typ_input.hwnd, hwnd, hwnd, 3, n_project_small_save );
		n_win_smallbutton_direct_init_by_data( &p->smallbutton_typ_find, p->typ_input.hwnd, hwnd, hwnd, 4, n_project_small_find );

		p->smallbutton_ext_save.show_onoff = n_posix_true;
		p->smallbutton_ext_find.show_onoff = n_posix_true;
		p->smallbutton_typ_save.show_onoff = n_posix_true;
		p->smallbutton_typ_find.show_onoff = n_posix_true;


		{
			//H_EXT_SYNC.nomove_onoff = n_posix_true;

			int index = N_APPS_ICON_OFFSET_NEKO_NO_TE + 1;
			p->syncbutton_onoff = n_win_button_checklike( &H_EXT_SYNC, index, index, p->syncbutton_onoff );
		}


		n_win_simplemenu_init( &p->simplemenu );

		n_win_simplemenu_set( &p->simplemenu, 0, NULL, n_posix_literal( "[ ]Run \"regedit.exe\"" ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 1, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 2, NULL, n_posix_literal( "[ ]Delete Extension"    ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 3, NULL, n_posix_literal( "[ ]Delete File Type"    ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 4, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 5, NULL, n_posix_literal( "[ ]Refresh"             ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 6, NULL, n_posix_literal( "[ ]Refresh Explorer"    ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 7, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &p->simplemenu, 8, NULL, n_posix_literal( "[ ]Tweak New File"      ), NULL );

		n_win_titlemenu_init_main( &p->titlemenu, hwnd, &p->simplemenu );


		// Size

		n_win_stdfont_init( p->hgui, GUI_MAX );
		n_nekonote_resize( p, n_true );


		// Init

		n_nekonote_init( p );


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_DROPFILES :
	{

		if ( IsWindow( p->hpopup ) ) { break; }


		// [!] : N_PATH_MAX for n_path_*()

		n_posix_char cmdline[ N_PATH_MAX ];

		n_posix_char path[ N_ISHELLLINK_LNK2PATH_CCH_PATH ]; n_string_truncate( path );
		n_posix_char args[ N_ISHELLLINK_LNK2PATH_CCH_ARGS ]; n_string_truncate( args );
		n_posix_char icon[ N_ISHELLLINK_LNK2PATH_CCH_PATH ]; n_string_truncate( icon );
		n_type_gfx   icon_number = 0;

		n_win_dropfiles( hwnd, wparam, cmdline );

		if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, cmdline ) )
		{
			n_IShellLink_lnk2path( cmdline, path, args, icon, &icon_number );
		} else {
			n_posix_sprintf_literal( path, "%s", cmdline );
			n_posix_sprintf_literal( icon, "%s", cmdline );
		}

		if ( n_string_search_simple( path, N_STRING_SPACE ) )
		{
			n_string_doublequote_add( path, path );
		}

		if ( n_string_search_simple( icon, N_STRING_SPACE ) )
		{
			n_string_doublequote_add( icon, icon );
		}

		if ( n_win_check_is_checked( &p->ext_check ) )
		{

			n_posix_char str[ N_PATH_MAX ];

			n_path_ext_get( path, str );

			n_win_txtbox_line_set( &p->ext_input, 0, str );

			n_win_txtbox_refresh( &p->ext_input, N_WIN_TXTBOX_NEKO_NO_TE );

		}

		if ( n_win_check_is_checked( &p->typ_check ) )
		{

			n_posix_char str[ N_PATH_MAX ];

			n_path_name( cmdline, str );
			n_path_ext_del( str );

			n_win_txtbox_line_set( &p->typ_input, 0, str );

			n_win_txtbox_refresh( &p->typ_input, N_WIN_TXTBOX_NEKO_NO_TE );

		}

		if ( n_win_check_is_checked( &p->ico_check ) )
		{

			n_posix_char str[ N_PATH_MAX ];

			n_posix_sprintf_literal( str, "%s,%ld", path, icon_number );

			n_win_txtbox_line_set( &p->ico_input, 0, str );
			n_win_txtbox_select_tail_set( &p->ico_input );

			n_win_txtbox_refresh( &p->ico_input, N_WIN_TXTBOX_NEKO_NO_TE );

		}

		if ( n_win_check_is_checked( &p->exe_check ) )
		{

			n_posix_char str[ N_PATH_MAX ];

			// [!] : some programs need double-quotation for %1

			if ( n_string_is_empty( args ) )
			{
				n_posix_sprintf_literal( str, "%s \"%%1\"", path );
			} else {
				n_posix_sprintf_literal( str, "%s %s \"%%1\"", path, args );
			}

			n_win_txtbox_line_set( &p->exe_input, 0, str );
			n_win_txtbox_select_tail_set( &p->exe_input );

			n_win_txtbox_refresh( &p->exe_input, N_WIN_TXTBOX_NEKO_NO_TE );

		}

	}
	break;


	case WM_SIZE :

		//n_nekonote_resize( p, n_false );

	break;


	case WM_LBUTTONDOWN :

		SetFocus( hwnd );

	break;

/*
	case WM_KEYDOWN :

		if ( wparam == 'A' )
		{
			n_win_inputpopup_open_txtbox( hwnd, &p->ext_input );
		}

	break;
*/

	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_EXT_SYNC.hwnd )
		{

			int index = N_APPS_ICON_OFFSET_NEKO_NO_TE + 1;
			p->syncbutton_onoff = n_win_button_checklike( &H_EXT_SYNC, index, index, p->syncbutton_onoff );

		} else

		if ( h == p->ext_combo.input.hwnd )
		{

			if ( wparam == p->ext_combo.wparam_selection_changed )
			{
				n_nekonote_addfind( p, N_NEKONOTE_EXT, N_NEKONOTE_FIND, n_posix_true, n_posix_true );
			}

		} else

		if ( h == p->typ_combo.input.hwnd )
		{

			if ( wparam == p->typ_combo.wparam_selection_changed )
			{
				n_nekonote_addfind( p, N_NEKONOTE_TYP, N_NEKONOTE_FIND, n_posix_true, n_posix_true );
			}

		} else

		if ( h == p->ext_input.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &p->ext_input );
			}

		} else

		if ( h == p->typ_input.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &p->typ_input );
			}

		} else

		if ( h == p->ico_input.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &p->ico_input );
			}

		} else

		if ( h == p->exe_input.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &p->exe_input );
			}

		} else

		if ( ( h == p->smallbutton_ext_save.hwnd_msg )&&( wparam == 1 ) )
		{
			n_win_inputpopup_close();
			n_nekonote_ext_add( p );
		} else

		if ( ( h == p->smallbutton_ext_find.hwnd_msg )&&( wparam == 2 ) )
		{
			n_win_inputpopup_close();
			n_nekonote_ext_find( p );
		} else

		if ( ( h == p->smallbutton_typ_save.hwnd_msg )&&( wparam == 3 ) )
		{
			n_win_inputpopup_close();
			n_nekonote_typ_add( p );
		} else

		if ( ( h == p->smallbutton_typ_find.hwnd_msg )&&( wparam == 4 ) )
		{
			n_win_inputpopup_close();
			n_nekonote_typ_find( p );
		} else

		if ( h == H_BTN_ASSOC.hwnd )
		{
			n_nekonote_assoc( p );
		} else

		if ( h == p->simplemenu.hwnd )
		{

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{

				n_win_inputpopup_close();

				n_posix_char *str_ext = n_win_combo_selection_get( &p->ext_combo );

				if ( n_string_is_empty( str_ext ) )
				{
					n_win_simplemenu_tweak_literal( &p->simplemenu, 2, 'x' );
					n_win_simplemenu_tweak_literal( &p->simplemenu, 8, 'x' );
				} else {
					n_win_simplemenu_tweak_literal( &p->simplemenu, 2, ' ' );
					n_win_simplemenu_tweak_literal( &p->simplemenu, 8, ' ' );
				}


				n_posix_char *str_typ = n_win_combo_selection_get( &p->typ_combo );

				if ( n_string_is_empty( str_typ ) )
				{
					n_win_simplemenu_tweak_literal( &p->simplemenu, 3, 'x' );
				} else {
					n_win_simplemenu_tweak_literal( &p->simplemenu, 3, ' ' );
				}

			} else
			if ( wparam == 0 )
			{

				// [!] : Vista or later : UAC : rejected silently, error dialog at exit

				if ( n_sysinfo_version_vista_or_later() )
				{

					n_posix_char *runas = n_posix_literal( "runas" );
					n_posix_char *exe   = n_posix_literal( "regedit.exe" );

					ShellExecute( hwnd, runas, exe, 0, 0, SW_SHOWNORMAL );

				} else {

					n_win_exec_literal( "regedit.exe", SW_NORMAL );

				}

			} else
			if ( wparam == 2 )
			{

				n_nekonote_delete( p, &p->ext_combo );

			} else
			if ( wparam == 3 )
			{

				n_nekonote_delete( p, &p->typ_combo );

			} else
			if ( wparam == 5 )
			{

				n_nekonote_init( p );

			} else
			if ( wparam == 6 )
			{

				n_explorer_refresh( n_true );

			} else
			if ( wparam == 8 )
			{

				n_string_copy( n_win_combo_selection_get( &p->ext_combo ), n_nekonote_new_ext );
				n_string_copy( n_win_combo_selection_get( &p->typ_combo ), n_nekonote_new_typ );

				n_win_gui( hwnd, WINDOW, n_nekonote_new_wndproc, &p->hpopup );

			} //else

		}

	}
	break;


	case WM_CLOSE :

		n_win_inputpopup_silent_onoff = n_true;
		n_win_inputpopup_close();

		ShowWindow( hwnd, SW_HIDE );

		n_win_check_exit( &p->ext_check );
		n_win_check_exit( &p->typ_check );
		n_win_check_exit( &p->ico_check );
		n_win_check_exit( &p->exe_check );

		n_win_smallbutton_direct_exit( &p->smallbutton_ext_save );
		n_win_smallbutton_direct_exit( &p->smallbutton_ext_find );
		n_win_smallbutton_direct_exit( &p->smallbutton_typ_save );
		n_win_smallbutton_direct_exit( &p->smallbutton_typ_find );

		n_win_txtbox_exit( &p->ext_input );
		n_win_txtbox_exit( &p->typ_input );
		n_win_txtbox_exit( &p->ico_input );
		n_win_txtbox_exit( &p->exe_input );

		n_win_button_exit( &H_EXT_SYNC  );
		n_win_button_exit( &H_BTN_ASSOC );

		n_win_combo_silent = n_true;
		n_win_combo_exit( &p->ext_combo );

		n_win_combo_silent = n_true;
		n_win_combo_exit( &p->typ_combo );

		n_win_stdfont_exit( p->hgui, GUI_MAX );

		n_win_titlemenu_exit( &p->titlemenu );

		n_win_simplemenu_exit( &p->simplemenu );

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_EXT_SYNC  );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_ASSOC );


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_EXT_LINE, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_TYP_LINE, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_BTN_LINE, PS_SOLID );


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &p->ext_combo );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &p->typ_combo );


	n_win_check_proc( hwnd, msg, wparam, lparam, &p->ext_check );
	n_win_check_proc( hwnd, msg, wparam, lparam, &p->typ_check );
	n_win_check_proc( hwnd, msg, wparam, lparam, &p->ico_check );
	n_win_check_proc( hwnd, msg, wparam, lparam, &p->exe_check );


	{
		int ret = 0;

		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &p->ext_input );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &p->typ_input );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &p->ico_input );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &p->exe_input );

		if ( ret ) { return ret; }
	}


	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &p->ext_input );
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &p->typ_input );
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &p->ico_input );
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &p->exe_input );
	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );


	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &p->smallbutton_ext_save );
	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &p->smallbutton_ext_find );
	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &p->smallbutton_typ_save );
	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &p->smallbutton_typ_find );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nekonote_wndproc );
}

#endif // #ifndef NONNON_APPS




#undef H_EXT_LINE
#undef H_EXT_ADD
#undef H_EXT_FIND

#undef H_TYP_LINE
#undef H_TYP_ADD
#undef H_TYP_FIND

#undef H_ICO_LABEL

#undef H_EXE_LABEL
#undef H_EXE_INPUT

#undef H_BTN_LINE

#undef GUI_MAX


#undef H_EXT_SYNC
#undef H_BTN_ASSOC
#undef BTN_MAX


