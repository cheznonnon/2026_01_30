// Nonnon Freecell
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism] : terminology
//
//	[ Stock ]
//
//	+ upper-right corner
//	+ place where stack A to K
//
//	[ Freecell ]
//
//	+ upper-left corer
//	+ 4 cards only puttable
//
//	[ Tableau ]
//
//	+ main play area




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




//#define N_MEMORY_DEBUG




#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/click.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"

#include "../nonnon/neutral/bmp/ui/transition.c"


//#include "../nonnon/neutral/ini.c"

#include "../nonnon/win32/gdi.c"
#include "../nonnon/win32/win_titlemenu.c"

#include "../nonnon/project/macro.c"

#include "../nonnon/project/cardgenerator/cardgenerator.c"




// Constants

#ifndef N_GAMECONSOLE

#define N_GAMECONSOLE_ICON_OFFSET_FREECELL ( 1 )

#endif // #ifndef N_GAMECONSOLE


#define NFREECELL_WAV_MUTE         "N_PROJECT_SOUND_MUTE"
#define NFREECELL_WAV_TAKE         "N_PROJECT_SOUND_CLICK"
#define NFREECELL_WAV_DONE         "N_PROJECT_SOUND_GET"

#define N_FREECELL_NOTHING         ( -1 )

#define N_FREECELL_SUIT_HEARTS     N_CARDGENERATOR_SUIT_HEARTS
#define N_FREECELL_SUIT_DIAMONDS   N_CARDGENERATOR_SUIT_DIAMONDS
#define N_FREECELL_SUIT_SPADES     N_CARDGENERATOR_SUIT_SPADES
#define N_FREECELL_SUIT_CLUBS      N_CARDGENERATOR_SUIT_CLUBS
#define N_FREECELL_SUIT_MAX        N_CARDGENERATOR_SUIT_MAX

#define N_FREECELL_CARD_UNIT       N_CARDGENERATOR_CARD_UNIT
#define N_FREECELL_CARD_ALL        N_CARDGENERATOR_CARD_ALL
#define N_FREECELL_PILE_SX         ( 8 )
#define N_FREECELL_PILE_SY         ( N_FREECELL_CARD_UNIT * 2 )
#define N_FREECELL_PILE_ALL        ( N_FREECELL_PILE_SX * N_FREECELL_PILE_SY )
#define N_FREECELL_TABLEAU         ( N_FREECELL_SUIT_MAX + N_FREECELL_PILE_ALL )

//#define N_FREECELL_DEAL_MSEC       (  100 )
#define N_FREECELL_FADE_MSEC       ( 1000 )
#define N_FREECELL_RESZ_MSEC       (  200 )

#define N_FREECELL_DEAL_PHASE_0    0
#define N_FREECELL_DEAL_PHASE_1    1
#define N_FREECELL_DEAL_PHASE_2    2

#define N_FREECELL_RESZ_PHASE_NONE 0
#define N_FREECELL_RESZ_PHASE_STOP 1

#define N_FREECELL_WATCHER_L       0
#define N_FREECELL_WATCHER_R       1

#define N_FREECELL_TIMER_ID_STYLE  ( 1 )

#define N_FREECELL_ANIMATION_STEP  ( 12 )

#define N_FREECELL_SHADOW_COUNT    ( N_FREECELL_SUIT_MAX + 1 )




typedef struct {

	n_bool            is_init;

	n_bool            is_first;

	n_cardgenerator   cardgen;

	u32               color_init;
	u32               color_text;
	u32               color_gradient_upper;
	u32               color_gradient_lower;
	u32               color_halo_focus;
	u32               color_halo_current;

	n_bool            splash_onoff;

	n_game_sound      snd_mute;
	n_game_sound      snd_take;
	n_game_sound      snd_done;

	n_bool            is_done;

	n_bmp             bmp_bg;
	n_bmp             bmp_freecell;
	n_bmp             bmp_stock[ N_FREECELL_SUIT_MAX ];
	n_bmp             bmp_neko_l, bmp_neko_r;

	int               transition_type;
	n_bmp             transition_bmp_old;
	n_bmp             transition_bmp_new;
	n_type_real       transition_percent;

	n_bool            animation_onoff;
	int               animation_index_f;
	int               animation_index_t;
	n_type_real       animation_base_x;
	n_type_real       animation_base_y;
	n_type_real       animation_step_x;
	n_type_real       animation_step_y;
	int               animation_server[ N_FREECELL_SUIT_MAX ];

	n_bool            redraw  [ N_FREECELL_PILE_SX  ];
	n_game_chara      freecell[ N_FREECELL_SUIT_MAX ];
	n_game_chara      stock   [ N_FREECELL_SUIT_MAX ];
	n_game_chara      tableau [ N_FREECELL_TABLEAU  ];
	n_game_chara      bottom  [ N_FREECELL_PILE_SX  ];
	n_game_chara      restore [ N_FREECELL_PILE_SY  ];
	int               drag_index;
	int               restore_count;
	int               freespace;

	int               shuffle[ N_FREECELL_CARD_ALL ];

	int               watcher;

	n_win_titlemenu   titlemenu;
	n_win_simplemenu  simplemenu;

	n_bool            shadow_global_onoff;
	n_bool            shadow_onoff;
	n_bmp            *shadow_bmp;
	n_bmp             shadow_bmp_cache[ N_FREECELL_SHADOW_COUNT ];
	n_type_gfx        shadow_x;
	n_type_gfx        shadow_y;
	n_type_gfx        shadow_sx;
	n_type_gfx        shadow_sy;
	n_type_gfx        shadow_px;
	n_type_gfx        shadow_py;
	n_type_gfx        shadow_psx;
	n_type_gfx        shadow_psy;

	n_game_click      doubleclick;

	n_bool            debug_onoff;
	int               debug_automove_count;

} n_freecell;


static n_freecell freecell;




// Components

#include "./subclass.c"

#include "./n_freecell_splashscreen.c"
#include "./n_freecell_watcher.c"




#define n_freecell_pos2index( x, y ) ( N_FREECELL_SUIT_MAX + ( x ) + ( N_FREECELL_PILE_SX * ( y ) ) )

#define n_freecell_index_upper( i ) ( ( i ) * N_FREECELL_PILE_SX )

void
n_freecell_debug( n_freecell *p )
{

	int movable = 0;
	int dnd     = 0;

	int i = 0;
	n_posix_loop
	{

		extern n_bool n_freecell_rule_is_movable( n_freecell*, int );
		movable += n_freecell_rule_is_movable( p, i );

		dnd += p->tableau[ i ].dnd_onoff;

		i++;
		if ( i >= N_FREECELL_TABLEAU ) { break; }
	}


	n_posix_char str[ 1024 ];

	int cch = 0;

	cch += n_posix_sprintf_literal( &str[ cch ], "game.refresh             = %d\n", game.refresh );
	cch += n_posix_sprintf_literal( &str[ cch ], "freecell.is_init         = %d\n", p->is_init );
	cch += n_posix_sprintf_literal( &str[ cch ], "freecell.animation_onoff = %d\n", p->animation_onoff );
	cch += n_posix_sprintf_literal( &str[ cch ], "freecell.drag_index      = %d\n", p->drag_index );
	cch += n_posix_sprintf_literal( &str[ cch ], "freecell.restore_count   = %d\n", p->restore_count );
	cch += n_posix_sprintf_literal( &str[ cch ], "freecell.freespace       = %d\n", p->freespace );
	cch += n_posix_sprintf_literal( &str[ cch ], "is_movable()             = %d\n", movable );
	cch += n_posix_sprintf_literal( &str[ cch ], "dnd_onoff                = %d\n", dnd );
	cch += n_posix_sprintf_literal( &str[ cch ], "dnd_refcount             = %d\n", (int) n_game_chara_dnd_refcount );

	n_posix_debug_literal( "%s", str );


	if ( ( dnd == 0 )&&( n_game_chara_dnd_refcount != 0 ) ) { n_game_chara_dnd_refcount = 0; }


	return;
}

void
n_freecell_pile_count( n_freecell *p, int redraw_map[ N_FREECELL_PILE_SX ] )
{

	int x = 0;
	n_posix_loop
	{

		redraw_map[ x ] = 0;

		int y = 0;
		n_posix_loop
		{

			int target = n_freecell_pos2index( x, y );
			n_game_chara *c = &p->tableau[ target ];

			if ( c->data == N_FREECELL_NOTHING ) { break; }

			//if ( p->redraw[ x ] )
			{
				redraw_map[ x ]++;
			}

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}

		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}

/*
	// [x] : don't do on a thread

	n_game_hwndprintf_literal
	(
		"%d %d %d %d %d %d %d %d",
		redraw_map[ 0 ],
		redraw_map[ 1 ],
		redraw_map[ 2 ],
		redraw_map[ 3 ],
		redraw_map[ 4 ],
		redraw_map[ 5 ],
		redraw_map[ 6 ],
		redraw_map[ 7 ]
	);
*/

	return;
}

void
n_freecell_redraw( n_freecell *p )
{

	int x = 0;
	n_posix_loop
	{

		p->redraw[ x ] = n_true;

		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return;
}

void
n_freecell_chara_erase( n_freecell *p, n_game_chara *c )
{

	const n_type_gfx m  = p->cardgen.halo;
	const n_type_gfx mm = ( p->cardgen.halo * 2 ) + ( p->cardgen.halo % 2 );


	c->px -= m;
	c->py -= m;
	c->sx += mm;
	c->sy += mm;

	n_game_chara_erase( c );

	c->px += m;
	c->py += m;
	c->sx -= mm;
	c->sy -= mm;


	return;
}

void
n_freecell_chara_draw( n_freecell *p, n_game_chara *c )
{

	if ( p->animation_onoff == n_false )
	{

		n_type_gfx x = c->x - p->cardgen.halo;
		n_type_gfx y = c->y - p->cardgen.halo;

		n_bmp_rasterizer
		(
			&p->cardgen.bmp_halo, &game.bmp, x,y, 
			p->color_halo_current,
			n_false
		);
/*
		n_bmp_rasterizer_clip
		(
			&p->cardgen.bmp_halo, &game.bmp, x,y, 
			NULL, p->cardgen.color_halo,
			&p->bmp_freecell, -p->cardgen.halo, -p->cardgen.halo,
			n_false
		);
*/
	}


	n_game_chara_draw( c );


	return;
}

void
n_freecell_shadow( n_freecell *p )
{

	if ( p->shadow_global_onoff == n_false ) { return; }

	//if ( p->animation_onoff ) { return; }


	int index = 0;
	if ( p->restore_count >= 1 ) { index = p->restore_count - 1; }

//n_game_hwndprintf_literal( " %d %d : %d %d ", p->animation_onoff, p->drag_index, p->restore_count, index );


	p->shadow_bmp = &p->shadow_bmp_cache[ index ];

	if ( NULL != N_BMP_PTR( p->shadow_bmp ) )
	{
		return;
	}


	n_game_chara *c = &p->tableau[ p->drag_index ];

	n_type_gfx osy = 0; if ( p->restore_count >= 2 ) { osy = p->cardgen.osy * ( p->restore_count - 1 ); }

//n_game_hwndprintf_literal( " %d ", p->cardgen.halo );

	p->shadow_x  = c->x + ( p->cardgen.halo * 2 );
	p->shadow_y  = c->y + ( p->cardgen.halo * 2 );
	p->shadow_sx = c->sx;
	p->shadow_sy = c->sy + osy;

	n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp );
	n_cardgenerator_dropshadow( &bmp_tmp, p->shadow_sx, p->shadow_sy, p->cardgen.halo, p->cardgen.halo / 2 );

	n_bmp_new_fast( p->shadow_bmp, N_BMP_SX( &bmp_tmp ),N_BMP_SY( &bmp_tmp ) );
	n_bmp_flush( p->shadow_bmp, n_bmp_black_invisible );

	u32 shadow_color = n_bmp_blend_pixel( p->color_gradient_upper, n_bmp_black_invisible, 0.5 );
	n_bmp_rasterizer( &bmp_tmp, p->shadow_bmp, 0,0, shadow_color, n_false );
//n_bmp_save_literal( p->shadow_bmp, "ret.bmp" );

	n_bmp_free_fast( &bmp_tmp );


	return;
}

void
n_freecell_shadow_erase( n_freecell *p )
{

	if ( p->shadow_global_onoff == n_false ) { return; }

	//if ( p->animation_onoff ) { return; }

	if ( p->shadow_onoff == n_false ) { return; }


	p->shadow_onoff = n_false;


	n_type_gfx  x = p->shadow_px;
	n_type_gfx  y = p->shadow_py;
	n_type_gfx sx = p->shadow_psx;
	n_type_gfx sy = p->shadow_psy;

//n_bmp_box( &game.bmp, x,y,sx,sy, n_bmp_rgb(0,200,255) );
	n_bmp_fastcopy( &p->bmp_bg, &game.bmp, x,y,sx,sy, x,y );


	n_game_chara a; n_game_chara_zero( &a );
	n_game_chara_pos( &a, x,y );
	n_game_chara_src( &a, 0,0, sx,sy, 0,0 );

	n_type_gfx ix = 0;
	n_type_gfx iy = 0;
	n_posix_loop
	{//break;

		int target = n_freecell_pos2index( ix, iy );
		n_game_chara *b = &p->tableau[ target ];

		if ( n_game_chara_is_hit( &a, b ) )
		{
			p->redraw[ ix ] = n_true;
		}

		ix++;
		if ( ix >= N_FREECELL_PILE_SX )
		{

			ix = 0;

			iy++;
			if ( iy >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_freecell_shadow_draw( n_freecell *p )
{

	if ( p->shadow_global_onoff == n_false ) { return; }

	//if ( p->animation_onoff ) { return; }


	p->shadow_onoff = n_true;

	n_game_chara *c = &p->tableau[ p->drag_index ];

	n_type_gfx ox = ( p->cardgen.halo * 1 );
	n_type_gfx oy = ( p->cardgen.halo * 1 );
	n_type_gfx  x = c->x + ox;
	n_type_gfx  y = c->y + oy;
	n_type_gfx sx = N_BMP_SX( p->shadow_bmp );
	n_type_gfx sy = N_BMP_SY( p->shadow_bmp );

	//n_bmp_rasterizer( p->shadow_bmp, &game.bmp, x,y, n_bmp_rgb( 50,50,50 ), n_false );
	//n_bmp_transcopy( p->shadow_bmp, &game.bmp, 0,0,sx,sy, x,y );

	n_bmp_clipcopy( p->shadow_bmp, &game.bmp, 0,0,sx,sy, x,y, c->chara,ox,oy, 0.0 );
//n_bmp_save_literal( c->chara, "ret.bmp" );


	p->shadow_px  = x;
	p->shadow_py  = y;
	p->shadow_psx = N_BMP_SX( p->shadow_bmp );
	p->shadow_psy = N_BMP_SY( p->shadow_bmp );


	return;
}

void
n_freecell_animation_go( n_freecell *p, int index_f, int index_t )
{

	p->animation_onoff   = n_true;
	p->animation_index_f = index_f;
	p->animation_index_t = index_t;
	p->animation_base_x  = p->tableau[ index_f ].x;
	p->animation_base_y  = p->tableau[ index_f ].y;

	n_type_real step = N_FREECELL_ANIMATION_STEP;
	p->animation_step_x  = (n_type_real) ( p->stock[ index_t ].x - p->tableau[ index_f ].x ) / step;
	p->animation_step_y  = (n_type_real) ( p->stock[ index_t ].y - p->tableau[ index_f ].y ) / step;

	p->drag_index        = p->animation_index_f;


	p->restore_count     = 0;

	n_freecell_shadow( p );


//p->debug_automove_count++;

	return;
}

void
n_freecell_redraw_detect( n_freecell *p )
{

	n_game_chara card = p->tableau[ p->drag_index ];
//n_game_hwndprintf_literal( " %d ", p->drag_index );

	card.x = card.px;
	card.y = card.py;


	int x = 0;
	int y = 0;
	n_posix_loop
	{

		if ( y == 0 )
		{

			n_game_chara *b = &p->bottom[ x ];
			if ( n_game_chara_is_hit_offset( &card, b, -p->cardgen.halo,-p->cardgen.halo, 0,0 ) )
			{
//n_game_hwndprintf_literal( " 1 " );
				p->redraw[ x ] = n_true;
			}

		} else {

			if ( ( x == p->drag_index )&&( p->restore_count != 0 ) )
			{
//n_game_hwndprintf_literal( " 2 " );

				p->redraw[ x ] = n_true;

			} else {

				int target = n_freecell_pos2index( x, y );
				n_game_chara *c = &p->tableau[ target ];

				if (
					( c->data != N_FREECELL_NOTHING )
					&&
					( n_game_chara_is_hit_offset( &card, c, -p->cardgen.halo,-p->cardgen.halo, 0,0 ) )
				)
				{
//n_game_hwndprintf_literal( " 3 " );
					p->redraw[ x ] = n_true;
				}

			}

		}


		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_freecell_reposition( n_freecell *p )
{

	// Reset : when resized

	int x,y;


	x = 0;
	n_posix_loop
	{

		n_game_chara *c;


		c = &p->freecell[ x ];

		n_game_chara_pos( c, p->cardgen.card_sx * x, 0 );
		n_game_chara_prv( c );


		c = &p->tableau[ x ];

		n_game_chara_pos( c, p->cardgen.card_sx * x, 0 );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	x = 0;
	n_posix_loop
	{
		n_game_chara *c = &p->stock[ x ];

		n_game_chara_pos( c, p->cardgen.csx - ( p->cardgen.card_sx * 4 ) + ( p->cardgen.card_sx * x ), 0 );
		n_game_chara_prv( c );

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	n_type_gfx tmp_sx = p->cardgen.csx / N_FREECELL_PILE_SX;
	if ( tmp_sx > p->cardgen.card_sx )
	{
		p->cardgen.osx = (n_type_gfx) ( fmod( tmp_sx, p->cardgen.card_sx ) / 2 );
	} else {
		p->cardgen.osx = 0;
	}

//n_game_hwndprintf_literal( "%d : %d %d", p->cardgen.osx, p->cardgen.csx, p->cardgen.card_sx );
//n_game_hwndprintf_literal( "%d %d", ( p->cardgen.csx / N_FREECELL_PILE_SX ), fmod( ( p->cardgen.csx / N_FREECELL_PILE_SX ), p->cardgen.card_sx ) );

	x = 0;
	y = 0;
	n_posix_loop
	{

		int target = n_freecell_pos2index( x,y );

		n_game_chara *c = &p->tableau[ target ];


		n_type_gfx tx = ( ( p->cardgen.osx + p->cardgen.card_sx + p->cardgen.osx ) * x ) + p->cardgen.osx;
		n_type_gfx ty = p->cardgen.card_sy + ( p->cardgen.osy * y );

		n_game_chara_pos( c, tx,ty );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}

	x = 0;
	n_posix_loop
	{

		n_game_chara *c = &p->bottom[ x ];


		n_type_gfx tx = ( ( p->cardgen.osx + p->cardgen.card_sx + p->cardgen.osx ) * x ) + p->cardgen.osx;

		n_game_chara_pos( c, tx,p->cardgen.card_sy );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return;
}

#define n_freecell_rule_is_hearts(   p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_HEARTS,   N_FREECELL_SUIT_DIAMONDS )
#define n_freecell_rule_is_diamonds( p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_DIAMONDS, N_FREECELL_SUIT_SPADES   )
#define n_freecell_rule_is_spades(   p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_SPADES,   N_FREECELL_SUIT_CLUBS    )
#define n_freecell_rule_is_clubs(    p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_CLUBS,    N_FREECELL_SUIT_MAX      )
#define n_freecell_rule_is_reds(     p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_HEARTS,   N_FREECELL_SUIT_SPADES   )
#define n_freecell_rule_is_blacks(   p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_SPADES,   N_FREECELL_SUIT_MAX      )

n_bool
n_freecell_rule_range( n_freecell *p, int index, int f, int t )
{

	int data = p->tableau[ index ].data;
	int unit = N_FREECELL_CARD_UNIT;

	if ( ( data >= ( unit * f ) )&&( data < ( unit * t ) ) ) { return n_true; }


	return n_false;
}

n_bool
n_freecell_rule_suit_is_ok( n_freecell *p, int a, int b )
{

	if ( ( n_freecell_rule_is_hearts  ( p, a ) ) && ( n_freecell_rule_is_hearts  ( p, b ) ) ) { return n_true; }
	if ( ( n_freecell_rule_is_diamonds( p, a ) ) && ( n_freecell_rule_is_diamonds( p, b ) ) ) { return n_true; }
	if ( ( n_freecell_rule_is_spades  ( p, a ) ) && ( n_freecell_rule_is_spades  ( p, b ) ) ) { return n_true; }
	if ( ( n_freecell_rule_is_clubs   ( p, a ) ) && ( n_freecell_rule_is_clubs   ( p, b ) ) ) { return n_true; }


	return n_false;
}

n_bool
n_freecell_rule_half_is_ok( n_freecell *p, int a, int b )
{

	if ( ( n_freecell_rule_is_reds(   p, a ) ) && ( n_freecell_rule_is_blacks( p, b ) ) ) { return n_true; }
	if ( ( n_freecell_rule_is_blacks( p, a ) ) && ( n_freecell_rule_is_reds  ( p, b ) ) ) { return n_true; }


	return n_false;
}

n_bool
n_freecell_rule_rank_is_ok( n_freecell *p, int a, int b )
{

	a = p->tableau[ a ].data;
	b = p->tableau[ b ].data;


	int rank;

	rank  = a % N_FREECELL_CARD_UNIT;
	rank -= b % N_FREECELL_CARD_UNIT;

	if ( rank == 1 )
	{
		return n_true;
	}


	return n_false;
}

int
n_freecell_rule_freespace( n_freecell *p )
{

	int freespace = 0;

	int x = 0;
	n_posix_loop
	{

		if ( p->tableau[ x ].data == N_FREECELL_NOTHING ) { freespace++; }

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	// [x] : difficult to determine

	int freespace_tableau = 0;

	x = 0;
	n_posix_loop
	{break;

		if ( p->tableau[ N_FREECELL_SUIT_MAX + x ].data == N_FREECELL_NOTHING ) { freespace_tableau++; }

		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return freespace;
}

n_bool
n_freecell_rule_is_movable( n_freecell *p, int index )
{
//return n_false;
//return  n_true;

	// Free cell

	if ( index < N_FREECELL_SUIT_MAX )
	{
		return ( p->tableau[ index ].data != N_FREECELL_NOTHING );
	}
 

	// Empty cell

	if ( p->tableau[ index ].data == N_FREECELL_NOTHING ) { return n_false; }


	// Sequence Checker

	n_bool ret = n_false;

	int sequence = 0;

	int i = 0;
	n_posix_loop
	{

		int f = index + n_freecell_index_upper( i + 0 );
 		int t = index + n_freecell_index_upper( i + 1 );


		// Single : top most of a pile

		if ( t >= N_FREECELL_PILE_ALL ) { return n_true; }


		// Single : top of a stock

		if ( p->tableau[ t ].data == N_FREECELL_NOTHING ) { ret = n_true; break; }


		// Multiple

		if (
			( n_freecell_rule_half_is_ok( p, f, t ) )
			&&
			( n_freecell_rule_rank_is_ok( p, f, t ) )
		)
		{
			sequence++;
		} else {
			break;
		}


		i++;
		if ( f >= N_FREECELL_PILE_ALL ) { break; }
	}


	if ( ( ret )&&( sequence > p->freespace ) ) { ret = n_false; }


	return ret;
}

n_bool
n_freecell_rule_is_puttable( n_freecell *p, int index )
{
//return n_true;

	// [Mechanism]
	//
	//	"index" : .data could have N_FREECELL_NOTHING


	n_posix_loop
	{

		// Cascading : Top to Bottom

		if ( p->tableau[ index ].data != N_FREECELL_NOTHING ) { break; }

		// Bottom-most

		index -= n_freecell_index_upper( 1 );
		if ( index < N_FREECELL_SUIT_MAX ) { return n_true; }
	}


	return (
		( n_freecell_rule_rank_is_ok( p, index, p->drag_index ) )
		&&
		( n_freecell_rule_half_is_ok( p, index, p->drag_index ) )
	);
}

n_bool
n_freecell_rule_stock_is_puttable( n_freecell *p, int f, int t )
{

	n_bool ret = n_false;

	int a = p->stock  [ t ].data;
	int b = p->tableau[ f ].data;
	int c = ( t + 0 ) * N_FREECELL_CARD_UNIT;
	int d = ( t + 1 ) * N_FREECELL_CARD_UNIT;
	int n = N_FREECELL_NOTHING;
//n_game_hwndprintf_literal( " Stock : %d %d %d ", a, b, c );

	if (
		( ( a == n )&&( c == b ) )
		||
		( ( a >= c )&&( ( a + 1 ) < d )&&( ( a + 1 ) == b ) )
	)
	{
		ret = n_true;
	}


	return ret;
}

void
n_freecell_rule_stock( n_freecell *p, int index, int xxx, n_bool *restore )
{

	if ( n_freecell_rule_stock_is_puttable( p, index, xxx ) )
	{

		p->stock  [   xxx ].data  = p->tableau[ index ].data;
		p->tableau[ index ].data  = N_FREECELL_NOTHING;

		p->stock  [   xxx ].chara = p->tableau[ index ].chara;
		p->tableau[ index ].chara = NULL;

		if ( p->tableau[ index ].dnd_onoff )
		{

			if ( n_game_chara_dnd_refcount >= 1 ) { n_game_chara_dnd_refcount--; }

			p->tableau[ index ].dnd_onoff = n_false;
			p->tableau[ index ].dnd_ox    = 0;
			p->tableau[ index ].dnd_oy    = 0;

		}

		n_freecell_chara_erase( p, &p->tableau[ index ] );

		p->restore_count = 0;


		p->drag_index = N_FREECELL_NOTHING;

		n_game_sound_loop( &p->snd_take );

		n_freecell_reposition( p );
		n_freecell_redraw( p );
		n_game_refresh_on();

	} else {

		if ( restore != NULL ) { (*restore) = n_true; }

	}


	return;
}

int
n_freecell_rule_number( n_freecell *p, int data )
{

	if ( data == -1 ) { return 0; }


	int h = N_FREECELL_SUIT_HEARTS   * N_FREECELL_CARD_UNIT;
	int d = N_FREECELL_SUIT_DIAMONDS * N_FREECELL_CARD_UNIT;
	int s = N_FREECELL_SUIT_SPADES   * N_FREECELL_CARD_UNIT;
	int c = N_FREECELL_SUIT_CLUBS    * N_FREECELL_CARD_UNIT;
	int m = N_FREECELL_SUIT_MAX      * N_FREECELL_CARD_UNIT;

	if ( ( data >= h )&&( data < d ) )
	{
		data -= h;
	} else
	if ( ( data >= d )&&( data < s ) )
	{
		data -= d;
	} else
	if ( ( data >= s )&&( data < c ) )
	{
		data -= s;
	} else
	if ( ( data >= c )&&( data < m ) )
	{
		data -= c;
	}


	return data;
}

int
n_freecell_rule_stock_minimum( n_freecell *p )
{

	// [!] : maximum based approach is problematic : dead lock will happen

	int ret = N_FREECELL_CARD_UNIT - 1;

	int x = 0;
	n_posix_loop
	{//break;

		int data = p->stock[ x ].data;
		if ( data != N_FREECELL_NOTHING ) { data = n_freecell_rule_number( p, data ); }

		if ( ret > data ) { ret = data; }

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	return ret + 1;
}

n_bool
n_freecell_rule_stock_minimum_is_puttable( n_freecell *p, int minimum, int index )
{
//n_game_hwndprintf_literal( " %d %d %d %d ", p->stock[ 0 ].data, p->stock[ 1 ].data, p->stock[ 2 ].data, p->stock[ 3 ].data );

	int data = n_freecell_rule_number( p, p->tableau[ index ].data );

	return ( minimum >= data );
}

void
n_freecell_rule_automove( n_freecell *p, int threshold, int target )
{

	int xxx = 0;
	n_posix_loop
	{//break;
//n_freecell_rule_stock( p, i, xxx, NULL );

		if (
			( n_freecell_rule_stock_minimum_is_puttable( p, threshold, target ) )
			&&
			( n_freecell_rule_stock_is_puttable( p, target, xxx ) )
		)
		{
//n_freecell_animation_go( p, target, xxx );
			p->animation_server[ xxx ] = target;
		}

		xxx++;
		if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
	}

	return;
}

n_bool
n_freecell_restore( n_freecell *p, int index )
{

	if ( index != N_FREECELL_NOTHING )
	{

		if ( n_false == n_freecell_rule_is_movable( p, index ) ) { return n_false; }


		n_game_chara_dnd( &p->tableau[ index ], game.hwnd, VK_LBUTTON );
		if ( n_false == p->tableau[ index ].dnd_onoff ) { return n_false; }


		if ( p->drag_index == N_FREECELL_NOTHING )
		{
//n_game_title_literal( " Restore : ON " );


			n_game_sound_loop( &p->snd_take );


			p->drag_index = index;
//n_game_hwndprintf_literal( " %d ", p->drag_index );

			if ( p->drag_index < N_FREECELL_SUIT_MAX )
			{
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : ON : 1 : %d ", p->tableau[ p->drag_index ].x ); }

				p->restore[ 0 ]  = p->tableau[ p->drag_index ];
				p->restore_count = 1;

			} else {
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : ON : 2 " ); }

				int y = 0;
				n_posix_loop
				{//break;

					int upper = p->drag_index + n_freecell_index_upper( y );
					if ( upper >= N_FREECELL_PILE_ALL ) { break; }
					if ( p->tableau[ upper ].data == N_FREECELL_NOTHING ) { break; }

					p->restore[ y ] = p->tableau[ upper ];

					y++;
					if ( y >= N_FREECELL_PILE_SY ) { break; }
				}

				p->restore_count = y;

			}
//n_game_hwndprintf_literal( " %d ", p->restore_count );

			n_freecell_shadow( p );

		} else {
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : ON : Dragging " ); }

			// Multiple Dragging

			if ( p->restore_count >= 2 )
			{
				int i = 1;
				n_posix_loop
				{

					int upper = p->drag_index + n_freecell_index_upper( i );

					p->tableau[ upper ].x = p->tableau[ p->drag_index ].x;
					p->tableau[ upper ].y = p->tableau[ p->drag_index ].y + ( p->cardgen.osy * i );


					i++;
					if ( i >= p->restore_count ) { break; }
				}
			}


			// [!] : change halo color when puttable

//n_win_debug_count( game.hwnd );

			p->color_halo_current = p->cardgen.color_halo;

			n_type_gfx ox = p->cardgen.card_sx / 2;
			n_type_gfx oy = p->cardgen.card_sy / 2;

//static int i = 0;
//n_game_hwndprintf_literal( " %d : %d %d ", i, p->tableau[ p->drag_index ].x, p->tableau[ p->drag_index ].y );
//i++;

			int xxx = 0;
			n_posix_loop
			{//break;

				n_game_chara *f = &p->tableau[ p->drag_index ];
				n_game_chara *t = &p->stock[ xxx ];

//n_game_hwndprintf_literal( " %d %d %d ", f->x, t->x, ( t->x + t->sx ) );

				if (
					( p->restore_count == 1 )
					&&
					( n_game_chara_is_hit_offset( f, t, ox,oy, 0,0 ) )
					&&
					( n_freecell_rule_stock_is_puttable( p, p->drag_index, xxx ) )
				)
				{
//n_posix_debug_literal( " Stock : %d ", xxx );

					p->color_halo_current = p->color_halo_focus;

				}
//break;
				xxx++;
				if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
			}

			int xx = 0;
			n_posix_loop
			{

				n_game_chara *f = &p->tableau[ p->drag_index ];
				n_game_chara *t = &p->tableau[ xx ];

				if (
					( p->restore_count == 1 )
					&&
					( p->tableau[ xx ].data == N_FREECELL_NOTHING )
					&&
					( n_game_chara_is_hit_offset( f, t, ox,oy, 0,0 ) )
				)
				{

					p->color_halo_current = p->color_halo_focus;

					break;
				}

				xx++;
				if ( xx >= N_FREECELL_SUIT_MAX ) { break; }
			}


			int x = 0;
			int y = 0;
			n_posix_loop
			{

				int target = n_freecell_pos2index( x,y );

				if (
					( p->tableau[ target ].data == N_FREECELL_NOTHING )
					&&
					( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ target ], ox,oy, 0,0 ) )
					&&
					( n_freecell_rule_is_puttable( p, target ) )
				)
				{

					p->color_halo_current = p->color_halo_focus;

					break;
				}

				x++;
				if ( x >= N_FREECELL_PILE_SX )
				{

					x = 0;

					y++;
					if ( y >= N_FREECELL_PILE_SY ) { break; }
				}
			}

		}


		// [!] : off for halo effect

		//if ( n_game_chara_is_moved( &p->tableau[ p->drag_index ] ) )
		{
			n_game_refresh_on();
		}

	} else {

		if ( p->drag_index == N_FREECELL_NOTHING ) { return n_false; }

if ( p->debug_onoff ) { n_game_title_literal( " Restore : OFF " ); }


		p->color_halo_current = p->cardgen.color_halo;


		n_bool moved   = n_false;
		n_bool restore = n_false;


		n_type_gfx ox = p->cardgen.card_sx / 2;
		n_type_gfx oy = p->cardgen.card_sy / 2;


		int xxx = 0;
		n_posix_loop
		{

			if (
				( p->restore_count == 1 )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->stock[ xxx ], ox,oy, 0,0 ) )
			)
			{
//n_posix_debug_literal( " Stock : %d ", xxx );

				n_freecell_rule_stock( p, p->drag_index, xxx, &restore );

			}

			xxx++;
			if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
		}


		int xx = 0;
		n_posix_loop
		{
	
			if (
				( p->restore_count == 1 )
				&&
				( p->tableau[ xx ].data == N_FREECELL_NOTHING )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ xx ], ox,oy, 0,0 ) )
			)
			{
//n_game_title_literal( "Collision" );
				moved = n_true;

				break;
			}

			xx++;
			if ( xx >= N_FREECELL_SUIT_MAX ) { break; }
		}


		int x = 0;
		int y = 0;
		n_posix_loop
		{

			if ( moved ) { break; }


			int target = n_freecell_pos2index( x,y );

			if (
				( p->tableau[ target ].data == N_FREECELL_NOTHING )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ target ], ox,oy, 0,0 ) )
				&&
				( n_freecell_rule_is_puttable( p, target ) )
			)
			{
//n_game_title_literal( " Collision " );
				moved = n_true;

				break;
			}

			x++;
			if ( x >= N_FREECELL_PILE_SX )
			{

				x = 0;

				y++;
				if ( y >= N_FREECELL_PILE_SY ) { break; }
			}
		}


		if ( ( moved == n_false )||( restore ) )
		{

			if ( p->drag_index < N_FREECELL_SUIT_MAX )
			{
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : OFF : 1 " ); }

				n_freecell_chara_erase( p, &p->tableau[ p->drag_index ] );

				if ( p->restore_count == 1 )
				{
					p->tableau[ p->drag_index ].data  = p->restore[ 0 ].data;
					p->tableau[ p->drag_index ].chara = p->restore[ 0 ].chara;

					n_game_chara_pos( &p->tableau[ p->drag_index ], p->cardgen.card_sx * p->drag_index, 0 );
					n_game_chara_prv( &p->tableau[ p->drag_index ] );
				}

			} else {
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : OFF : 2 : %d ", restore ); }

				int i = 0;
				n_posix_loop
				{

					int upper = p->drag_index + n_freecell_index_upper( i );

					n_freecell_chara_erase( p, &p->tableau[ upper ] );

					p->tableau[ upper ] = p->restore[ i ];


					i++;
					if ( i >= p->restore_count ) { break; }
				}

			}

		} else
		if ( xx != N_FREECELL_SUIT_MAX )
		{
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : OFF : 3 : %d : %d %d ", p->restore_count, p->drag_index, xx ); }

			// Move

			int f = p->drag_index;
			int t = xx;


			// [!] : erase the last dragged position

			n_freecell_chara_erase( p, &p->tableau[ f ] );


			// [!] : restore x,y,px,py

			n_game_chara_pos( &p->tableau[ f ], p->restore[ 0 ].x, p->restore[ 0 ].y );
			n_game_chara_prv( &p->tableau[ f ] );

			n_game_chara_pos( &p->tableau[ t ], p->cardgen.card_sx * t, 0 );
			n_game_chara_prv( &p->tableau[ t ] );


			p->tableau[ t ].data  = p->tableau[ f ].data;
			p->tableau[ f ].data  = N_FREECELL_NOTHING;

			p->tableau[ t ].chara = p->tableau[ f ].chara;
			p->tableau[ f ].chara = NULL;

		} else {
if ( p->debug_onoff ) { n_game_hwndprintf_literal( " Restore : OFF : 4 : multiple restore : %d %d ", moved, p->restore_count ); }

			// [!] : cascade to the bottom most

			n_posix_loop
			{

				int target = n_freecell_pos2index( x,y );

				if ( p->tableau[ target ].data != N_FREECELL_NOTHING ) { break; }

				y--;
				if ( y < 0 ) { break; }
			}
			y++;

			int i = 0;
			n_posix_loop
			{

				int f = n_freecell_index_upper( i ) + p->drag_index;
				int t = n_freecell_index_upper( i ) + n_freecell_pos2index( x,y );


				// [!] : erase the last dragged position

				n_freecell_chara_erase( p, &p->tableau[ f ] );


				// Move

				p->tableau[ t ].data  = p->tableau[ f ].data;
				p->tableau[ f ].data  = N_FREECELL_NOTHING;

				p->tableau[ t ].chara = p->tableau[ f ].chara;
				p->tableau[ f ].chara = NULL;


				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}


		p->tableau[ p->drag_index ].dnd_onoff = n_false;
		p->drag_index = N_FREECELL_NOTHING;


		n_game_sound_loop( &p->snd_take );

		n_freecell_reposition( p );
		n_freecell_redraw( p );
		n_game_refresh_on();

	}


	return n_true;
}

void
n_freecell_shuffle( n_freecell *p )
{

	if ( p->debug_onoff ) { return; }

	int i = 0;
	n_posix_loop
	{//break;

		int r = n_random_range_hq( N_FREECELL_CARD_ALL );

		int swap        = p->shuffle[ i ];
		p->shuffle[ i ] = p->shuffle[ r ];
		p->shuffle[ r ] = swap;


		i++;
		if ( i >= N_FREECELL_CARD_ALL ) { break; }
	}


	return;
}

void
n_freecell_reset( n_freecell *p, n_bool is_init )
{
//u32 tick = n_posix_tickcount();

	// Reset : once per session

	p->drag_index = N_FREECELL_NOTHING;


	p->is_done = n_false;


	if ( is_init )
	{
		n_game_chara_bulk_zero( p->bottom,   N_FREECELL_PILE_SX  );
		n_game_chara_bulk_zero( p->tableau,  N_FREECELL_PILE_ALL );
		n_game_chara_bulk_zero( p->freecell, N_FREECELL_SUIT_MAX );
		n_game_chara_bulk_zero( p->stock,    N_FREECELL_SUIT_MAX );
	}


	int x,y;


	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }

		n_game_chara_bmp( &p->freecell[ x ], &game.bmp, &p->bmp_freecell, bmp_bg, game.color );
		n_game_chara_src( &p->freecell[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

		p->freecell[ x ].data = N_FREECELL_NOTHING;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }

		if ( is_init )
		{
			n_game_chara_bmp( &p->tableau[ x ], &game.bmp, NULL, bmp_bg, game.color );
			n_game_chara_src( &p->tableau[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

			p->tableau[ x ].data = N_FREECELL_NOTHING;
		} else {
			n_game_chara_src( &p->tableau[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }

		if ( is_init )
		{
			n_game_chara_bmp( &p->stock[ x ], &game.bmp, &p->bmp_stock[ x ], bmp_bg, game.color );
			n_game_chara_src( &p->stock[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

			p->stock[ x ].data = N_FREECELL_NOTHING;
		} else {
			n_game_chara_src( &p->stock[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		p->animation_server[ x ] = N_FREECELL_NOTHING;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }

		n_game_chara_bmp( &p->bottom[ x ], &game.bmp, &p->cardgen.bmp_foundation, bmp_bg, game.color );
		n_game_chara_src( &p->bottom[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

		p->bottom[ x ].data = N_FREECELL_NOTHING;


		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	x = y = 0;
	int i = 0;
	n_posix_loop
	{

		int    target = n_freecell_pos2index( x,y );
		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }

		if ( is_init )
		{
			n_game_chara_bmp( &p->tableau[ target ], &game.bmp, NULL, bmp_bg, game.color );
			n_game_chara_src( &p->tableau[ target ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );


			if ( i < N_FREECELL_CARD_ALL )
			{
				p->tableau[ target ].chara = &p->cardgen.cards[ p->shuffle[ i ] ];
				p->tableau[ target ].data  = p->shuffle[ i ];
				i++;
			} else {
				p->tableau[ target ].chara = NULL;
				p->tableau[ target ].data  = N_FREECELL_NOTHING;
			}
		} else {
			n_game_chara_src( &p->tableau[ target ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}

		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	n_freecell_shadow( p );


	p->color_halo_current = p->cardgen.color_halo;


//n_posix_debug_literal( " %d ", n_posix_tickcount() - tick );
	return;
}

void
n_freecell_input_doubleclick( n_freecell *p )
{
//return;

	if ( p->animation_onoff ) { return; }


	n_posix_bool found = n_posix_false;
	int          index = -1;


	// [!] : freecell area is putting on beginning of tableau[]

	n_type_gfx freecell_x = 0;
	n_posix_loop
	{
		n_game_chara *c = &p->tableau[ freecell_x ];

		if ( c->data != N_FREECELL_NOTHING )
		{
			if ( n_win_is_hovered_offset( game.hwnd, c->x,c->y,c->sx,c->sy ) )
			{
				found = n_posix_true;
				index = freecell_x;
				break;
			}
		}

		freecell_x++;
		if ( freecell_x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	if ( found == n_posix_false )
	{

		n_type_gfx x = 0;
		n_type_gfx y = N_FREECELL_PILE_SY - 1;
		n_posix_loop
		{

			int target = n_freecell_pos2index( x,y );

			n_game_chara *c = &p->tableau[ target ];

			if ( c->data != N_FREECELL_NOTHING )
			{
				if ( n_win_is_hovered_offset( game.hwnd, c->x,c->y,c->sx,c->sy ) )
				{
					found = n_posix_true;
					index = n_freecell_pos2index( x,y );
					break;
				}
				y = 0;
			}

			y--;
			if ( y < 0 )
			{
				y = N_FREECELL_PILE_SY - 1;
				x++;
				if ( x >= N_FREECELL_PILE_SX ) { break; }
			}
		}

		if ( found == n_posix_false ) { return; }
//NSLog( @"found : %d %d", x, y ); return;
	}


	int i  = index;
	int ii = 0;
	n_posix_loop
	{//break;

		if ( n_freecell_rule_stock_is_puttable( p, i, ii ) )
		{
			n_freecell_animation_go( p, i, ii );
		}

		ii++;
		if ( ii >= N_FREECELL_SUIT_MAX ) { break; }
	}


	return;
}

void
n_freecell_input( n_freecell *p )
{
//if ( p->debug_onoff ) { n_game_hwndprintf_literal( " n_freecell_input() : %d ", n_game_refresh_is_off() ); }

	if ( n_false == n_game_refresh_is_off() ) { return; }


	if ( p->animation_onoff ) { return; }


	// DnD

	int dnd = 0;

	int i = N_FREECELL_TABLEAU - 1;
	n_posix_loop
	{

		p->freespace = n_freecell_rule_freespace( p );

		n_bool break_needed = n_false;
		if ( n_freecell_restore( p, i ) ) { break_needed = n_true; }

		dnd += p->tableau[ i ].dnd_onoff;

		if ( break_needed ) { break; }

		i--;
		if ( i < 0 )
		{
			n_freecell_restore( p, N_FREECELL_NOTHING );
			break;
		}
	}

	if ( ( dnd == 0 )&&( n_game_chara_dnd_refcount != 0 ) ) { n_game_chara_dnd_refcount = 0; }


	return;
}

#define N_FREECELL_PILE_ERASE 0
#define N_FREECELL_PILE_DRAW  1

#define n_freecell_pile_erase( p, x,y ) n_freecell_pile( p, x,y, N_FREECELL_PILE_ERASE )
#define n_freecell_pile_draw(  p, x,y ) n_freecell_pile( p, x,y, N_FREECELL_PILE_DRAW  )

void
n_freecell_pile( n_freecell *p, int x, int y, int mode )
{

	// [!] : draw always for alpha blending

	if ( y == 0 )
	{

		if ( mode == N_FREECELL_PILE_ERASE )
		{
			n_game_chara_erase( &p->bottom[ x ] );
		} else {
			n_game_chara_draw ( &p->bottom[ x ] );
//n_bmp_box( &game.bmp, p->bottom[ x ].x,p->bottom[ x ].y, p->bottom[ x ].sx,10, n_game_randomcolor() );
		}

	}


	n_posix_loop
	{

		n_game_chara *c = &p->tableau[ n_freecell_pos2index( x, y + 0 ) ];

		if ( c->data == N_FREECELL_NOTHING ) { break; }


		// [!] : dragged cards are handled as overlay

		if ( p->drag_index != N_FREECELL_NOTHING )
		{
			if ( p->drag_index == n_freecell_pos2index( x,y ) ) { break; }
		}


		if ( mode == N_FREECELL_PILE_ERASE )
		{
			n_game_chara_erase( c );
		} else {
			n_game_chara_draw ( c );
//n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_game_randomcolor() );
		}


		y++;
		if ( y >= N_FREECELL_PILE_SY ) { break; }
	}


	return;
}

typedef struct {

	n_freecell *freecell;
	int         offset, cores;

} n_freecell_pile_draw_all_thread_struct;

DWORD WINAPI
n_freecell_pile_draw_all_thread( LPVOID lpParameter )
{

	n_freecell_pile_draw_all_thread_struct *p = (void*) lpParameter;


	int x = p->offset;
	n_posix_loop
	{

		if ( p->freecell->redraw[ x ] )
		{
			p->freecell->redraw[ x ] = n_false;
			n_freecell_pile_draw( p->freecell, x, 0 );
/*
n_game_chara *c = &p->freecell->tableau[ n_freecell_pos2index( x, 0 ) ];
if ( 0 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 0,200,255 ) ); }
if ( 1 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 255,0,200 ) ); }
if ( 2 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 0,  0,255 ) ); }
if ( 3 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 255,0,  0 ) ); }
*/
		}

		x += p->cores;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return 0;
}

void
n_freecell_pile_draw_all( n_freecell *p )
{

	if ( n_thread_onoff() )
	{

		n_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_true;


		u32 cores = n_posix_min( n_thread_core_count, N_FREECELL_PILE_SX );
		//if ( cores > 1 ) { cores--; }
//n_game_hwndprintf_literal( "%d", cores );


		n_thread                               *h = n_memory_new( cores * sizeof( n_thread                               ) );
		n_freecell_pile_draw_all_thread_struct *f = n_memory_new( cores * sizeof( n_freecell_pile_draw_all_thread_struct ) );

		u32 i = 0;
		n_posix_loop
		{

			n_freecell_pile_draw_all_thread_struct tmp = { p, i, cores };
			n_memory_copy( &tmp, &f[ i ], sizeof( n_freecell_pile_draw_all_thread_struct ) );

			h[ i ] = n_thread_init( n_freecell_pile_draw_all_thread, &f[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( f );


		n_bmp_is_multithread = p_multithread;


		return;
	}


	int x = 0;
	n_posix_loop
	{

		if ( p->redraw[ x ] )
		{
//LARGE_INTEGER li_f; QueryPerformanceCounter( &li_f );

			p->redraw[ x ] = n_false;
			n_freecell_pile_draw( p, x, 0 );

//LARGE_INTEGER li_t; QueryPerformanceCounter( &li_t );
//if ( x == 0 )  { n_game_hwndprintf_literal( " %d ", li_t.QuadPart - li_f.QuadPart ); }
		}


		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return;
}

void
n_freecell_newgame( n_freecell *p )
{

	n_freecell_shuffle( p );
	n_freecell_reset( p, n_true );
	n_freecell_reposition( p );
	n_freecell_redraw( p );

	n_game_refresh_resize();

	return;
}

void
n_freecell_replay( n_freecell *p )
{

	n_freecell_reset( p, n_true );
	n_freecell_reposition( p );
	n_freecell_redraw( p );

	n_game_refresh_resize();

	return;
}

void
n_freecell_flush_background( n_freecell *p )
{

	if ( game.dwm_onoff )
	{
		n_bmp_flush( &game.bmp, game.color );
	} else {
		n_bmp_flush( &game.bmp, p->color_gradient_upper );

		n_type_gfx sx = game.sx;
		n_type_gfx sy = game.sy / 3;
		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
		u32 color = n_bmp_alpha_replace_pixel( p->color_gradient_upper, 0 );
		n_bmp_flush_gradient( &b, color, p->color_gradient_lower, N_BMP_GRADIENT_VERTICAL );
		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, 0, ( sy * 2 ) + ( sy % 2 ) );
		n_bmp_free_fast( &b );
	}

	n_bmp_free( &p->bmp_bg );
	n_bmp_carboncopy( &game.bmp, &p->bmp_bg );


	return;
}

void
n_freecell_style_change( n_freecell *p )
{

	p->is_first = n_true;


	n_project_darkmode();

	n_win_darkmode_hwnd( game.hwnd, n_win_darkmode_onoff );


	// [!] : DWM is off : because of not beautiful

	n_game_dwm_onoff();

	game.dwm_onoff = n_posix_false;

/*
game.dwm_onoff = n_true;
game.color     = 0;
n_game_dwm_on();
*/

	if ( game.dwm_onoff )
	{
		p->        color_init       = n_bmp_black_invisible;
		p->        color_text       = n_bmp_white;
		p->cardgen.color_margin     = n_bmp_black_invisible;
		p->cardgen.color_halo       = n_bmp_argb( 255,128,128,128 );
		p->        color_halo_focus = n_win_dwm_windowcolor_arranged();
	} else
	if ( n_win_darkmode_onoff )
	{
		p->        color_init       = n_bmp_rgb( 10,10,10 );
		p->        color_text       = n_bmp_white;
		p->cardgen.color_margin     = n_bmp_black_invisible;
		p->cardgen.color_halo       = n_bmp_rgb( 10,10,10 );
		p->        color_halo_focus = n_win_dwm_windowcolor_arranged();

	} else {
		p->        color_init       = n_gdi_systemcolor( COLOR_WINDOW     );
		p->        color_text       = n_gdi_systemcolor( COLOR_WINDOWTEXT );
		p->cardgen.color_margin     = n_bmp_white_invisible;
		p->cardgen.color_halo       = n_win_dwm_windowcolor_arranged();
		p->        color_halo_focus = n_bmp_rgb( 255,255,0 );
	}

	p->color_gradient_upper = n_bmp_lightness_replace_pixel( p->cardgen.color_halo,  50 );
	p->color_gradient_lower = n_bmp_lightness_replace_pixel( p->cardgen.color_halo, 100 );


	n_cardgenerator_exit( &p->cardgen );
	n_cardgenerator_init( &p->cardgen, 10 );


	return;
}

void
n_freecell_automove( n_freecell *p )
{

	if ( p->is_init      == n_false ) { return; }
	if ( p->splash_onoff == n_false ) { return; }

	if ( n_false == n_game_refresh_is_off() ) { return; }

	if ( p->animation_onoff ) { return; }


	int threshold = n_freecell_rule_stock_minimum( p );
//n_game_hwndprintf_literal( " %d ", threshold );


	// [!] : Freecell Area

	{

		int x = 0;
		n_posix_loop
		{

			n_game_chara *c = &p->tableau[ x ];
			if ( c->data != N_FREECELL_NOTHING )
			{
				n_freecell_rule_automove( p, threshold, x );
			}

			x++;
			if ( x >= N_FREECELL_SUIT_MAX ) { break; }
		}

	}


	// [!] : Tableau Area

	int x = 0;
	int y = N_FREECELL_PILE_SY - 1;
	n_posix_loop
	{

		int target = n_freecell_pos2index( x, y );

		n_game_chara *c = &p->tableau[ target ];
		if ( c->data != N_FREECELL_NOTHING )
		{
			n_freecell_rule_automove( p, threshold, target );
			y = 0;
		}

		y--;
		if ( y < 0 )
		{

			y = N_FREECELL_PILE_SY - 1;

			x++;
			if ( x >= N_FREECELL_PILE_SX ) { break; }
		}
	}


	return;
}

void
n_freecell_automove_engine( n_freecell *p )
{

//p->debug_automove_count = 0;

	int done = 0;

	int x = 0;
	n_posix_loop
	{

		if (
			( p->animation_onoff == n_false )
			&&
			( p->animation_server[ x ] != N_FREECELL_NOTHING )
		)
		{
			done++;

			n_freecell_animation_go( p, p->animation_server[ x ], x );

			p->animation_server[ x ] = N_FREECELL_NOTHING;

			break;
		}

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

/*
n_game_hwndprintf_literal
(
	" %d : %d %d %d %d ",
	done,
	p->animation_server[ 0 ],
	p->animation_server[ 1 ],
	p->animation_server[ 2 ],
	p->animation_server[ 3 ]
);
*/

//if ( n_win_is_input( VK_SHIFT ) )
//{
	if ( done == 0 )
	{
//n_posix_debug_literal( "" );
		n_freecell_automove( p );
	}
//}
//n_game_hwndprintf_literal( " %d ", p->debug_automove_count );


	return;
}




#define n_freecell_zero( p ) n_memory_zero( p, sizeof( n_freecell ) )

void
n_freecell_init( n_freecell *p )
{

	// Global #1

	n_direct2d_exit();

	n_bmp_safemode = n_bmp_safemode_base = n_false;

	n_win_icon_init_is_ui = n_false;

	n_win_tabletpc_disable( game.hwnd );


	n_freecell_style_change( p );


	// System

	n_game_title_literal( "+++Nonnon Freecell+++" );

	game.sx       = p->cardgen.csx;
	game.sy       = p->cardgen.csy;
	game.fps      = 30;
	game.color    = p->color_init;
	game.on_event = n_freecell_on_event;
	game.on_close = n_freecell_on_close;

	n_game_window_resizable();

	n_freecell_menu_init( p );

	n_game_click_init( &p->doubleclick, VK_LBUTTON );


	// Resource

	n_freecell_watcher( p );

	n_game_sound_zero( &p->snd_mute );
	n_game_sound_init_literal( &p->snd_mute, game.hwnd, NFREECELL_WAV_MUTE );
	n_game_sound_loop( &p->snd_mute );

	n_game_sound_zero( &p->snd_take );
	n_game_sound_init_literal( &p->snd_take, game.hwnd, NFREECELL_WAV_TAKE );

	n_game_sound_zero( &p->snd_done );
	n_game_sound_init_literal( &p->snd_done, game.hwnd, NFREECELL_WAV_DONE );


	// Debug Center

	p->debug_onoff = n_false;//n_true;

	p->shadow_global_onoff = n_true;


	// New Game

	int i = 0;
	n_posix_loop
	{

		p->shuffle[ i ] = N_FREECELL_CARD_ALL - 1 - i;

		i++;
		if ( i >= N_FREECELL_CARD_ALL ) { break; }
	}

	n_freecell_shuffle( p );


	// Debug : Automove

	    i = 0;
	int j = 0;
	while( p->debug_onoff )
	{//break;

		p->shuffle[ i + 3 ] = ( ( 1 + N_FREECELL_SUIT_HEARTS   ) * N_FREECELL_CARD_UNIT ) - 1 - j;
		p->shuffle[ i + 2 ] = ( ( 1 + N_FREECELL_SUIT_DIAMONDS ) * N_FREECELL_CARD_UNIT ) - 1 - j;
		p->shuffle[ i + 1 ] = ( ( 1 + N_FREECELL_SUIT_SPADES   ) * N_FREECELL_CARD_UNIT ) - 1 - j;
		p->shuffle[ i + 0 ] = ( ( 1 + N_FREECELL_SUIT_CLUBS    ) * N_FREECELL_CARD_UNIT ) - 1 - j;

		j++;

		i += 4;
		if ( i >= N_FREECELL_CARD_ALL ) { break; }
	}

	if ( p->debug_onoff ) { p->restore_count = 4; }


	return;
}

void
n_freecell_loop( n_freecell *p )
{

	if ( n_game_refresh_is_resize() )
	{
		if ( p->is_init == n_false )
		{
			return;
		}
	}


	if ( n_win_simplemenu_target != NULL ) { return; }


	n_cardgenerator_loop( &p->cardgen );
	if ( p->is_first )
	{

		p->is_first = n_false;


		// [!] : Freecell Area

		const u32 freecell = n_bmp_argb( 50, 255,255,255 );

		n_cardgenerator_base( &p->cardgen, &p->bmp_freecell, freecell, 0 );

		u32 color_frame  = p->cardgen.color_frame ; p->cardgen.color_frame  = n_bmp_white_invisible;
		u32 color_margin = p->cardgen.color_margin; p->cardgen.color_margin = n_bmp_black_invisible;

		n_cardgenerator_resampler( &p->cardgen, &p->bmp_freecell, n_bmp_black_invisible );

		p->cardgen.color_frame  = color_frame;
		p->cardgen.color_margin = color_margin;


		// [!] : Placeholder

		n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 0 ], &p->bmp_stock[ 0 ] );
		n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 1 ], &p->bmp_stock[ 1 ] );
		n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 2 ], &p->bmp_stock[ 2 ] );
		n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 3 ], &p->bmp_stock[ 3 ] );

		n_cardgenerator_gray( &p->bmp_stock[ 0 ] );
		n_cardgenerator_gray( &p->bmp_stock[ 1 ] );
		n_cardgenerator_gray( &p->bmp_stock[ 2 ] );
		n_cardgenerator_gray( &p->bmp_stock[ 3 ] );

//n_bmp_save_literal( &p->cardgen.bmp_halo, "halo.bmp" );
//n_bmp_save_literal( &p->bmp_freecell, "cell.bmp" );

//n_bmp_save_literal( &p->cardgen.cards[ ( N_CARDGENERATOR_CARD_UNIT * 1 ) + 0 ], "diamond_1.bmp" );
//n_bmp_save_literal( &p->cardgen.cards[ ( N_CARDGENERATOR_CARD_UNIT * 1 ) + 1 ], "diamond_2.bmp" );
//n_bmp_save_literal( &p->cardgen.cards[ ( N_CARDGENERATOR_CARD_UNIT * 1 ) + 2 ], "diamond_3.bmp" );
	}


	// Splash Screen

	if ( p->splash_onoff == n_false )
	{

		if ( NULL == N_BMP_PTR( &p->transition_bmp_old ) )
		{

			p->transition_type = N_BMP_UI_TRANSITION_NOTHING;
			if ( n_win_fade_is_on() ) { p->transition_type = N_BMP_UI_TRANSITION_FADE; }

			n_freecell_reset( p, n_true );
			n_freecell_reposition( p );
			n_freecell_redraw( p );

			n_bmp_new_fast( &p->transition_bmp_old, game.sx,game.sy );
			n_bmp_new_fast( &p->transition_bmp_new, game.sx,game.sy );

			n_freecell_splashscreen( p, &p->transition_bmp_old );
//n_bmp_carboncopy( &p->transition_bmp_old, &p->transition_bmp_new );

			p->is_init = p->splash_onoff =  n_true;

			n_freecell_flush_background( p );
			n_freecell_loop( p );
			n_bmp_flush_fastcopy( &game.bmp, &p->transition_bmp_new );

			p->is_init = p->splash_onoff = n_false;
//n_win_exedir2curdir();
//n_bmp_save_literal( &p->transition_bmp_new, "ret.bmp" );
		}

		if ( game.dwm_onoff )
		{
			n_game_clear( game.color );
			n_bmp_flush_blendcopy( &p->transition_bmp_old, &game.bmp, (n_type_real) p->transition_percent * 0.01 );
		}

		n_bool ret = n_bmp_ui_transition
		(
			&game.bmp,
			&p->transition_bmp_old,
			&p->transition_bmp_new,
			N_FREECELL_FADE_MSEC,
			&p->transition_percent,
			p->transition_type
		);

		if ( ret )
		{

			p->splash_onoff = n_true;

			n_bmp_free( &p->transition_bmp_old );
			n_bmp_free( &p->transition_bmp_new );

			p->is_init = n_true;

			if ( game.dwm_onoff )
			{
				n_game_refresh_resize();
			} else {
				n_game_refresh_on();
			}

		} else {

			n_game_refresh_on();

			return;
		}

	}


	// Resize

	if ( n_game_refresh_is_resize() )
	{
//n_game_title_literal( "Resize" );

		n_freecell_flush_background( p );

		p->cardgen.csx = game.sx;
		p->cardgen.csy = game.sy;

		if ( p->animation_onoff )
		{
			n_freecell_animation_go( p, p->animation_index_f, p->animation_index_t );
		}

		n_freecell_reposition( p );
		n_freecell_redraw( p );

		n_game_refresh_on();

	}


	// Input
//n_game_hwndprintf_literal( " %d ", p->animation_onoff );

	if ( n_game_click_double( &p->doubleclick ) )
	{
		n_freecell_input_doubleclick( p );
	} else
	if ( n_false == ( p->doubleclick.phase == N_GAME_CLICK_PHASE_DOUBLE ) )
	{
		n_freecell_input( p );
	}


	// Automove

	n_freecell_automove_engine( p );


//n_game_hwndprintf_literal( " %d %d %d %d ", p->stock[ 0 ].data, p->stock[ 1 ].data, p->stock[ 2 ].data, p->stock[ 3 ].data );

	if ( p->is_done == n_false )
	{
		if (
			( p->stock[ 0 ].data == 12 )
			&&
			( p->stock[ 1 ].data == 25 )
			&&
			( p->stock[ 2 ].data == 38 )
			&&
			( p->stock[ 3 ].data == 51 )
		)
		{
			p->is_done = n_true;
			n_game_sound_loop( &p->snd_done );
		}
	}


	// Auto Animation

	if ( p->animation_onoff )
	{
//static int i = 0;
//n_game_hwndprintf_literal( " %d : %f %f ", i, p->animation_step_x, p->animation_step_y );
//i++;
		n_type_gfx ox = p->cardgen.card_sx / 2;
		n_type_gfx oy = p->cardgen.card_sy / 2;

		if ( n_game_chara_is_hit_offset( &p->tableau[ p->animation_index_f ], &p->stock[ p->animation_index_t ], ox,oy, 0,0 ) )
		{
			p->animation_onoff = n_false;
			p->drag_index      = N_FREECELL_NOTHING;
			n_freecell_rule_stock( p, p->animation_index_f, p->animation_index_t, NULL );

			n_freecell_automove_engine( p );
		} else {
			n_game_chara *c = &p->tableau[ p->animation_index_f ];

			p->animation_base_x += p->animation_step_x;
			p->animation_base_y += p->animation_step_y;

			c->x = (n_type_gfx) p->animation_base_x;
			c->y = (n_type_gfx) p->animation_base_y;
		}

		n_freecell_redraw( p );
		n_game_refresh_on();

	}




	// Watcher

	{

		n_type_gfx cursor_x; n_win_cursor_position_relative( game.hwnd, &cursor_x, NULL );

		n_bool redraw = n_false;

		if ( cursor_x < ( game.sx / 2 ) )
		{
			if ( p->watcher != N_FREECELL_WATCHER_L )
			{
				p->watcher = N_FREECELL_WATCHER_L;
				redraw = n_true;
			}
		} else {
			if ( p->watcher != N_FREECELL_WATCHER_R )
			{
				p->watcher = N_FREECELL_WATCHER_R;
				redraw = n_true;
			}
		}

		if ( redraw ) { n_game_refresh_on(); }

	}


	if ( n_game_refresh_is_on() )
	{

//n_game_hwndprintf_literal( "%d", p->restore_count );


		// Erase

		// [!] : Safe Mode

		//n_freecell_redraw( p );
		//n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


		// [!] : Fast Mode

		if ( p->drag_index != N_FREECELL_NOTHING )
		{

			n_freecell_redraw_detect( p );

			int i = 0;
			n_posix_loop
			{

				int upper = p->drag_index + n_freecell_index_upper( i );

				n_game_chara *c = &p->tableau[ upper ];

				n_freecell_chara_erase( p, c );

				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}


		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_erase( &p->freecell[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}

		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_erase( &p->stock[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}

		n_freecell_shadow_erase( p );

		{

			int x = 0;
			n_posix_loop
			{


				if ( p->redraw[ x ] ) { n_freecell_pile_erase( p, x, 0 ); }


				x++;
				if ( x >= N_FREECELL_PILE_SX ) { break; }
			}

		}


		// Draw

		{

			n_type_gfx sx = N_BMP_SX( &p->bmp_neko_l );
			n_type_gfx sy = N_BMP_SX( &p->bmp_neko_l );
			n_type_gfx tx = (            game.sx / 2 ) - ( sx / 2 );
			n_type_gfx ty = ( p->cardgen.card_sy / 2 ) - ( sy / 2 );

			if ( p->watcher == N_FREECELL_WATCHER_L )
			{
				n_bmp_transcopy( &p->bmp_neko_l, &game.bmp, 0,0,sx,sy, tx,ty );
			} else {
				n_bmp_transcopy( &p->bmp_neko_r, &game.bmp, 0,0,sx,sy, tx,ty );
			}

		}

		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_draw( &p->freecell[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}

		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_draw( &p->stock[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}


		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_draw( &p->tableau[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}


		n_freecell_pile_draw_all( p );


		if ( p->drag_index != N_FREECELL_NOTHING )
		{

			n_freecell_shadow_draw( p );

			int i = 0;
			n_posix_loop
			{//break;

				int upper = p->drag_index + n_freecell_index_upper( i );

				n_game_chara *c = &p->tableau[ upper ];

				n_freecell_chara_draw( p, c );
//n_bmp_box( &game.bmp, c->x, c->y, c->sx, c->sy, n_bmp_rgb( 0,200,255 ) );

				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}


		n_game_refresh_on();

	}


	return;
}

void
n_freecell_exit( n_freecell *p )
{

	n_cardgenerator_exit( &p->cardgen );


	int i = 0;
	n_posix_loop
	{

		n_bmp_free( &p->bmp_stock[ i ] );

		i++;
		if ( i >= N_FREECELL_SUIT_MAX ) { break; }
	}


	n_bmp_free_fast( &p->bmp_bg       );
	n_bmp_free_fast( &p->bmp_freecell );
	n_bmp_free_fast( &p->bmp_neko_l   );
	n_bmp_free_fast( &p->bmp_neko_r   );

	i = 0;
	n_posix_loop
	{

		n_bmp_free_fast( &p->shadow_bmp_cache[ i ] );

		i++;
		if ( i >= N_FREECELL_SHADOW_COUNT ) { break; }
	}


	n_game_sound_exit( &p->snd_mute );
	n_game_sound_exit( &p->snd_take );
	n_game_sound_exit( &p->snd_done );


	n_freecell_zero( p );


	//n_memory_debug_refcount();


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_freecell_zero( &freecell );
	n_freecell_init( &freecell );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_freecell_exit( &freecell );
		n_freecell_init( &freecell );
		n_game_reset();
	}

	n_freecell_loop( &freecell );


	return;
}

void
n_game_exit( void )
{

	n_freecell_exit( &freecell );


	return;
}

#endif // #ifndef N_GAMECONSOLE

