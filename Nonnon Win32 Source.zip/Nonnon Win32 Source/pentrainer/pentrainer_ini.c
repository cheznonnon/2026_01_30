// Nonnon Pen Trainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_pentrainer_ini_read( void )
{

	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );


	n_pentrainer_wintab_onoff = n_ini_value_int_literal( &ini, N_PENTRAINER_INISECT, "wintab", 1 );

	n_ini_value_str_literal( &ini, N_PENTRAINER_INISECT, "font", "FixedSys", n_pentrainer_font, LF_FACESIZE );
	n_ini_value_str_literal( &ini, N_PENTRAINER_INISECT, "mode",         "", n_pentrainer_mode,         100 );

	if ( n_string_is_empty( n_pentrainer_mode ) ) { n_pentrainer_mode_init(); }


	n_ini_free( &ini );


	return;
}

// internal
void
n_pentrainer_ini_write( void )
{

	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );

	n_ini_section_add_literal( &ini, N_PENTRAINER_INISECT );

	n_ini_key_add_int_literal( &ini, N_PENTRAINER_INISECT, "wintab", n_pentrainer_wintab_onoff );
	n_ini_key_add_str_literal( &ini, N_PENTRAINER_INISECT, "font  ", n_pentrainer_font );
	n_ini_key_add_str_literal( &ini, N_PENTRAINER_INISECT, "mode  ", n_pentrainer_mode );

	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	n_explorer_refresh( n_false );


	return;
}

