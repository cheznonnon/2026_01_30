// NonnonGame
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




LRESULT CALLBACK
n_ngame_on_event( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_ngame *p = &ngame;


	switch( msg ) {


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
			n_vfw_pause ( &N_NGAME_SND_BGM.vfw );
		} else {
			n_vfw_resume( &N_NGAME_SND_BGM.vfw );
			//N_NGAME_SND_BGM.tmr = 0;
			//n_ngame_bgm( p );
		}

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


