// NonnonGame
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html

// Partial File




void
n_ngame_smooth_debug_data( n_ngame *p, int data )
{

	n_game_hwndprintf_literal
	(
		" U:%d D:%d L:%d R:%d",
		( 0 != ( data & N_NGAME_OBJ_MOVE_U ) ),
		( 0 != ( data & N_NGAME_OBJ_MOVE_D ) ),
		( 0 != ( data & N_NGAME_OBJ_MOVE_L ) ),
		( 0 != ( data & N_NGAME_OBJ_MOVE_R ) )
	);


	return;
}

void
n_ngame_smooth_shuffle( n_ngame *p, int i )
{

	n_type_gfx rnd_x = n_game_random( n_posix_max_n_type_gfx( 0, p->csx - p->unit ) );
	n_type_gfx rnd_y = n_game_random( n_posix_max_n_type_gfx( 0, p->csy - p->unit ) );

	n_game_chara_prv( &p->obj[ i ] );
	n_game_chara_pos( &p->obj[ i ], rnd_x, rnd_y );

	p->obj[ N_NGAME_OBJ_ELEM_U + i ] = p->obj[ i ];
	p->obj[ N_NGAME_OBJ_ELEM_D + i ] = p->obj[ i ];
	p->obj[ N_NGAME_OBJ_ELEM_L + i ] = p->obj[ i ];
	p->obj[ N_NGAME_OBJ_ELEM_R + i ] = p->obj[ i ];


	return;
}

void
n_ngame_smooth_shuffle_all( n_ngame *p )
{

	int i = 0;
	n_posix_loop
	{

		n_ngame_smooth_shuffle( p, i );

		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}


	return;
}

void
n_ngame_smooth_srcx_init( n_ngame *p )
{

	int i = 0;
	n_posix_loop
	{

		n_type_gfx srcx = p->unit * i;

		p->obj[ N_NGAME_OBJ_ELEM_0 + i ].srcx = srcx;
		p->obj[ N_NGAME_OBJ_ELEM_U + i ].srcx = srcx;
		p->obj[ N_NGAME_OBJ_ELEM_D + i ].srcx = srcx;
		p->obj[ N_NGAME_OBJ_ELEM_L + i ].srcx = srcx;
		p->obj[ N_NGAME_OBJ_ELEM_R + i ].srcx = srcx;

		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}

	return;
}

void
n_ngame_smooth_collision( n_ngame *p )
{

	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_0, &N_NGAME_OBJ_BLOCK_0 );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_0, &N_NGAME_OBJ_BLOCK_U );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_0, &N_NGAME_OBJ_BLOCK_D );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_0, &N_NGAME_OBJ_BLOCK_L );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_0, &N_NGAME_OBJ_BLOCK_R );

	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_U, &N_NGAME_OBJ_BLOCK_0 );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_U, &N_NGAME_OBJ_BLOCK_U );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_U, &N_NGAME_OBJ_BLOCK_D );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_U, &N_NGAME_OBJ_BLOCK_L );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_U, &N_NGAME_OBJ_BLOCK_R );

	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_D, &N_NGAME_OBJ_BLOCK_0 );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_D, &N_NGAME_OBJ_BLOCK_U );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_D, &N_NGAME_OBJ_BLOCK_D );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_D, &N_NGAME_OBJ_BLOCK_L );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_D, &N_NGAME_OBJ_BLOCK_R );

	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_L, &N_NGAME_OBJ_BLOCK_0 );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_L, &N_NGAME_OBJ_BLOCK_U );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_L, &N_NGAME_OBJ_BLOCK_D );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_L, &N_NGAME_OBJ_BLOCK_L );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_L, &N_NGAME_OBJ_BLOCK_R );

	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_R, &N_NGAME_OBJ_BLOCK_0 );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_R, &N_NGAME_OBJ_BLOCK_U );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_R, &N_NGAME_OBJ_BLOCK_D );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_R, &N_NGAME_OBJ_BLOCK_L );
	n_ngame_object_collision( p, &N_NGAME_OBJ_CHARA_R, &N_NGAME_OBJ_BLOCK_R );


	return;
}

void
n_ngame_smooth_draw( n_ngame *p )
{

	// [!] : reverse overlay order

	n_game_chara_draw( &N_NGAME_OBJ_PANEL_0 );


	if ( n_false == n_ngame_is_inner( p, &N_NGAME_OBJ_BLOCK_0 ) )
	{
		n_game_chara_draw( &N_NGAME_OBJ_BLOCK_U );
		n_game_chara_draw( &N_NGAME_OBJ_BLOCK_D );
		n_game_chara_draw( &N_NGAME_OBJ_BLOCK_L );
		n_game_chara_draw( &N_NGAME_OBJ_BLOCK_R );
	}

	n_game_chara_draw( &N_NGAME_OBJ_BLOCK_0 );


//n_game_hwndprintf_literal( " %d ", n_ngame_is_inner( p, &N_NGAME_OBJ_CHARA_0 ) );
	if ( n_false == n_ngame_is_inner( p, &N_NGAME_OBJ_CHARA_0 ) )
	{

		const n_bool debug = n_false;

		const u32 color_u = n_bmp_rgb( 255,  0,  0 );
		const u32 color_d = n_bmp_rgb(   0,255,  0 );
		const u32 color_l = n_bmp_rgb(   0,  0,255 );
		const u32 color_r = n_bmp_rgb( 255,  0,255 );

		n_ngame_chara_draw( p, &N_NGAME_OBJ_CHARA_U, debug, color_u );
		n_ngame_chara_draw( p, &N_NGAME_OBJ_CHARA_D, debug, color_d );
		n_ngame_chara_draw( p, &N_NGAME_OBJ_CHARA_L, debug, color_l );
		n_ngame_chara_draw( p, &N_NGAME_OBJ_CHARA_R, debug, color_r );

	}

	n_game_chara_draw( &N_NGAME_OBJ_CHARA_0 );


	n_game_refresh_on();

	return;
}

void
n_ngame_smooth_edgelooping( n_ngame *p )
{

	int i = 0;
	n_posix_loop
	{

		int             u = N_NGAME_OBJ_ELEM_U;
		int             d = N_NGAME_OBJ_ELEM_D;
		int             l = N_NGAME_OBJ_ELEM_L;
		int             r = N_NGAME_OBJ_ELEM_R;
		n_game_chara *c_0 = &p->obj[ 0 + i ];
		n_game_chara *c_u = &p->obj[ u + i ];
		n_game_chara *c_d = &p->obj[ d + i ];
		n_game_chara *c_l = &p->obj[ l + i ];
		n_game_chara *c_r = &p->obj[ r + i ];

//if ( i == 0 ) { n_game_hwndprintf_literal( " %d %d ", c_0->x, c_0->y ); }

		int data = 0;


		// [!] : X

		if ( c_0->x < -c_0->sx )
		{
			data |= N_NGAME_OBJ_MOVE_L;
			n_game_chara_pos( c_0, c_r->x, c_r->y );
		} else
		if ( c_0->x < 0 )
		{
			data |= N_NGAME_OBJ_MOVE_L;
			n_game_chara_pos( c_r, p->csx + c_0->x, c_0->y );
		} else {
			n_game_chara_pos( c_r, c_0->x, c_0->y );
		}

		if ( c_0->x > p->csx )
		{
			data |= N_NGAME_OBJ_MOVE_R;
			n_game_chara_pos( c_0, c_l->x, c_l->y );
		} else
		if ( ( c_0->x + c_0->sx ) > p->csx )
		{
			data |= N_NGAME_OBJ_MOVE_R;
			n_game_chara_pos( c_l, c_0->x - p->csx, c_0->y );
		} else {
			n_game_chara_pos( c_l, c_0->x, c_0->y );
		}


		// [!] : Y

		if ( c_0->y < -c_0->sy )
		{
			data |= N_NGAME_OBJ_MOVE_U;
			if ( data & N_NGAME_OBJ_MOVE_L )
			{
				n_game_chara_pos( c_0, c_r->x, c_d->y );
			} else
			if ( data & N_NGAME_OBJ_MOVE_R )
			{
				n_game_chara_pos( c_0, c_l->x, c_d->y );
			} else {
				n_game_chara_pos( c_0, c_d->x, c_d->y );
			}
		} else
		if ( c_0->y < 0 )
		{
			data |= N_NGAME_OBJ_MOVE_U;
			n_game_chara_pos( c_d, c_0->x, p->csy + c_0->y );
		} else {
			n_game_chara_pos( c_d, c_0->x, c_0->y );
		}

		if ( c_0->y > p->csy )
		{
			data |= N_NGAME_OBJ_MOVE_D;
			if ( data & N_NGAME_OBJ_MOVE_L )
			{
				n_game_chara_pos( c_0, c_r->x, c_u->y );
			} else
			if ( data & N_NGAME_OBJ_MOVE_R )
			{
				n_game_chara_pos( c_0, c_l->x, c_u->y );
			} else {
				n_game_chara_pos( c_0, c_u->x, c_u->y );
			}
		} else
		if ( ( c_0->y + c_0->sy ) > p->csy )
		{
			data |= N_NGAME_OBJ_MOVE_D;
			n_game_chara_pos( c_u, c_0->x, c_0->y - p->csy );
		} else {
			n_game_chara_pos( c_u, c_0->x, c_0->y );
		}

//if ( i == 0 ) { n_ngame_smooth_debug_data( p, data ); }


		// [!] : corner

		n_bool debug  = n_false;//n_true;
		int    target = 0;

		if ( data & N_NGAME_OBJ_MOVE_U )
		{
			if ( data & N_NGAME_OBJ_MOVE_L )
			{
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " UL " ); }
				n_game_chara_pos( c_l, p->csx + c_0->x, p->csy + c_0->y );
			} else
			if ( data & N_NGAME_OBJ_MOVE_R )
			{
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " UR " ); }
				n_game_chara_pos( c_r, c_0->x - p->csx, p->csy + c_0->y );
			} else {
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " U  " ); }
			}
		} else
		if ( data & N_NGAME_OBJ_MOVE_D )
		{
			if ( data & N_NGAME_OBJ_MOVE_L )
			{
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " DL " ); }
				n_game_chara_pos( c_l, p->csx + c_0->x, c_0->y - p->csy );
			} else
			if ( data & N_NGAME_OBJ_MOVE_R )
			{
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " DR " ); }
				n_game_chara_pos( c_r, c_0->x - p->csx, c_0->y - p->csy );
			} else {
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " D  " ); }
			}
		} else {
			if ( data & N_NGAME_OBJ_MOVE_L )
			{
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " L  " ); }
			} else
			if ( data & N_NGAME_OBJ_MOVE_R )
			{
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " R  " ); }
			} else {
if ( ( debug )&&( i == target ) ) { n_game_hwndprintf_literal( " NA " ); }
			}
		}


		// [Needed] : used when half-looped and pushed from another side

		if ( i == 1 )
		{
//n_game_hwndprintf_literal( " NA " );

			if ( data == N_NGAME_OBJ_MOVE_U )
			{

				n_game_chara *f = &N_NGAME_OBJ_CHARA_0;
				n_game_chara *t = &N_NGAME_OBJ_BLOCK_D;

				if ( n_game_chara_is_hit( f, t ) )
				{
					int            swap_y =                  t->y;
					                 t->y = N_NGAME_OBJ_BLOCK_0.y;
					N_NGAME_OBJ_BLOCK_0.y =                swap_y;
				}

			}

			if ( data == N_NGAME_OBJ_MOVE_D )
			{

				n_game_chara *f = &N_NGAME_OBJ_CHARA_0;
				n_game_chara *t = &N_NGAME_OBJ_BLOCK_U;

				if ( n_game_chara_is_hit( f, t ) )
				{
					int            swap_y =                  t->y;
					                 t->y = N_NGAME_OBJ_BLOCK_0.y;
					N_NGAME_OBJ_BLOCK_0.y =                swap_y;
				}

			}

			if ( data == N_NGAME_OBJ_MOVE_L )
			{
//n_game_hwndprintf_literal( " N_NGAME_OBJ_MOVE_L " );
//n_game_hwndprintf_literal( " 0:%d : L:%d : R:%d ", N_NGAME_OBJ_BLOCK_0.x, N_NGAME_OBJ_BLOCK_L.x, N_NGAME_OBJ_BLOCK_R.x );

				n_game_chara *f = &N_NGAME_OBJ_CHARA_0;
				n_game_chara *t = &N_NGAME_OBJ_BLOCK_R;

				if ( n_game_chara_is_hit( f, t ) )
				{
//n_game_hwndprintf_literal( " N_NGAME_OBJ_MOVE_L : hit " );
					int            swap_x =                  t->x;
					                 t->x = N_NGAME_OBJ_BLOCK_0.x;
					N_NGAME_OBJ_BLOCK_0.x =                swap_x;
				}

			}

			if ( data == N_NGAME_OBJ_MOVE_R )
			{

				n_game_chara *f = &N_NGAME_OBJ_CHARA_0;
				n_game_chara *t = &N_NGAME_OBJ_BLOCK_L;

				if ( n_game_chara_is_hit( f, t ) )
				{
					int            swap_x =                  t->x;
					                 t->x = N_NGAME_OBJ_BLOCK_0.x;
					N_NGAME_OBJ_BLOCK_0.x =                swap_x;
				}

			}

			if (
				( data == ( N_NGAME_OBJ_MOVE_U | N_NGAME_OBJ_MOVE_L ) )
				||
				( data == ( N_NGAME_OBJ_MOVE_U | N_NGAME_OBJ_MOVE_R ) )
				||
				( data == ( N_NGAME_OBJ_MOVE_D | N_NGAME_OBJ_MOVE_L ) )
				||
				( data == ( N_NGAME_OBJ_MOVE_D | N_NGAME_OBJ_MOVE_R ) )
			)
			{

				n_game_chara *f = &N_NGAME_OBJ_CHARA_0;
				n_game_chara *t = &N_NGAME_OBJ_BLOCK_0;
				n_game_chara *u = &N_NGAME_OBJ_BLOCK_U;
				n_game_chara *d = &N_NGAME_OBJ_BLOCK_D;
				n_game_chara *l = &N_NGAME_OBJ_BLOCK_L;
				n_game_chara *r = &N_NGAME_OBJ_BLOCK_R;

				if ( n_game_chara_is_hit( f, u ) )
				{
//n_game_hwndprintf_literal( " U " );
					n_game_chara_pos( t, c_u->x, c_u->y );
				}

				if ( n_game_chara_is_hit( f, d ) )
				{
//n_game_hwndprintf_literal( " D " );
					// [Patch] : I don't know why

					if ( n_game_chara_is_hit( f, t ) )
					{
						n_game_chara_pos( t, c_d->x, c_d->y );
					}
				}

				if ( n_game_chara_is_hit( f, l ) )
				{
//n_game_hwndprintf_literal( " L " );
					n_game_chara_pos( t, c_l->x, c_l->y );
				}

				if ( n_game_chara_is_hit( f, r ) )
				{
//n_game_hwndprintf_literal( " R " );
					n_game_chara_pos( t, c_r->x, c_r->y );
				}

			}

		}


		i++;
		if ( i >= N_NGAME_OBJ_UNIT ) { break; }
	}


	return;
}


