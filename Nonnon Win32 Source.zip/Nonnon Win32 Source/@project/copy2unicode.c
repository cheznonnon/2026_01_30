// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"




int
main( void )
{

	n_posix_char *f[] = {
		"Z:\\c\\@toybox\\directx\\Nonnon Direct2D1 DLL\\Nonnon Direct2D1 DLL.dll",
		//"Z:\\c\\@toybox\\gdiplus\\Nonnon GDIPlus DLL.dll",
		"Z:\\c\\arcdrop\\arcdrop.exe",
		"Z:\\c\\gameconsole\\gameconsole.exe",
		"Z:\\c\\nonnonapps\\nonnonapps.exe",
		NULL
	};

	n_posix_char *t = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_unicode";


	int i = 0;
	while( 1 )
	{

		n_posix_char name[ N_PATH_MAX ]; n_path_name( f[ i ], name ); n_path_maker( t, name, name );

		n_filer_merge( f[ i ], name );
//n_posix_debug_literal( "%s\n%s", f[ i ], name );

		i++;
		if ( f[ i ] == NULL ) { break; }
	}


	return 0;
}

