// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"

#include "../nonnon/win32/win/commandline.c"




// internal
n_posix_bool
n_mac_tools_dotfiles_remover( const n_posix_char *folder )
{

	n_posix_bool ret = n_posix_false;


	if ( folder != NULL )
	{

		n_posix_DIR *dp = n_posix_opendir_nodot( folder );
		if ( dp == NULL ) { return n_posix_true; }


		// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

		n_type_int cch = n_posix_strlen( folder ) + 1;

		n_posix_loop
		{//break;

			n_posix_dirent *dirent = n_posix_readdir( dp );
			if ( dirent == NULL ) { break; }

			n_posix_char *item = n_string_path_new( cch + n_posix_strlen( dirent->d_name ) );
			n_string_path_make( folder, dirent->d_name, item );

			if ( n_posix_stat_is_dir( item ) )
			{
				n_mac_tools_dotfiles_remover( item );

				if ( dirent->d_name[ 0 ] == n_posix_literal( '.' ) )
				{
					n_filer_remove( item );
				}
			} else
			if ( dirent->d_name[ 0 ] == n_posix_literal( '.' ) )
			{
				n_filer_remove( item );
			}

			n_string_path_free( item );

		}


		n_posix_closedir( dp );


//n_posix_debug_literal( "%d %d", d->dir, d->file );

	}


	return ret;
}




int
main( void )
{

	// Phase 1 : shared

	n_win_exedir2curdir();

	n_posix_char cmdline[ N_PATH_MAX ]; n_win_commandline( cmdline );
	n_posix_char    exec[ N_PATH_MAX ];


	// Phase 2 : remove dotfiles

	n_mac_tools_dotfiles_remover( cmdline );


	// Phase 3 : set time stamp zero

	n_posix_char *timestamp = "Z:\\c\\@project\\timestamp.exe";

	n_posix_sprintf_literal( exec, "%s %s", timestamp, cmdline );
	n_win_execute( exec, SW_HIDE, n_posix_true );


	// Phase 4 : compress with UPX : currently off

	//n_posix_sprintf_literal( exec, "upx_pack.exe %s", cmdline );
	//n_win_execute( exec, SW_HIDE, n_posix_true );


	// Phase 5 : compress with ArcDrop

	n_posix_char *arcdrop = "Z:\\freewares\\nonnon_win_x64\\arcdrop.exe";

	n_posix_sprintf_literal( exec, "%s %s", arcdrop, cmdline );
	n_win_execute( exec, SW_HIDE, n_posix_true );


	return 0;
}

