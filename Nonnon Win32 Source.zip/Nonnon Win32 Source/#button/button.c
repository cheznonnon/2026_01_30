// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_button button;
	static n_win_button icobtn;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();
n_win_darkmode_onoff = n_posix_true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "MAIN_ICON", "" );


		n_win_button_zero( &button );
		n_win_button_init( &button, hwnd, n_posix_literal( "Button" ), PBS_NORMAL );

		n_win_button_zero( &icobtn );
		n_win_button_init( &icobtn, hwnd, n_posix_literal( "" ), PBS_NORMAL );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

//n_win_check_onoff( &check, n_false );

		{
			n_win_exedir2curdir();

			n_posix_char *name_ico = n_posix_literal( "../nonnon/project/neko.multi.ico" );
			icobtn.hicon = n_win_icon_init( name_ico, 0, N_WIN_ICON_INIT_OPTION_DEFAULT );
		}


		// Size

		{

			n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

			s32 ctl,ico; n_win_stdsize( hwnd, &ctl, &ico, NULL );

			s32 center_x = ( 200 - 100 ) / 2;
			s32 center_y = ( 200 - ctl ) / 2;

			button.maclike_onoff = n_posix_true;
			n_win_button_move( &button, center_x, center_y - ctl, 100, ctl, n_true );

			center_x = ( 200 - ico ) / 2;
			center_y = ( 200 - ctl ) / 2;

			icobtn.maclike_onoff = n_posix_false;
			n_win_move( icobtn.hwnd, center_x, center_y + ctl, ico, ico, n_true );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_button_exit( &button );
		n_win_button_exit( &icobtn );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &button );
	n_win_button_proc( hwnd, msg, wparam, lparam, &icobtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


