// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/registry.c"




void
n_watchcat_fullcoloricon_set( void )
{

	// [Mechanism] : when this value is not exist
	//
	//	Win95    : 16 colors
	//	WinNT4.0 : 16 colors
	//	WinVista : always full color
	//
	//	"16"     : full color
	//	"4"      : index color


	if ( n_sysinfo_version_vista_or_later() ) { return; }


	n_posix_char *subkey  = n_posix_literal( "Control Panel\\Desktop\\WindowMetrics" );
	n_posix_char *section = n_posix_literal( "Shell Icon BPP" );


	n_posix_char str[ 100 ]; n_string_zero( str, 100 );


	n_registry_read( HKEY_CURRENT_USER, subkey, section, str, 100 * sizeof( n_posix_char ) );

	if ( 16 == n_posix_atoi( str ) ) { return; }


	n_string_copy_literal( "16", str );

	n_registry_write( HKEY_CURRENT_USER, subkey, section, REG_SZ, str, 0 );


	return;
}


