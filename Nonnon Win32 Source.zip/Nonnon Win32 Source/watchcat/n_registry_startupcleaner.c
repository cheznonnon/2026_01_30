// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/ini.c"




// internal
void
n_registry_startupcleaner( void )
{

	const int maxlength = 256;

	const n_posix_char *smwc = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion" );

	const HKEY hive[] = {

		HKEY_CURRENT_USER,
		HKEY_LOCAL_MACHINE

	};

	const n_posix_char *hivestr[] = {

		n_posix_literal( "HKEY_CURRENT_USER"  ),
		n_posix_literal( "HKEY_LOCAL_MACHINE" )

	};

	const n_posix_char *runstr[] = {

		n_posix_literal( "Run"             ),
		n_posix_literal( "RunOnce"         ),
		n_posix_literal( "RunOnceEx"       ),
		n_posix_literal( "RunServices"     ),
		n_posix_literal( "RunServicesOnce" )

	};


	HKEY  hkey;
	LONG  ret;

	DWORD i, ii;
	DWORD lvalbyte, rvalbyte;

	n_posix_char  str[ 2048 ];
	n_posix_char  run[ 2048 ];
	n_posix_char lval[ 2048 ];
	n_posix_char rval[ 2048 ];
	n_posix_char sect[ 2048 ];

	n_ini ini; n_ini_zero( &ini );


	i = 0;
	n_posix_loop
	{

		n_posix_sprintf_literal( run, "%s\\%s", smwc, runstr[ i % 5 ] );

//n_posix_debug( hivestr[ i >= 5 ] );


		ret = RegOpenKeyEx( hive[ i >= 5 ], run, 0, KEY_QUERY_VALUE, &hkey );

		ii = 0;
		n_posix_loop
		{//break;

			if ( ret != ERROR_SUCCESS ) { break; }


			lvalbyte = maxlength * sizeof( n_posix_char );
			rvalbyte = maxlength * sizeof( n_posix_char );

			n_memory_zero( lval, lvalbyte );
			n_memory_zero( rval, rvalbyte );

			ret = RegEnumValue( hkey, ii, lval,&lvalbyte, NULL,NULL, (void*) rval, &rvalbyte );
			if ( ret != ERROR_SUCCESS ) { break; }

			ii++;

//n_posix_debug( lval );
//n_posix_debug( rval );


			n_string_copy_literal( "./startup", str );
			n_posix_mkdir( str );

			n_posix_sprintf_literal( &str[ n_posix_strlen( str ) ], "/%s", hivestr[ i >= 5 ] );
			n_posix_mkdir( str );

			n_posix_sprintf_literal( &str[ n_posix_strlen( str ) ], "/%s",  runstr[ i %  5 ] );
			n_posix_mkdir( str );

			{
				n_posix_char safename[ 256 ];

				n_string_safename( lval, safename );

				n_posix_sprintf_literal( &str[ n_posix_strlen( str ) ], "/%s.reg", safename );
			}

//n_posix_debug( str );

			n_ini_new( &ini );
			ini.unicode = N_TXT_UNICODE_NIL;


			n_posix_sprintf_literal( sect, "[%s\\%s]", hivestr[ i >= 5 ], run );
			n_ini_section_add( &ini, sect );


			// [!] : .REG needs double-quotation and escapement

			n_ini_value_escape( lval );
			n_ini_value_escape( rval );

			n_ini_key_add_str( &ini, sect, lval, rval );


			n_ini_add( &ini, 0, n_posix_literal( "REGEDIT4" ) );
			n_ini_add( &ini, 1, N_STRING_EMPTY );

			n_ini_save( &ini, str );


			n_ini_free( &ini );

		}


		// [!] : you cannot use RegDeleteValue( hive, lval );

		RegDeleteKey( hive[ i >= 5 ], run );


		RegCloseKey( hkey );


		i++;
		if ( i >= 10 ) { break; }
	}


	return;
}

