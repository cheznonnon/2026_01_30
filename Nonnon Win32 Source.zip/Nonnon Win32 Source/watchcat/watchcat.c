// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/com/IShellLink.c"

#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/sysinfo.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_progressbar.c"
#include "../nonnon/win32/win_sizegrip.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"




#include "./n_registry_startupcleaner.c"
#include "./n_watchcat_fullcoloricon_set.c"




// Watchcat

#define H_PROCLIST       watchcat.hgui[ 0 ]
#define H_INFO           watchcat.hgui[ 1 ]
#define H_STATIC_CPU     watchcat.hgui[ 2 ]
#define H_STATIC_MEM     watchcat.hgui[ 3 ]
#define H_SIZEGRIP_MAIN  watchcat.hgui[ 4 ]
#define H_SIZEGRIP_DARK  watchcat.hgui[ 5 ]
#define GUI_MAX                         6

#define H_BTN_TOP        watchcat.hbtn[ 0 ]
#define H_BTN_NEKO       watchcat.hbtn[ 1 ]
#define H_BTN_INFO_1     watchcat.hbtn[ 2 ]
#define H_BTN_INFO_2     watchcat.hbtn[ 3 ]
#define BTN_MAX                         4



#define N_WATCHCAT_APPNAME    n_posix_literal( "Watchcat" )
#define N_WATCHCAT_ICONNAME   n_posix_literal( "WATCHCAT_0_MAIN" )

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_WATCHCAT ( 0 )

#endif // #ifndef NONNON_APPS


#define N_WATCHCAT_TIMER_MSEC ( 1000 )



typedef struct {

	HWND                  hwnd;
	HWND                  hgui[ GUI_MAX ];
	n_win_button          hbtn[ BTN_MAX ];
	n_win_txtbox          txtbox;
	n_win_txtbox          txtbox_info;

	n_win                 nwin;
	n_type_gfx            minwsx,minwsy;

	int                   cpu, mem;

	n_sysinfo_processlist proclist;

	n_bool                topmost;
	n_bool                watchcat;
	n_bool                info_1;
	n_bool                info_2;

	n_type_gfx            scroll_y;

	int                   icon_offset;

	UINT                  timer_id;

	n_win_titlemenu       titlemenu;
	n_win_simplemenu      simplemenu;

	WNDPROC               flickerfree_func;

} n_watchcat;

#define n_watchcat_zero( p ) n_memory_zero( p, sizeof( n_watchcat ) )


static n_watchcat watchcat;




void
n_project_font_monospace( HWND hgui )
{

	HDC hdc = GetDC( hgui );

	LOGFONT lf_f; n_memory_zero( &lf_f, sizeof( LOGFONT ) ); 
	LOGFONT lf_t = n_win_font_hfont2logfont( n_win_stdfont_hfont() );

	// [x] : Win9x : "MS Gothic" is not available : a localized name is needed

	n_posix_char *fontname = n_gdi_font_find
	(
		n_posix_literal( "Consolas" ),
#ifdef UNICODE
		n_posix_literal( "\xff2d\xff33\x0020\x30b4\x30b7\x30c3\x30af" )           // Unicode LE
#else
		n_posix_literal( "\x82\x6c\x82\x72\x20\x83\x53\x83\x56\x83\x62\x83\x4e" ) // Shift-JIS
#endif
		n_posix_literal( "Courier New" ),
		n_posix_literal( "Courier" )
	);
	n_posix_sprintf_literal( lf_f.lfFaceName, "%s", fontname );
	n_bool ret = EnumFonts( hdc, NULL, n_gdi_font_enumfontsproc, (LPARAM) &lf_f );
//n_posix_debug_literal( "%d : %s", ret, lf_f.lfFaceName );
	ReleaseDC( hgui, hdc );

	if ( ret )
	{
		n_win_stdfont_init( &hgui, 1 );
	} else {
		n_posix_sprintf_literal( lf_t.lfFaceName, "%s", fontname );
		n_win_font_set( hgui, n_win_font_logfont2hfont( &lf_t ), n_true );
	}


	return;
}

void
n_watchcat_proclist_vertical_spacing( n_watchcat *p, n_bool onoff )
{

	if ( onoff )
	{
		n_type_gfx m; n_win_stdsize( p->hwnd, NULL, NULL, &m );
		n_win_txtbox_metrics_vertical_spacing( &p->txtbox, p->txtbox.font_pxl_sy + ( m * 2 ) );
	} else {
		n_win_txtbox_metrics_vertical_spacing( &p->txtbox, p->txtbox.font_pxl_sy             );
	}


	return;
}

void
n_watchcat_proclist_refresh( n_watchcat *p, n_bool is_init )
{
//return;

	n_sysinfo_processlist proclist;
	n_sysinfo_processlist_zero( &proclist );
	n_sysinfo_processlist_make( &proclist );

//n_win_hwndprintf_literal( p->hwnd, " %d ", p->scroll_y );

	if ( ( is_init == n_false )&&( proclist.exe.sy == p->proclist.exe.sy ) )
	{

		n_type_int same = 0;

		n_type_int i = 0;
		n_posix_loop
		{//break;

			if (
				( n_string_is_same( n_vector_get( &proclist.exe , i ), n_vector_get( &p->proclist.exe , i ) ) )
				&&
				( n_string_is_same( n_vector_get( &proclist.pid , i ), n_vector_get( &p->proclist.pid , i ) ) )
				&&
				( n_string_is_same( n_vector_get( &proclist.hwnd, i ), n_vector_get( &p->proclist.hwnd, i ) ) )
			)
			{
				same++;
			}

			i++;
			if ( i >= proclist.exe.sy ) { break; }
		}

		if ( same == proclist.exe.sy )
		{
//n_win_hwndprintf_literal( p->hwnd, "!" );
			n_sysinfo_processlist_exit( &proclist );
			return;
		} else {
//n_win_hwndprintf_literal( p->hwnd, "Watchcat" );
		}

	}

	n_sysinfo_processlist_exit( &p->proclist );
	n_memory_copy( &proclist, &p->proclist, sizeof( n_sysinfo_processlist ) );


//n_win_hwndprintf_literal( p->hwnd, "%d", n_win_txtbox_is_selected( &p->txtbox ) );

	// [x] : wrong glyphs are used

	n_posix_char *prev_selection = NULL;
	if ( n_win_txtbox_is_selected( &p->txtbox ) )
	{
		prev_selection = n_win_txtbox_selection_new( &p->txtbox );
	}


	n_type_int scroll_y = p->txtbox.scroll_pxl_tabbed_y;


	n_win_txtbox_reset( &p->txtbox );

	n_type_int i = 0;
	n_posix_loop
	{//break;

		n_type_int    str_cch = n_sysinfo_processlist_format_cch( &p->proclist, i );
		n_posix_char *str_fmt = n_string_new( str_cch ); n_sysinfo_processlist_format( &p->proclist, i, str_fmt );

		n_win_txtbox_line_set( &p->txtbox, i, str_fmt );

		n_string_free( str_fmt );

		i++;
		if ( i >= p->proclist.exe.sy ) { break; }
	}

	n_txt_sort_up( &p->txtbox.txt );

	n_watchcat_proclist_vertical_spacing( p, n_true );

	n_win_scrollbar_refresh( &p->txtbox.vscr );

	if ( prev_selection != NULL )
	{
		n_win_txtbox_line_select_by_string( &p->txtbox, prev_selection );
		n_string_free( prev_selection );
	}

//n_win_txtbox_line_select( &p->txtbox, 0 );

	p->txtbox.scroll_pxl_tabbed_y = scroll_y;

	n_win_txtbox_refresh( &p->txtbox, N_WIN_TXTBOX_WATCHCAT );

//n_win_hwndprintf_literal( p->hwnd, " %d %f ", p->proclist.exe.sy, p->txtbox.vscr.rect_thumb.sy );
	return;
}

// internal
void
n_watchcat_cpumem_refresh( n_watchcat *p )
{

	static int p_cpu = -1;
	static int p_mem = -1;

	DWORD mem_total, mem_used;


	p->cpu = n_sysinfo_cpu_ratio();
	p->mem = n_sysinfo_memory( &mem_total, &mem_used, NULL );


	if ( p_cpu != p->cpu )
	{

		n_win_hwndprintf_literal( H_STATIC_CPU, "CPU %3d%%", p->cpu );

		p_cpu = p->cpu;
		n_win_refresh( H_STATIC_CPU, n_posix_false );

	}

	if ( p_mem != p->mem )
	{

		n_win_hwndprintf_literal( H_STATIC_MEM, "MEM %3d%%", p->mem );

		p_mem = p->mem;
		n_win_refresh( H_STATIC_MEM, n_posix_false );

	}


	return;
}

// internal
void
n_watchcat_resize( n_watchcat *p )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m; n_win_stdsize( p->hwnd, &ctl, &ico, &m );

	n_type_gfx gap = H_BTN_TOP.maclike_offset / 2;


	static n_bool is_first = n_true;

	int        nwset = N_WIN_SET_DEFAULT;
	n_type_gfx csx   = -1;
	n_type_gfx csy   = -1;

	if ( is_first )
	{

		is_first = n_false;

		nwset = N_WIN_SET_CENTERING;

		csy  = m + ( ctl + ( ctl * 7 ) + ico );
		csx  = m + (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) );

		p->minwsx = csx;
		p->minwsy = ctl;

	} else {

		nwset = n_project_n_win_set();

	}

	n_win_set( p->hwnd, &p->nwin, csx,csy, nwset );

	csx = p->nwin.csx - m;
	csy = p->nwin.csy - m;


	if ( p->nwin.csy < ( ctl + ctl + ico ) )
	{
		ShowWindow( H_PROCLIST, SW_HIDE   );
		ShowWindow( H_INFO    , SW_HIDE   );
	} else {
		if ( ( p->info_1 )||( p->info_2 ) )
		{
			ShowWindow( H_PROCLIST, SW_HIDE   );
			ShowWindow( H_INFO    , SW_NORMAL );
		} else {
			ShowWindow( H_INFO    , SW_HIDE   );
			ShowWindow( H_PROCLIST, SW_NORMAL );
		}
	}


	if ( p->nwin.state == SIZE_MAXIMIZED )
	{
		ShowWindow( H_SIZEGRIP_MAIN, SW_HIDE   );
		ShowWindow( H_SIZEGRIP_DARK, SW_HIDE   );
	} else {
		ShowWindow( H_SIZEGRIP_MAIN, SW_NORMAL );
		ShowWindow( H_SIZEGRIP_DARK, SW_NORMAL );
	}


	n_type_gfx grip  = n_win_sizegrip_stdsize();
	n_type_gfx list  = csy - ( ctl + n_posix_max_n_type_gfx( ico, grip ) );
	n_type_gfx half  = csx / 2;
	n_type_gfx gripx = p->nwin.csx - grip;
	n_type_gfx gripy = p->nwin.csy - grip;

	if ( p->nwin.csy < ( ctl + ico  ) ) { ico  = 0; }
	if ( p->nwin.csy < ( ctl + grip ) ) { grip = 0; }

	n_type_gfx ico_x = ico * 0;

	n_win_move       (  H_STATIC_CPU   ,       0,       0, half,  ctl, redraw );
	n_win_move       (  H_STATIC_MEM   ,    half,       0, half,  ctl, redraw );
	n_win_move       (  H_PROCLIST     ,       0,     ctl,  csx, list, redraw );
	n_win_move       (  H_INFO         ,       0,     ctl,  csx, list, redraw );
	n_win_button_move( &H_BTN_TOP      ,   ico_x, csy-ico,  ico,  ico, redraw ); ico_x += ico + gap;
	n_win_button_move( &H_BTN_NEKO     ,   ico_x, csy-ico,  ico,  ico, redraw ); ico_x += ico + gap;
	n_win_button_move( &H_BTN_INFO_1   ,   ico_x, csy-ico,  ico,  ico, redraw ); ico_x += ico + gap;
	n_win_button_move( &H_BTN_INFO_2   ,   ico_x, csy-ico,  ico,  ico, redraw ); ico_x += ico + gap;
	n_win_move_simple(  H_SIZEGRIP_MAIN, gripx+1,   gripy, grip, grip, redraw );
	n_win_move_simple(  H_SIZEGRIP_DARK, gripx  ,   gripy, grip, grip, redraw );

	//n_win_txtbox_refresh( &p->txtbox     , N_WIN_TXTBOX_WATCHCAT );
	//n_win_txtbox_refresh( &p->txtbox_info, N_WIN_TXTBOX_WATCHCAT );


	return;
}

// internal
void
n_watchcat_terminate( n_watchcat *p )
{

	n_posix_char *str = n_win_txtbox_selection_new( &p->txtbox );
	DWORD         pid = n_posix_atoi( str );
	n_string_path_free( str );


	if ( watchcat.watchcat )
	{

		HANDLE hproc = OpenProcess( PROCESS_TERMINATE, n_false, pid );

		TerminateProcess( hproc, pid );

		CloseHandle( hproc );

	} else {

		HWND h = n_sysinfo_processlist_pid2hwnd( &p->proclist, pid );

		if ( h != NULL )
		{
			n_win_message_post( h, WM_CLOSE, 0,0 );
		}

	}


	return;
}

// internal
void
n_watchcat_info_refresh( n_watchcat *p )
{

	static int p_mode = 0;
	static int   mode = 0;


	n_bool proclist_onoff = ( ( p->info_1 | p->info_2 ) == n_false );
//n_win_hwndprintf_literal( p->hwnd, " %d %d %d ", proclist_onoff, p->info_1, p->info_2 );

	if ( proclist_onoff )
	{

		mode = 0;

		n_watchcat_proclist_refresh( p, n_false );

//n_win_hwndprintf_literal( p->hwnd, " %d %d ", (int) p->txtbox.vscr.unit_pos, p->scroll_y );

	} else
	if ( p->info_1 )
	{

		mode = 1;

		n_posix_char *str = n_string_new( N_SYSINFO_CCH );

		if ( n_sysinfo_window( p->hwnd, str, ( p_mode != mode ) ) )
		{
			n_win_txtbox_reset( &p->txtbox_info );
			n_win_txtbox_txt_load_onmemory( &p->txtbox_info, str, n_string_cch2cb( str, n_posix_strlen( str ) ) );
			n_win_txtbox_refresh( &p->txtbox_info, N_WIN_TXTBOX_WATCHCAT );
		} else {
			n_string_free( str );
		}

	} else
	if ( p->info_2 )
	{

		mode = 1;

		n_posix_char *str = n_string_new( N_SYSINFO_CCH );

		if ( n_sysinfo_class( p->hwnd, str, ( p_mode != mode ) ) )
		{
			n_win_txtbox_reset( &p->txtbox_info );
			n_win_txtbox_txt_load_onmemory( &p->txtbox_info, str, n_string_cch2cb( str, n_posix_strlen( str ) ) );
			n_win_txtbox_refresh( &p->txtbox_info, N_WIN_TXTBOX_WATCHCAT );
		} else {
			n_string_free( str );
		}

	}// else

	if ( p_mode != mode )
	{
		if ( mode == 0 )
		{
			p->info_1 = p->info_2 = n_false;

			//n_watchcat_proclist_refresh( p, n_true );

			ShowWindow( H_INFO    , SW_HIDE   );
			ShowWindow( H_PROCLIST, SW_NORMAL );
		} else {
			ShowWindow( H_PROCLIST, SW_HIDE   );
			ShowWindow( H_INFO    , SW_NORMAL );
		}
	}

	p_mode = mode;


	return;
}

void
n_watchcat_icon_add( void )
{

	n_posix_char *exe = n_win_exepath_new();

	n_win_icon_init_callback = n_project_system_icon_color;

	H_BTN_TOP   .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_WATCHCAT + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_NEKO  .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_WATCHCAT + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_INFO_1.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_WATCHCAT + 1, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_INFO_2.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_WATCHCAT + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );

	n_string_path_free( exe );


	return;
}

void
n_watchcat_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_watchcat_icon_add();

		n_win_button_on_settingchange( &H_BTN_TOP    );
		n_win_button_on_settingchange( &H_BTN_NEKO   );
		n_win_button_on_settingchange( &H_BTN_INFO_1 );
		n_win_button_on_settingchange( &H_BTN_INFO_2 );

		n_win_stdfont_init( watchcat.hgui, GUI_MAX );
		n_project_font_monospace( H_INFO );

		n_win_txtbox_on_settingchange( &watchcat.txtbox      );
		n_win_txtbox_on_settingchange( &watchcat.txtbox_info );

		n_watchcat_resize( &watchcat );

	break;


	} // switch


}

LRESULT CALLBACK
n_watchcat_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_bool is_wm_close = n_false;


	n_watchcat_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Instance

		n_win_exedir2curdir();

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_watchcat_zero( &watchcat );

		watchcat.hwnd = hwnd;


		// Window

		n_win_init( hwnd, N_WATCHCAT_APPNAME, N_WATCHCAT_ICONNAME, N_STRING_EMPTY );

		n_win_gui_literal( hwnd, CANVAS,  "", &H_STATIC_CPU    );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_STATIC_MEM    );

		n_win_button_init( &H_BTN_TOP   , hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_NEKO  , hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_INFO_1, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_INFO_2, hwnd, N_STRING_EMPTY, PBS_NORMAL );

		n_win_gui_literal( hwnd, CANVAS,  "", &H_SIZEGRIP_DARK );
		n_win_gui_literal( hwnd, VSCROLL, "", &H_SIZEGRIP_MAIN );

		n_watchcat_icon_add();

		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int option = 0;

			option = option | N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM;
			option = option | N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM;

			if ( n_win_fluent_ui_onoff )
			{
				option = option | N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
			}

			n_win_txtbox_zero( &watchcat.txtbox );
			n_win_txtbox_init( &watchcat.txtbox, hwnd, style, option );

			H_PROCLIST = watchcat.txtbox.hwnd;
//watchcat.txtbox.vscr.style = N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT;//VISUALSTYLE;

		}

		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_EDITBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;
			style = style | N_WIN_TXTBOX_STYLE_LINEBDR;

			n_win_txtbox_zero( &watchcat.txtbox_info );
			n_win_txtbox_init( &watchcat.txtbox_info, hwnd, style, N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM );

			H_INFO = watchcat.txtbox_info.hwnd;

		}


		// Style

		n_project_window_resizable( hwnd );

		n_win_style_add( H_SIZEGRIP_MAIN, SBS_SIZEGRIP );

		n_win_simplemenu_zero( &watchcat.simplemenu );
		n_win_simplemenu_init( &watchcat.simplemenu );

		n_win_simplemenu_set( &watchcat.simplemenu, 0, NULL, n_posix_literal( "[ ]Startup Cleaner"  ), NULL );
		n_win_simplemenu_set( &watchcat.simplemenu, 1, NULL, n_posix_literal( "[ ]Full Color Icons" ), NULL );

		n_win_titlemenu_init_main( &watchcat.titlemenu, hwnd, &watchcat.simplemenu );
/*
		H_BTN_TOP   .nomove_onoff = n_posix_true;
		H_BTN_NEKO  .nomove_onoff = n_posix_true;
		H_BTN_INFO_1.nomove_onoff = n_posix_true;
		H_BTN_INFO_2.nomove_onoff = n_posix_true;
*/

		n_win_stdfont_init( watchcat.hgui, GUI_MAX );
		n_project_font_monospace( H_INFO );

		n_win_flickerfree_init( hwnd, &watchcat.flickerfree_func );

		n_win_flickerfree_win_iconbutton_init( H_BTN_TOP   .hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_NEKO  .hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_INFO_1.hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_INFO_2.hwnd );


		// Watchcat

		n_sysinfo_sysmon_init();

		n_watchcat_info_refresh( &watchcat );
		n_watchcat_cpumem_refresh( &watchcat );

		n_watchcat_resize( &watchcat );

		if ( watchcat.timer_id == 0 ) { watchcat.timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, watchcat.timer_id, N_WATCHCAT_TIMER_MSEC );


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( di->hwndItem == H_STATIC_CPU )
		{
			n_win_fluent_ui_progress( H_STATIC_CPU, watchcat.cpu );
		} else
		if ( di->hwndItem == H_STATIC_MEM )
		{
			n_win_fluent_ui_progress( H_STATIC_MEM, watchcat.mem );
		}

	}
	break;


	case WM_SIZE :

		n_watchcat_resize( &watchcat );

		n_win_fluent_ui_progress( H_STATIC_CPU, watchcat.cpu );
		n_win_fluent_ui_progress( H_STATIC_MEM, watchcat.mem );

	break;

	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_PROCLIST )
		{

			if ( wparam == WM_LBUTTONDBLCLK )
			{
				n_watchcat_terminate( &watchcat );
				n_watchcat_info_refresh( &watchcat );
			}

		} else

		if ( h == H_BTN_TOP.hwnd )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 4;

			watchcat.topmost = n_win_button_checklike( &H_BTN_TOP, f, f, watchcat.topmost );

			n_win_topmost( hwnd, watchcat.topmost );

		} else

		if ( h == H_BTN_NEKO.hwnd )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 3;
			int t = N_APPS_ICON_OFFSET_WATCHCAT + 0;

			watchcat.watchcat = n_win_button_checklike( &H_BTN_NEKO, f, t, watchcat.watchcat );

		} else

		if ( h == H_BTN_INFO_1.hwnd )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 1;

			watchcat.info_1 = n_win_button_checklike( &H_BTN_INFO_1, f, f, watchcat.info_1 );
			watchcat.info_2 = n_false;

			n_watchcat_info_refresh( &watchcat );

			if ( watchcat.info_1 )
			{
				n_win_button_grayed_onoff( &H_BTN_INFO_2, n_true  );
			} else {
				n_win_button_grayed_onoff( &H_BTN_INFO_2, n_false );
			}

			n_watchcat_resize( &watchcat );

		} else

		if ( h == H_BTN_INFO_2.hwnd )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 2;

			watchcat.info_1 = n_false;
			watchcat.info_2 = n_win_button_checklike( &H_BTN_INFO_2, f, f, watchcat.info_2 );

			n_watchcat_info_refresh( &watchcat );

			if ( watchcat.info_2 )
			{
				n_win_button_grayed_onoff( &H_BTN_INFO_1, n_true  );
			} else {
				n_win_button_grayed_onoff( &H_BTN_INFO_1, n_false );
			}

			n_watchcat_resize( &watchcat );

		} else

		if ( h == watchcat.simplemenu.hwnd )
		{

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{

			} else
			if ( wparam == 0 )
			{

				n_registry_startupcleaner();
				n_explorer_refresh( n_false );

				n_win_exec_literal( "explorer.exe startup", SW_NORMAL );

			} else
			if ( wparam == 1 )
			{

				n_watchcat_fullcoloricon_set();

			}// else

		}// else

	}
	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != watchcat.timer_id ) { break; }


		n_watchcat_cpumem_refresh( &watchcat );
		n_watchcat_info_refresh( &watchcat );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_win_timer_exit( hwnd, watchcat.timer_id );


		n_sysinfo_processlist_exit( &watchcat.proclist );


		n_sysinfo_sysmon_exit();


		n_win_txtbox_exit( &watchcat.txtbox      );
		n_win_txtbox_exit( &watchcat.txtbox_info );


		n_win_button_exit( &H_BTN_TOP    );
		n_win_button_exit( &H_BTN_NEKO   );
		n_win_button_exit( &H_BTN_INFO_1 );
		n_win_button_exit( &H_BTN_INFO_2 );


		is_wm_close = n_true;
		n_win_stdfont_exit( watchcat.hgui, GUI_MAX );


		n_win_titlemenu_exit( &watchcat.titlemenu );

		n_win_simplemenu_exit( &watchcat.simplemenu );


		n_win_flickerfree_exit( hwnd, &watchcat.flickerfree_func );

		n_win_flickerfree_win_iconbutton_exit( H_BTN_TOP   .hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_NEKO  .hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_INFO_1.hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_INFO_2.hwnd );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch()


	n_win_minsize_proc( hwnd, msg, wparam, lparam, watchcat.minwsx, watchcat.minwsy );


	if ( is_wm_close == n_false )
	{

		if ( IsWindowVisible( watchcat.txtbox     .hwnd ) )
		{
			n_win_txtbox_proc( hwnd, msg, wparam, lparam, &watchcat.txtbox      );
		}

		if ( IsWindowVisible( watchcat.txtbox_info.hwnd ) )
		{
			n_win_txtbox_proc( hwnd, msg, wparam, lparam, &watchcat.txtbox_info );
		}

	}

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_TOP    );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_NEKO   );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_INFO_1 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_INFO_2 );


	n_win_sizegrip_proc( hwnd, msg, wparam, lparam, H_SIZEGRIP_DARK );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win_main( N_WATCHCAT_APPNAME, n_watchcat_wndproc );
}

#endif // #ifndef NONNON_APPS




#undef H_PROCLIST
#undef H_INFO
#undef H_STATIC_CPU
#undef H_STATIC_MEM
#undef H_SIZEGRIP_MAIN
#undef H_SIZEGRIP_DARK
#undef GUI_MAX

#undef H_BTN_TOP
#undef H_BTN_NEKO
#undef H_BTN_INFO_1
#undef H_BTN_INFO_2
#undef BTN_MAX


