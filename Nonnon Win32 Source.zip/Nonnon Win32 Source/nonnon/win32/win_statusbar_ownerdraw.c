// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//	n_win_statusbar_od_zero()
//	n_win_statusbar_od_init()
//
//	[ WndProc() ]
//
//	n_win_statusbar_od_proc()




#ifndef _H_NONNON_WIN32_WIN_STATUSBAR_OD
#define _H_NONNON_WIN32_WIN_STATUSBAR_OD




#include "./gdi/doublebuffer_32bpp.c"

#include "./win.c"
#include "./win_sizegrip.c"

#include "./uxtheme.c"




#define N_WIN_STATUSBAR_OD_MAX ( 10 )




typedef struct {

	int  parts;

	n_posix_char *str[ N_WIN_STATUSBAR_OD_MAX ];

	HWND hwnd;
	HWND hwnd_parent;
	HWND hsizegrip_main;
	HWND hsizegrip_dark;

	n_type_gfx offset_y;

	n_posix_bool is_xp_or_later;
	n_posix_bool is_8_or_later;

	n_posix_bool sizegrip_onoff;

} n_win_statusbar_ownerdraw;




#define n_win_statusbar_od_zero( p ) n_memory_zero( p, sizeof( n_win_statusbar_ownerdraw ) )

void
n_win_statusbar_od_init( n_win_statusbar_ownerdraw *p, HWND hwnd_parent, int parts )
{

	p->parts       = parts;
	p->hwnd_parent = hwnd_parent;

	n_win_gui_literal( p->hwnd_parent, N_WIN_GUI_CANVAS,  "", &p->hsizegrip_dark );
	n_win_gui_literal( p->hwnd_parent, N_WIN_GUI_VSCROLL, "", &p->hsizegrip_main );
	n_win_gui_literal( p->hwnd_parent, N_WIN_GUI_CANVAS,  "", &p->hwnd );

	n_win_style_add( p->hsizegrip_main, SBS_SIZEGRIP );

	n_win_stdfont_init( &p->hwnd, 1 );

	p->is_xp_or_later = n_sysinfo_version_xp_or_later();
	p->is_8_or_later  = n_sysinfo_version_8_or_later();


	return;
}

void
n_win_statusbar_od_exit( n_win_statusbar_ownerdraw *p )
{

	int i = 0;
	n_posix_loop
	{

		n_string_free( p->str[ i ] );

		i++;
		if ( i >= N_WIN_STATUSBAR_OD_MAX ) { break; }
	}

	n_win_stdfont_exit( &p->hwnd, 1 );

	DestroyWindow( p->hsizegrip_main );
	DestroyWindow( p->hsizegrip_dark );
	DestroyWindow( p->hwnd           );


	return;
}

void
n_win_statusbar_od_box( HWND hwnd, HDC hdc, RECT *rect, COLORREF color )
{

	//n_win_box( hwnd, hdc, rect, color );

	n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

	u32 argb = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color ) );

	n_bmp_box( bmp, x,y,sx,sy, argb );


	return;
}

void
n_win_statusbar_od_text( n_win_statusbar_ownerdraw *p, n_posix_char *str, int part )
{

	if ( p->str[ part ] != NULL ) { n_string_free( p->str[ part ] ); }
	p->str[ part ] = n_string_carboncopy( str );

	n_win_refresh( p->hwnd, n_posix_false );


	return;
}

void
n_win_statusbar_od_automove( n_win_statusbar_ownerdraw *p )
{

	n_type_gfx ctl; n_win_stdsize( p->hwnd, &ctl, NULL, NULL );


	n_type_gfx sx,sy; n_win_size_client( p->hwnd_parent, &sx, &sy );
	MoveWindow( p->hwnd, 0,sy - ctl, sx,ctl, n_posix_true );
//n_win_hwndprintf_literal( p->hwnd_parent, " %d : %d %d ", ctl, sx, sy );

	DWORD style = n_win_style_get( p->hwnd_parent );
	if ( ( style & WS_SIZEBOX )&&( n_posix_false == IsZoomed( p->hwnd_parent ) ) )
	{

		n_type_gfx sizegrip = n_win_sizegrip_stdsize();

		p->sizegrip_onoff = n_posix_true;

		ShowWindow( p->hsizegrip_main, SW_NORMAL );
		ShowWindow( p->hsizegrip_dark, SW_NORMAL );

		n_type_gfx o = 0;
		if ( n_win_style_is_classic() ) { o = n_win_sizegrip_offset( p->hsizegrip_dark ); }

//n_win_hwndprintf_literal( p->hwnd_parent, " %d ", n_win_sizegrip_offset( p->hsizegrip_dark ) );

		MoveWindow( p->hsizegrip_main, sx - sizegrip + o, sy - sizegrip + o, sizegrip, sizegrip, n_posix_true );
		MoveWindow( p->hsizegrip_dark, sx - sizegrip + o, sy - sizegrip + o, sizegrip, sizegrip, n_posix_true );

	} else {

		p->sizegrip_onoff = n_posix_false;

		ShowWindow( p->hsizegrip_main, SW_HIDE );
		ShowWindow( p->hsizegrip_dark, SW_HIDE );

	}


	return;
}

// internal
void
n_win_statusbar_od_draw( n_win_statusbar_ownerdraw *p, RECT *rect_arg )
{

	RECT  rect_null;
	RECT *rect;

	if ( rect_arg != NULL )
	{
		rect = rect_arg;
	} else {
		GetClientRect( p->hwnd, &rect_null );
		rect = &rect_null;
	}


	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	n_type_gfx scale = (n_type_gfx) trunc( n_win_scale( p->hwnd ) );


	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx,sy );


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, p->hwnd, L"WINDOW" );

	if (n_posix_false)//( uxtheme.onoff )
	{

		// [x] : how to implement this ?

		int part  = 0;
		int state = 0;

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, rect, NULL );

	} else {

		COLORREF bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE       );
		COLORREF fg = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT       );
		COLORREF ln = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
		COLORREF lt = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );


		SetBkMode( hdc, TRANSPARENT );
		n_win_statusbar_od_box( p->hwnd, hdc, rect, bg );


		// [!] : border line

		n_type_gfx offset_y = 0;

		if (
			( ( p->is_xp_or_later )&&( uxtheme.onoff ) )
			||
			( p->is_8_or_later )
		)
		{

			RECT r = { x, y, x + sx, y + scale };
			n_win_statusbar_od_box( p->hwnd, hdc, &r, ln );

			n_type_gfx unit = ( 4 * scale );

			if ( n_posix_false == n_sysinfo_version_vista_or_later() )
			{

				n_posix_loop
				{//break;
					offset_y++;
					if ( offset_y >= unit ) { break; }

					COLORREF color = n_win_color_blend( ln, bg, (n_type_real) offset_y / unit );

					RECT r = { x, y + offset_y, x + sx, y + offset_y + scale };
					n_win_statusbar_od_box( p->hwnd, hdc, &r, color );
				}

				n_win_sizegrip_status_gradient( p->hwnd, hdc, x, y, sx, sy, scale, ln, bg );

			} else {

				offset_y = 1 * scale;

			}

		} else {

			offset_y = 2 * scale;

		}


		HFONT  hfont = n_win_font_get( p->hwnd );
		HFONT phfont = SelectObject( hdc, hfont );


		n_type_gfx ctl; n_win_stdsize( p->hwnd_parent, &ctl, NULL, NULL );


		int i = 0;
		n_posix_loop
		{

			n_type_gfx  text_sx = sx / p->parts;
			n_type_gfx parts_sx = sx / p->parts;
			n_type_gfx offset_x = parts_sx * i;

			if ( i == ( p->parts - 1 ) )
			{
				if ( IsWindowVisible( p->hsizegrip_main ) ) { text_sx -= ctl / 2; }
			}

			if ( ( p->is_xp_or_later )&&( uxtheme.onoff ) )
			{

				n_type_gfx scale_sy = ( scale * 2 );
				if ( p->is_8_or_later == n_posix_false ) { scale_sy += ( scale * 4 ); }

				RECT r = { x + offset_x - 1, y + offset_y + scale, x + offset_x -1 + 1, y + offset_y + sy - scale_sy };
				n_win_statusbar_od_box( p->hwnd, hdc, &r, ln );

				if ( p->is_8_or_later == n_posix_false )
				{
					offset_x++;
					RECT r = { x + offset_x - 1, y + offset_y + scale, x + offset_x -1 + 1, y + offset_y + sy - scale_sy };
					n_win_statusbar_od_box( p->hwnd, hdc, &r, lt );
				}

			} else {

				//

			}

			{
				SetTextColor( hdc, fg );

				int dt = DT_NOPREFIX | ( DT_SINGLELINE | DT_VCENTER );
				RECT r = { offset_x, y + offset_y, offset_x + text_sx, y + sy };

				n_posix_char *s = p->str[ i ];

				if ( s == NULL )
				{
					//
				} else
				if ( s[ 0 ] == N_STRING_CHAR_NUL )
				{
					//
				} else
				if ( s[ 1 ] == N_STRING_CHAR_NUL )
				{
					//
				} else
				if ( ( s[ 0 ] == N_STRING_CHAR_TAB )&&( s[ 1 ] != N_STRING_CHAR_TAB ) )
				{
					dt |= DT_CENTER;
					s   = &s[ 1 ];
				} else
				if ( ( s[ 0 ] == N_STRING_CHAR_TAB )&&( s[ 1 ] == N_STRING_CHAR_TAB ) )
				{
					dt |= DT_RIGHT;
					s   = &s[ 2 ];
					if ( p->sizegrip_onoff )
					{
						r.right -= ctl / 2;
					}
				}

				DrawText( hdc, s, -1, &r, dt );

//TextOut( hdc, offset, y, p->str[ i ], n_posix_strlen( p->str[ i ] ) );
			}

			if ( ( p->is_xp_or_later )&&( uxtheme.onoff ) )
			{

				//

			} else {

				RECT r = { x + offset_x, y + offset_y, x + offset_x + parts_sx, y + sy };
				if ( i < ( p->parts - 1 ) )
				{
					r.right -= ( scale * 2 );
				} else {
					r.right += ( sx % p->parts );
				}
				DrawEdge( hdc, &r, BDR_SUNKENOUTER, BF_RECT );

			}

			i++;
			if ( i >= p->parts ) { break; }
			if ( i >= N_WIN_STATUSBAR_OD_MAX ) { break; }
		}

		SelectObject( hdc, phfont );

	}

	n_uxtheme_exit( &uxtheme, p->hwnd );


	if ( n_win_dwm_is_on() ) { n_gdi_doublebuffer_32bpp_simple_visible(); }

	n_gdi_doublebuffer_32bpp_simple_exit();


	return;
}

void
n_win_statusbar_od_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_statusbar_ownerdraw *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		n_win_statusbar_od_draw( p, &di->rcItem );

	}
	break;

	} // switch


	n_win_sizegrip_proc_statusbar( hwnd, msg, wparam, lparam, p->hsizegrip_dark );


	return;
}


#endif // _H_NONNON_WIN32_WIN_STATUSBAR_OD



/*


#include "../project/macro.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_statusbar_ownerdraw sbar;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_statusbar_od_zero( &sbar );
		n_win_statusbar_od_init( &sbar, hwnd, 3 );

		n_win_statusbar_od_text( &sbar, n_posix_literal( " Test 1" ), 0 );
		n_win_statusbar_od_text( &sbar, n_posix_literal( " Test 2" ), 1 );
		n_win_statusbar_od_text( &sbar, n_posix_literal( " Test 3" ), 2 );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_stdfont_init( &sbar.hwnd, 1 );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

		n_win_statusbar_od_automove( &sbar );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		n_win_statusbar_od_automove( &sbar );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_stdfont_exit( &sbar.hwnd, 1 );

		n_win_statusbar_od_exit( &sbar );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_statusbar_od_proc( hwnd,msg,wparam,lparam, &sbar );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

*/

