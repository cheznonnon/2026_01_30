// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_CLIPBOARD
#define _H_NONNON_WIN32_CLIPBOARD




#include "../neutral/string.c"
#include "../neutral/string_path.c"


#include <shlobj.h>




#ifdef _H_NONNON_NEUTRAL_BMP

n_posix_bool
n_clipboard_nbmp_get( n_bmp *b )
{

	// [Needed] : n_bmp_zero( &b );


	if ( b == NULL ) { return n_posix_true; }


	OpenClipboard( GetDesktopWindow() );


	if (
		( n_posix_false == IsClipboardFormatAvailable( CF_DIB    ) )
		||
		( n_posix_false == IsClipboardFormatAvailable( CF_BITMAP ) )
	)
	{

		CloseClipboard();

		return n_posix_true;
	}


	BITMAPINFO bi;

	{

		HGLOBAL h = GetClipboardData( CF_DIB );
		if ( h == NULL )
		{

			CloseClipboard();

			return n_posix_true;
		}


		n_memory_copy( (void*) GlobalLock( h ), &bi, sizeof(BITMAPINFO) );

		GlobalUnlock( h );

	}

/*
n_posix_debug
(
	"Size      \t\t %d-%d \n"
	"Depth       \t %d \n"
	"Compression \t %d \n"
	"SizeImage   \t %d \n",
	(int) bi.bmiHeader.biWidth,
	(int) bi.bmiHeader.biHeight,
	(int) bi.bmiHeader.biBitCount,
	(int) bi.bmiHeader.biCompression,
	(int) bi.bmiHeader.biSizeImage
);
*/


	HGLOBAL h = GetClipboardData( CF_BITMAP );
	if ( h == NULL )
	{

		CloseClipboard();

		return n_posix_true;
	}


	// [!] : auto-conversion

	bi.bmiHeader.biCompression =  0;
	bi.bmiHeader.biSizeImage   =  0;
	bi.bmiHeader.biBitCount    = 32;

	n_type_int byte = n_bmp_size
	(
		bi.bmiHeader.biWidth,
		bi.bmiHeader.biHeight,
		bi.bmiHeader.biBitCount
	);


	n_bmp_free( b );


	BITMAPFILEHEADER fileh = { N_BMP_TYPE_BM, 0, 0,0, N_BMP_SIZE_HEADER };

	fileh.bfSize = fileh.bfOffBits + (u32) byte;

	n_memory_copy( &fileh,        &N_BMP_FILEH( b ), N_BMP_SIZE_FILEH );
	n_memory_copy( &bi.bmiHeader, &N_BMP_INFOH( b ), N_BMP_SIZE_INFOH );

	{

		HDC hdc = GetDC( NULL );

		N_BMP_PTR( b ) = n_memory_new( byte );

		GetDIBits( hdc, h, 0,bi.bmiHeader.biHeight, N_BMP_PTR( b ), &bi, DIB_RGB_COLORS );

		ReleaseDC( NULL, hdc );

	}

	n_bmp_precalc( b );


	// [!] : XP : mixed alpha value causes troubles

	// [!] : 2019/12/29 : off by usability

	//n_bmp_alpha_visible( b );


	CloseClipboard();


	return n_posix_false;
}

n_posix_bool
n_clipboard_nbmp_set( const n_bmp *bmp )
{

	if ( bmp == NULL ) { return n_posix_true; }


	OpenClipboard( GetDesktopWindow() );


	EmptyClipboard();


	//n_bmp bmp_24bpp; n_bmp_carboncopy( bmp, &bmp_24bpp ); n_bmp_24bit( &bmp_24bpp );


	const n_bmp *bmp_target = bmp;


	BITMAPINFO bi = { N_BMP_INFOH( bmp_target ), { { 0,0,0,0 } } };


/*
	// [x] : don't do this else broken image will display on MS Paint

	{
		HANDLE handle = GlobalAlloc( GHND, sizeof( BITMAPINFO ) );

		n_memory_copy( &bi, (void*) GlobalLock( handle ), sizeof( BITMAPINFO ) );

		GlobalUnlock( handle );

		SetClipboardData( CF_DIB, handle );
	}
*/

	{
		HDC hdc = GetDC( NULL );

		HBITMAP hbmp = CreateDIBitmap( hdc, &N_BMP_INFOH( bmp_target ), CBM_INIT, N_BMP_PTR( bmp_target ), &bi, DIB_RGB_COLORS );

		SetClipboardData( CF_BITMAP, hbmp );

		ReleaseDC( NULL, hdc );
	}


	//n_bmp_free_fast( &bmp_24bpp );


	CloseClipboard();


	return n_posix_false;
}

#endif // #ifdef _H_NONNON_NEUTRAL_BMP

n_type_int
n_clipboard_text_get( HWND hwnd, n_posix_char *text )
{

	OpenClipboard( hwnd );


#ifdef UNICODE

	HANDLE handle = GetClipboardData( CF_UNICODETEXT );

#else // #ifdef UNICODE

	HANDLE handle = GetClipboardData( CF_TEXT );

#endif // #ifdef UNICODE


	n_type_int length = GlobalSize( handle ) / sizeof( n_posix_char );

	if ( text != NULL )
	{

		n_posix_char *str = (n_posix_char*) GlobalLock( handle );

		if ( str != NULL )
		{
			n_posix_sprintf_literal( text, "%s", str );
		}

		GlobalUnlock( handle );

	}


	CloseClipboard();


	return length;
}

void
n_clipboard_text_set( HWND hwnd, const n_posix_char *text )
{

	if ( text == NULL ) { return; }


	OpenClipboard( hwnd );

	EmptyClipboard();


	n_type_int length = n_posix_strlen( text ) + 1;
	HANDLE     handle = GlobalAlloc( GHND, length * sizeof( n_posix_char ) );

	n_string_copy( text, (void*) GlobalLock( handle ) );

	GlobalUnlock( handle );


#ifdef UNICODE

	SetClipboardData( CF_UNICODETEXT, handle );

#else // #ifdef UNICODE

	SetClipboardData( CF_TEXT, handle );

#endif // #ifdef UNICODE


	CloseClipboard();


	return;
}

#define n_clipboard_explorer_cch( hwnd ) n_clipboard_explorer_get( hwnd, NULL )

n_type_int
n_clipboard_explorer_get( HWND hwnd, n_posix_char *multipath )
{

	OpenClipboard( hwnd );


	HANDLE handle = GetClipboardData( CF_HDROP );


	n_type_int cb  = GlobalSize( handle );
	n_type_int cch = cb / sizeof( n_posix_char );


	if ( multipath != NULL )
	{

		u8 *p = GlobalLock( handle );

		DROPFILES df = { sizeof( DROPFILES ), { 0,0 }, n_posix_false, n_posix_false };

		n_memory_copy( p, &df, sizeof( DROPFILES ) );

#ifdef UNICODE
		if ( df.fWide != n_posix_false )
		{
			n_memory_copy( (void*) &p[ sizeof( DROPFILES ) ], multipath, cb );
		}
#else  // #ifdef UNICODE
		if ( df.fWide == n_posix_false )
		{
			n_memory_copy( (void*) &p[ sizeof( DROPFILES ) ], multipath, cb );
		}
#endif // #ifdef UNICODE


		GlobalUnlock( handle );

	}


	return cch;
}

n_posix_char*
n_clipboard_explorer_new( HWND hwnd )
{

	// [!] : you need to n_string_path_free() a returned variable

	n_type_int    cch = n_clipboard_explorer_cch( hwnd );
	n_posix_char *ret = n_string_path_new( cch );


	if ( cch != 0 ) { n_clipboard_explorer_get( hwnd, ret ); }


	return ret;
}

void
n_clipboard_explorer_set( HWND hwnd, const n_posix_char *multipath )
{

	DROPFILES df = { sizeof( DROPFILES ), { 0,0 }, n_posix_false, n_posix_false };


#ifdef UNICODE
	df.fWide = n_posix_true;
#else  // #ifdef UNICODE
	df.fWide = n_posix_false;
#endif // #ifdef UNICODE


	// [!] : space for double NUL

	n_type_int cch = n_string_path_cch( multipath ) + 2;
	n_type_int cb  = cch * sizeof( n_posix_char );


	HGLOBAL hglobal = GlobalAlloc( GHND | GMEM_DDESHARE, sizeof( DROPFILES ) + cb );

	u8 *p = GlobalLock( hglobal );

	n_memory_copy( &df, p, sizeof( DROPFILES ) );
	n_memory_copy( multipath, (void*) &p[ sizeof( DROPFILES ) ], cb );

	GlobalUnlock( hglobal );


	if ( OpenClipboard( hwnd ) )
	{
		EmptyClipboard();

		SetClipboardData( CF_HDROP, hglobal );

		CloseClipboard();
	}


	return;
}


#endif // _H_NONNON_WIN32_CLIPBOARD

