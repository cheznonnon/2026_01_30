// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_PAINT_CANVAS_COLOR n_bmp_rgb_mac( 128,128,128 )


#define N_PAINT_TOOL_TYPE_PEN     0
#define N_PAINT_TOOL_TYPE_FILL    1
#define N_PAINT_TOOL_TYPE_GRABBER 2


#define N_PAINT_REDRAW_TYPE_ALL  0
#define N_PAINT_REDRAW_TYPE_PEN  1




typedef struct {

	n_type_gfx x,y,sx,sy;

} n_rect;


typedef struct {

	// [!] : Base

	BOOL       init;

	n_bmp      bmp_data;
	n_bmp      bmp_grab;
	n_type_gfx zoom;
	NSPoint    scroll;
	CGFloat    inner_sx;
	CGFloat    inner_sy;
	CGFloat    margin;
	NSRect     rect_redraw;
	int        redraw_type;

	NSOperationQueue *queue;
	int               cores;


	// [!] : Pen Trainer

	NSFont    *font;
	int        mode;

	int        index;
	CGFloat    canvas_size;
	CGFloat      icon_size;

	NSRect     prev_rect;
	n_bmp      prev_bmp;
	BOOL       prev_is_pressed;
	BOOL       prev_is_hovered;

	NSRect     clear_rect;
	n_bmp      clear_bmp;
	BOOL       clear_is_pressed;
	BOOL       clear_is_hovered;

	NSRect     next_rect;
	n_bmp      next_bmp;
	BOOL       next_is_pressed;
	BOOL       next_is_hovered;


	// [!] : Instance

	u32        color;
	int        tooltype;
	int        pensize;
	int        mix;

	BOOL       grid_onoff;


	// [!] : Canvas

	BOOL       readonly;

	NSPoint    n_pt;

	CGFloat    canvas_offset_x;
	CGFloat    canvas_offset_y;
	CGFloat    canvas_offset_sx;
	CGFloat    canvas_offset_sy;


	// [!] : Pen

	n_bmp        *pen_bmp_data;
	n_bmp        *pen_bmp_grab;
	BOOL          pen_start;
	n_type_gfx    pen_start_x;
	n_type_gfx    pen_start_y;
	n_type_gfx    pen_radius;
	u32           pen_color;
	double        pen_blend;
	int           pen_boost;
	BOOL          pen_quick_eraser_onoff;
	BOOL          pen_quick_blur_onoff;

} n_paint;


#define n_paint_zero( p ) n_memory_zero( p, sizeof( n_paint ) )


