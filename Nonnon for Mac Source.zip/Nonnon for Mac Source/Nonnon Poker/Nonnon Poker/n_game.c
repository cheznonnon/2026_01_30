// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




//#import <Cocoa/Cocoa.h>


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/window.c"




@interface NonnonGame : NSView
@end




#include "poker.c"




@interface NonnonGame ()

@end




@implementation NonnonGame {

	n_poker  poker;
	NSRect   poker_rect;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
//NSLog( @"initWithCoder" );
	}


	return self;
}

- (void) n_mac_game_init:(int) endless_mode coin:(int)coin
{

	// [!] : trick : glitch at first time
	n_mac_keystate_get( 0 );

	n_poker_zero( &poker );
	n_poker_init( &poker );

	poker.self = self;

	if ( endless_mode )
	{
		poker.game_mode = N_POKER_GAME_MODE_ENDLESS;
	} else {
		poker.game_mode = N_POKER_GAME_MODE_BET;
	}

	poker.coin = poker.coin_dif = coin;

	n_poker_loop( &poker );

//NSLog( @"%d %d", poker.sx, poker.sy );


	n_game_chara_cursor_position_mousemoved_init( self );


	// [x] : Sonoma : glitch prevention
	n_mac_timer_init_once( self, @selector( n_timer_method_launch ), 500 );

}


- (void) n_timer_method_launch
{
//NSLog( @"n_timer_method_launch" );

	n_mac_timer_init( self, @selector( n_timer_method ), 1 );

}


- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{
//NSLog( @"!" );

	if ( sx == -1 ) { sx = poker.sx; }
	if ( sy == -1 ) { sy = poker.sy; }
//NSLog( @"%d %d", sx, sy );

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	[window setContentMaxSize:size];

	poker_rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:poker_rect];

	[window setContentSize:size];
	n_mac_window_centering( window );

}




- (void) n_accentColorChanged
{
//return;

	n_poker *p = &poker;

	p->draw_center = N_POKER_DRAW_CENTER_ALL;

}

- (void) n_darkModeChanged
{
//NSLog( @"n_darkModeChanged" );

	n_poker *p = &poker;

	n_poker_cardgenerator( p );

	p->draw_center = N_POKER_DRAW_CENTER_ALL;

}




- (void) n_game_start
{

	// [!] : macOS Sonoma launching sequence
	//
	//	initWithCoder
	//	awakeFromNib
	//	applicationWillFinishLaunching
	//	drawRect
	//	applicationDidFinishLaunching
	//	n_timer_method

}




- (BOOL) isFlipped
{
	return NO;
}




- (void) n_timer_method
{
//return;

//static u32 tick_prv = 0;


	// [x] : color / darkmode changer needs to be without this
	//if ( [n_mac_image_window isKeyWindow] == FALSE ) { return; }


	n_poker *p = &poker;


	static u32 timer = 0;
	if ( n_bmp_ui_timer( &timer, 6 ) )
	{
		n_poker_loop( p );
	}


	if ( p->coin_prv != p->coin )
	{
		// [!] : this makes slow-down
		int coin_step = n_posix_max( 2, abs( p->coin_prv - p->coin ) / 200 );
		if ( p->coin_prv < p->coin )
		{
			p->coin_prv += coin_step;
			if ( p->coin_prv > p->coin ) { p->coin_prv = p->coin; }
		} else {
			p->coin_prv -= coin_step;
			if ( p->coin_prv < p->coin ) { p->coin_prv = p->coin; }
		}

		n_poker_table_draw_coin_counter( p );
		p->refresh = TRUE;
	}


	if ( p->refresh )
	{
//n_mac_debug_count();
		p->refresh = FALSE;

		[self display];
	}

//u32 tick_cur = n_posix_tickcount();

//NSLog( @"%d", (int) tick_cur - tick_prv );

//tick_prv = tick_cur;

}




- (void) drawRect:(NSRect) rect
{
//NSLog( @"drawRect" );

	n_poker *p = &poker;

	//n_mac_image_nbmp_direct_draw_fast( &p->canvas, &poker_rect, FALSE );

	//n_mac_image_imagerep_sync( p->rep, &p->canvas );

	n_mac_image_imagerep_alias_fast( p->rep, &p->canvas );

	n_mac_image_nbmp_direct_draw_faster( p->rep, &poker_rect, FALSE );

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");

	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");

        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d : Chars %@", event.keyCode, event.characters );

#ifdef DEBUG

	// [!] : DEBUG_RESULT : search with this word

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_NUMBER_1: 
	{
		// [!] : N_POKER_ROYAL_FLUSH

		n_poker *p = &poker;

		p->table[ 0 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 10 );
		p->table[ 3 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 11 );
		p->table[ 4 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 12 );
		p->table[ 1 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 13 );
		p->table[ 2 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS,  1 );

		//p->table[ 1 ] = N_POKER_JOKER;

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	case N_MAC_KEYCODE_NUMBER_2: 
	{
		// [!] : N_POKER_FULL_HOUSE

		n_poker *p = &poker;

		p->table[ 0 ] = 0;
		p->table[ 1 ] = 13;
		p->table[ 2 ] = 26;
		p->table[ 3 ] = 1;
		p->table[ 4 ] = 14;

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	case N_MAC_KEYCODE_NUMBER_3: 
	{
		// [!] : N_POKER_FULL_HOUSE

		n_poker *p = &poker;

		p->table[ 0 ] = 0;
		p->table[ 1 ] = 13;
		p->table[ 2 ] = 26;
		p->table[ 3 ] = 1;
		p->table[ 4 ] = 14;

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	case N_MAC_KEYCODE_NUMBER_4: 
	{
		// [!] : N_POKER_FOUR_OF_A_KIND

		n_poker *p = &poker;

		p->table[ 0 ] = 0;
		p->table[ 1 ] = 13;
		p->table[ 2 ] = 26;
		p->table[ 3 ] = 39;
		p->table[ 4 ] = 1;

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	case N_MAC_KEYCODE_NUMBER_5: 
	{
		// [!] : N_POKER_STRAIGHT

		n_poker *p = &poker;

		p->table[ 0 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 5 );
		p->table[ 1 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 6 );
		p->table[ 2 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS, 7 );
		p->table[ 3 ] = n_poker_rule_card_number( p, N_SUIT_SPADES, 9 );
		p->table[ 4 ] = n_poker_rule_card_number( p, N_SUIT_SPADES, 8 );

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	case N_MAC_KEYCODE_NUMBER_6: 
	{
		// [!] : N_POKER_TWO_PAIR

		n_poker *p = &poker;

		p->table[ 0 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS  , 5 );
		p->table[ 1 ] = n_poker_rule_card_number( p, N_SUIT_DIAMONDS, 5 );
		p->table[ 2 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS  , 6 );
		p->table[ 3 ] = n_poker_rule_card_number( p, N_SUIT_SPADES  , 6 );
		p->table[ 4 ] = n_poker_rule_card_number( p, N_SUIT_SPADES  , 9 );

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	case N_MAC_KEYCODE_NUMBER_0: 
	{
		// [!] : Joker Test

		n_poker *p = &poker;

		p->table[ 0 ] = N_POKER_JOKER;
		p->table[ 1 ] = n_poker_rule_card_number( p, N_SUIT_SPADES  , 10 );
		p->table[ 2 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS  , 11 );
		p->table[ 3 ] = n_poker_rule_card_number( p, N_SUIT_HEARTS  , 12 );
		p->table[ 4 ] = n_poker_rule_card_number( p, N_SUIT_SPADES  , 13 );

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );
	}
	break;

	} // switch

#endif

}

- (void) keyUp : (NSEvent*) event
{
}



- (void) mouseMoved:(NSEvent*) theEvent
{
//NSLog( @"mouseMoved" );
/*
	n_poker *p = &poker;

	BOOL prv = p->hover_onoff;

	p->hover_onoff = n_poker_button_is_hovered( p );

	if ( prv != p->hover_onoff ) { p->draw_center = N_POKER_DRAW_CENTER_ALL; }
*/
}

- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp %ld", [theEvent clickCount] );

	// [x] : clickCount : zero is set when you dragged

	//if ( 1 != [theEvent clickCount] ) { return; }


	n_poker *p = &poker;

	BOOL draw = FALSE;

	if ( p->click_onoff[ 0 ] )
	{
		if ( n_poker_button_is_hovered( p, 0 ) )
		{
			p->button_is_clicked[ 0 ] = TRUE;
		}

		draw = TRUE;
	}

	if ( p->click_onoff[ 1 ] )
	{
		if ( n_poker_button_is_hovered( p, 1 ) )
		{
			p->button_is_clicked[ 1 ] = TRUE;
		}

		draw = TRUE;
	}

	p->click_onoff[ 0 ] = FALSE;
	p->click_onoff[ 1 ] = FALSE;

	if ( draw )
	{
		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_draw_button( p );
	}

//NSLog( @"Button %d %d", p->button_is_clicked[ 0 ], p->button_is_clicked[ 1 ] );

//NSLog( @"Button %d %d", n_poker_button_is_hovered( p, 0 ), n_poker_button_is_hovered( p, 1 ) );

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog( @"mouseDown %ld", [theEvent clickCount] );

	if ( 1 != [theEvent clickCount] ) { return; }

	n_poker *p = &poker;

	n_poker_on_click( p );
	p->draw_center = N_POKER_DRAW_CENTER_ALL;

	if ( n_poker_button_is_hovered( p, 0 ) )
	{
		p->click_onoff[ 0 ] = TRUE;

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_draw_button( p );
	}

	if ( n_poker_button_is_hovered( p, 1 ) )
	{
		p->click_onoff[ 1 ] = TRUE;

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_draw_button( p );
	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog(@"mouseDragged");

	n_poker *p = &poker;

	BOOL draw = FALSE;

	if ( FALSE == n_poker_button_is_hovered( p, 0 ) )
	{
		if ( p->click_onoff[ 0 ] )
		{
			p->click_onoff[ 0 ] = FALSE;
			draw = TRUE;
		}
	}

	if ( FALSE == n_poker_button_is_hovered( p, 1 ) )
	{
		if ( p->click_onoff[ 1 ] )
		{
			p->click_onoff[ 1 ] = FALSE;
			draw = TRUE;
		}
	}

	if ( draw )
	{
		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_draw_button( p );
	}

}




- (int) n_mac_game_coin_get
{
	n_poker *p = &poker;

	return p->coin;
}




- (void) n_mac_game_mode:(BOOL) endless_onoff
{

	n_poker *p = &poker;

	if ( endless_onoff )
	{
		p->game_mode = N_POKER_GAME_MODE_ENDLESS;
	} else {
		p->game_mode = N_POKER_GAME_MODE_BET;
		//p->coin      = N_POKER_COIN_DEFAULT;
		p->coin_prv  = 0;
	}

	n_poker_reset( p );

}


@end


#endif // _H_NONNON_MAC_NONNON_GAME


