// Nonnon Pinknoise for Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

//#define _UNICODE
//#define  UNICODE




#include "../nonnon/bridge/sound/directsound.c"

#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win64/ui/window.c"
#include "../nonnon/win64/ui/button.c"




#define N_PINKNOISE_APPNAME n_posix_literal( "Nonnon Pinknoise" )
#define N_PINKNOISE_ICONAME n_posix_literal( "MAIN_ICON" )




#define N_PINKNOISE_TIMER_INTERVAL 5000

#define N_PINKNOISE_ICON_SIZE 64




#define n_pinknoise_button_setup_literal( p, l, r ) n_pinknoise_button_setup( p, n_posix_literal( l ), n_posix_literal( r ) ) 

void
n_pinknoise_button_setup( n_win64_ui_button *p, n_posix_char *label, n_posix_char *resource_name )
{

	p->label         = label;
	p->resource_name = resource_name;

	n_win64_refresh( p->hwnd, FALSE );


	return;
}

LRESULT CALLBACK
n_pinknoise_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static n_directsound directsound;
	static n_wav         wav;
	static UINT          timer_id;

	static n_win64_ui_button button;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );


		// Window

		n_win64_ui_window_init( hwnd, N_PINKNOISE_APPNAME, N_PINKNOISE_ICONAME, N_STRING_EMPTY );
		n_win64_ui_window_set( hwnd, 0,0, 333,333, TRUE );

		{
			RECT c; GetClientRect( hwnd, &c );

			n_type_gfx icon_size = N_PINKNOISE_ICON_SIZE;

			n_type_gfx x = ( c.right  / 2 ) - ( icon_size / 2 );
			n_type_gfx y = ( c.bottom / 2 ) - ( icon_size / 2 );

			n_win64_ui_button_init( &button, hwnd );
			n_win64_ui_button_move( &button, x,y,icon_size,icon_size, FALSE );

			n_pinknoise_button_setup_literal( &button, "Pause", "N_NEKO_1" );
		}


		// Display

		//ShowWindow( hwnd, SW_HIDE );
		ShowWindow( hwnd, SW_NORMAL );


		// Pink Noise

		{
			const n_type_real output = 0.025;

			n_wav_zero( &wav );
			n_wav_new( &wav, N_PINKNOISE_TIMER_INTERVAL * 2 );
			n_wav_pinknoise( &wav, output, 0.75, 0.75 );

			n_directsound_zero( &directsound );
			BOOL ret = n_directsound_init( &directsound, hwnd, &wav );
			if ( ret ) { n_wav_free( &wav ); return -1; }

			n_directsound_loop( &directsound );
		}


		// Init

		if ( timer_id == 0 ) { timer_id = n_win64_timer_id_get(); }
		n_win64_timer_init( hwnd, timer_id, N_PINKNOISE_TIMER_INTERVAL );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wParam == 0 ) { break; }

		if ( wParam != timer_id ) { break; }

		if ( button.fake_onoff ) { break; }

		n_directsound_loop( &directsound );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );


		RECT rect; GetClientRect( hwnd, &rect );

		HBRUSH br = CreateSolidBrush( RGB( 222,222,222 ) );

		FillRect( ps.hdc, &rect, br );

		DeleteObject( br );


		EndPaint( hwnd, &ps );

		return 0;
	}
	break;


	case WM_COMMAND :

		if ( (HWND) lParam == button.hwnd )
		{
			static BOOL onoff = TRUE;
			if ( onoff )
			{
				onoff = FALSE;

				button.fake_onoff = TRUE;
				n_pinknoise_button_setup_literal( &button, "Play", "N_NEKO_2" );

				n_directsound_pause( &directsound );
			} else {
				onoff = TRUE;

				button.fake_onoff = FALSE;
				n_pinknoise_button_setup_literal( &button, "Pause", "N_NEKO_1" );

				n_directsound_resume( &directsound );
			}
		}

	break;

	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win64_timer_exit( hwnd, timer_id );

		n_win64_ui_button_exit( &button );

		n_directsound_exit( &directsound );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_pinknoise_wndproc );
}


