// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_game_init( void )
{
//return;

	n_hunyapiyo3 *p = &hunyapiyo3;

	n_hunyapiyo3_zero( p );


	n_hunyapiyo3_init( p );
//n_posix_debug_literal( "%d %d", p->sx, p->sy );
//return;


	game.sx = p->sx;
	game.sy = p->sy + p->bar;
/*
Size            393 419 
GetClientRect   0 0 387 390 
*/
//n_posix_debug_literal( "%d %d", game.sx, game.sy );

	n_game_bmp_init();


	// Init

	p->canvas = &game.bmp;

	n_hunyapiyo3_gdi_background( p, &p->bmp_bg );

	n_bmp_flush_fastcopy( &p->bmp_bg, p->canvas );

	n_bmp_carboncopy( &p->bmp_bg, &p->bmp_result );


	n_hunyapiyo3_sound_init( p, game.hwnd );


	n_hunyapiyo3_reset( p );


	n_win64_ui_window_init_literal( game.hwnd, "hunyapiyo3", "MAIN_ICON", "" );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );


	return;
}

void
n_game_loop( void )
{

	n_hunyapiyo3 *p = &hunyapiyo3;

	n_hunyapiyo3_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_hunyapiyo3 *p = &hunyapiyo3;

	n_hunyapiyo3_exit( p );

	n_hunyapiyo3_sound_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MOUSEMOVE :

		hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );

		n_win64_on_mousemove( hwnd );

	break;

	case WM_MOUSELEAVE :

		hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );

	break;


	case WM_LBUTTONDOWN :
//n_posix_debug_literal( "WM_LBUTTONDOWN" );

		if ( hunyapiyo3.animation_onoff ) { break; }

		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
			hunyapiyo3.button_press_offset = hunyapiyo3.button_press_offset_default;

			hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );
			n_hunyapiyo3_main( &hunyapiyo3 );
		} else
		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_PERC )
		{
			hunyapiyo3.button_press_offset = hunyapiyo3.button_press_offset_default;

			hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );
			n_hunyapiyo3_last( &hunyapiyo3 );
		}

		game.refresh = hunyapiyo3.refresh;

	break;

	case WM_LBUTTONUP :

		if ( hunyapiyo3.animation_onoff ) { break; }

		hunyapiyo3.click = TRUE;

		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_CLCK )
		{
			hunyapiyo3.phase = N_HUNYAPIYO3_PHASE_STRT;
		} else
		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
			hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );
			n_hunyapiyo3_main( &hunyapiyo3 );
		} else
		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_PERC )
		{
			hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );
			n_hunyapiyo3_last( &hunyapiyo3 );
		}

		hunyapiyo3.click = FALSE;

		game.refresh = hunyapiyo3.refresh;

	break;


	case WM_RBUTTONDOWN :

		if ( hunyapiyo3.animation_onoff ) { break; }

		hunyapiyo3.click_menu = TRUE;

		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
			hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );
			n_hunyapiyo3_main( &hunyapiyo3 );
		} else
		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_PERC )
		{
			if ( hunyapiyo3.answer_check_onoff )
			{
				n_hunyapiyo3_sound_play( &hunyapiyo3, N_HUNYAPIYO3_SOUND_CLICK );
				hunyapiyo3.answer_check_onoff = FALSE;
			} else {
				n_hunyapiyo3_sound_play( &hunyapiyo3, N_HUNYAPIYO3_SOUND_CLICK );
				hunyapiyo3.answer_check_onoff = TRUE;
			}

			hunyapiyo3.pt = n_win64_cursor_position_relative_POINT( game.hwnd );
			n_hunyapiyo3_last( &hunyapiyo3 );
		}

		hunyapiyo3.click_menu = FALSE;

		game.refresh = hunyapiyo3.refresh;

	break;


	case WM_MOUSEWHEEL :

		if ( hunyapiyo3.animation_onoff ) { break; }

		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
//n_posix_debug_literal( "%d", n_win64_scroll_wheeldelta( wparam, 1 ) );

			if ( 0 < n_win64_scroll_wheeldelta( wparam, 1 ) )
			{
				hunyapiyo3.click      = TRUE;	
			} else {
				hunyapiyo3.click_menu = TRUE;
			}
			n_hunyapiyo3_main( &hunyapiyo3 );

			hunyapiyo3.click = hunyapiyo3.click_menu = n_posix_false;
		}

		game.refresh = hunyapiyo3.refresh;

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

