// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




typedef struct {


	// [ Needed ] : you need to set at n_game_init()
	//
	//	needpos : initial position is needed
	//	x/y     : window position : default is centering
	//	sx/sy   : canvas size
	//	fps     : frames per sec
	//	color   : default back ground color

	s32  x,y,sx,sy;
	u32  fps;
	u32  color;


	// [ Optional ]
	//
	//	esc2exit : an application will close when Esc key is pressed over 5sec.

	BOOL esc2exit;


	// [ Internal ] : automatically manage by the game layer
	//
	//	hwnd      : a main window
	//	bmp       : a main canvas
	//	refresh   : painting request
	//
	//	is_active : is main window active or not
	//	is_closed : WM_CLOSE is called
	//	ime_onoff : is "Input Method Editor" running or not

	HWND  hwnd;
	n_bmp bmp;
	int   refresh;

	BOOL is_active;
	BOOL is_closed;
	BOOL ime_onoff;


	// [ Internal ] : cache : don't touch these members

	HBITMAP    hbmp;
	BITMAPINFO bi;

	u32        frame_msec;
	u32         misc_msec;
	u32         loop_msec;
	u32         loop_tmr;


} n_game;


static n_game game;


// [ Needed ]

// [ Mechanism ]
//
//	[ n_game_init() ]
//
//		Nonnon Game Layer will call this...
//		+ before back-buffer (game.bmp) is made
//		+ after a window (game.hwnd) is made
//
//	[ n_game_loop() ]
//
//		you need to call refresh = TRUE; to redraw
//
//	[ n_game_exit() ]
//
//		Nonnon Game Layer will call this...
//		+ after game.hwnd and game.bmp are freed

extern void n_game_init( void );
extern void n_game_loop( void );
extern void n_game_exit( void );

extern LRESULT CALLBACK n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam );



// [!] : helper functions and macros

#define n_game_hwndprintf(         f, ... ) n_win64_hwndprintf(         game.hwnd, f, ##__VA_ARGS__ )
#define n_game_hwndprintf_literal( f, ... ) n_win64_hwndprintf_literal( game.hwnd, f, ##__VA_ARGS__ )
#define n_game_debug_count(               ) n_win64_debug_count( game.hwnd )




void
n_game_clear( u32 color )
{

	n_bmp_flush( &game.bmp, color );

	return;
}




// internal
void
n_game_bmp_exit( void )
{

	n_win64_dibsection_exit( &game.hbmp, &game.bmp );


	return;
}

// internal
void
n_game_bmp_init( void )
{

	// [!] : anti-fault

	if ( game.sx <= 0 ) { game.sx = 1; }
	if ( game.sy <= 0 ) { game.sy = 1; }


	n_win64_dibsection_init( &game.hbmp, &game.bmp, game.hwnd, NULL, game.sx,game.sy );


	n_game_clear( game.color );


	return;
}

// internal
void
n_game_esc2exit( void )
{

	if ( game.esc2exit == FALSE ) { return; }


	BOOL is_escape = n_win64_is_input( VK_ESCAPE );

	if ( ( game.is_active )&&( game.ime_onoff == FALSE )&&( is_escape ) )
	{

		const u32 timeout_max = 0xffffffff;
		const u32 wait_msec   = 5000;

		// [x] : GCC4 complains when use "static u32 timeout = timeout_max;"

		static BOOL is_start = FALSE;
		static u32  timeout  = 0xffffffff;

		if ( is_start == FALSE )
		{
			is_start = TRUE;
			timeout  = n_posix_tickcount() + wait_msec;
		}

		if ( timeout <= n_posix_tickcount() )
		{

			is_start = FALSE;
			timeout  = timeout_max;

			if ( ( game.ime_onoff == FALSE )&&( is_escape ) )
			{
				n_win64_message_send( game.hwnd, WM_CLOSE, 0,0 );
			}

		}

	}


	return;
}

// internal
void
n_game_on_paint( void )
{
//u32 tick = n_posix_tickcount();

	{
		HDC hdc = GetDC( game.hwnd );

		HDC     hdc_compat = CreateCompatibleDC( hdc );
		HBITMAP hbmp_old   = SelectObject( hdc_compat, game.hbmp );

		BitBlt( hdc, 0,0,game.sx,game.sy, hdc_compat, 0,0, SRCCOPY );

		SelectObject( hdc_compat, hbmp_old );
		DeleteDC( hdc_compat );

		ReleaseDC( game.hwnd, hdc );
	}

//n_game_hwndprintf_literal( "%d", (int) n_posix_tickcount() - tick );
	return;
}

// internal
void
n_game_on_paint_partial( s32 x, s32 y, s32 sx, s32 sy )
{

	HDC hdc = GetDC( game.hwnd );

	{
		HDC     hdc_compat = CreateCompatibleDC( hdc );
		HBITMAP hbmp_old   = SelectObject( hdc_compat, game.hbmp );

		BitBlt( hdc, x,y,sx,sy, hdc_compat, x,y, SRCCOPY );

		SelectObject( hdc_compat, hbmp_old );
		DeleteDC( hdc_compat );
	}


	ReleaseDC( game.hwnd, hdc );


	return;
}

LRESULT CALLBACK
n_game_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_IME_STARTCOMPOSITION :

		game.ime_onoff = TRUE;

	break;

	case WM_IME_ENDCOMPOSITION :

		game.ime_onoff = FALSE;

	break;


	case WM_ACTIVATE :

		//game.is_active = wparam;

	break;


	case WM_CREATE :

		game.hwnd = hwnd;

		ShowWindow( hwnd, SW_HIDE );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :

		// [!] : multi-threaded rendering

		// [!] : WinXP/2003 : PeekMessage() never send WM_PAINT when WS_OVERLAPPEDWINDOW

		n_game_on_paint();

		// [!] : this causes redraw error with child windows

		//return 0;

	break;


	case WM_SYSCOMMAND :

		if ( wparam == SC_MONITORPOWER )
		{
//n_posix_debug_literal( "SC_MONITORPOWER : %d", lparam );

			if ( lparam == 2 ) { return 0; }

		} else
		if ( wparam == SC_SCREENSAVE )
		{
//n_posix_debug_literal( "SC_SCREENSAVE" );

			return 0;

		}// else

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		game.is_closed = TRUE;

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return n_game_DefWindowProc( hwnd, msg, wparam, lparam );
	//return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{

	// Initialization

	n_random_shuffle();

	n_win64_exedir2curdir();


	// Window

	n_memory_zero( &game, sizeof( n_game ) );

	game.x        =  -1;
	game.y        =  -1;
	game.sx       = 320;
	game.sy       = 240;
	game.fps      =  30;
	game.esc2exit = TRUE;


	game.hwnd = n_win64_ui_window( NULL, n_game_wndproc );
//n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	n_game_init();


	// Start Game Loop

	n_game_loop();

	ShowWindowAsync( game.hwnd, SW_NORMAL );

	MSG msg;
	n_posix_loop
	{

		// [x] : buggy : don't use GetFocus() and GetActiveWindow()
		//
		//	TRUE is returned when an inactive window

		game.is_active = ( game.hwnd == GetForegroundWindow() );
		game.misc_msec = n_posix_tickcount();


		// Forced Shutdown : PostMessage() may cause busy

		n_game_esc2exit();


		if ( n_win64_message_peek( &msg ) )
		{
			if ( msg.message == WM_QUIT ) { break; }

			TranslateMessage( &msg );
			DispatchMessage ( &msg );
		}


		BOOL frame_onoff =
		(
			( game.is_active )
			&&
			( n_bmp_ui_timer( &game.loop_tmr, game.loop_msec ) )
		);


		game.misc_msec = n_posix_tickcount() - game.misc_msec;


		if ( frame_onoff )
		{

			game.loop_msec = n_posix_tickcount();

			n_game_loop();

			game.loop_msec = n_posix_tickcount() - game.loop_msec;


			game.loop_msec += game.misc_msec;

			if ( game.frame_msec > game.loop_msec )
			{
				game.loop_msec = game.frame_msec - game.loop_msec;
			} else {
				game.loop_msec = 0;
			}


			if ( game.refresh )
			{

				game.refresh = FALSE;

				// [Mechanism] : slower to faster
				//
				//	1 : InvalidateRect()
				//	2 : n_game_on_paint()
				//	3 : SendMessage()
				//	4 : PostMessage()        : UI response will be slowdown 
				//	5 : SendMessageTimeout()

				SendMessageTimeout( game.hwnd, WM_PAINT, 0,0, SMTO_ABORTIFHUNG, game.loop_msec, NULL );

			}

		}


		n_posix_sleep( 1 );

	} // n_posix_loop


	// Cleanup

	n_game_exit();


	n_memory_debug_refcount();


	return (int) msg.wParam;
}


