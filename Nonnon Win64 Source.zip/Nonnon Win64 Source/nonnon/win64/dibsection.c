// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_GDI_DIBSECTION
#define _H_NONNON_WIN64_GDI_DIBSECTION




#include "../neutral/bmp.c"
#include "../neutral/bmp/_fastcopy.c"




void
n_win64_dibsection_zero( HBITMAP *h, n_bmp *b )
{

	(*h) = NULL;

	n_bmp_zero( b );


	return;
}

void
n_win64_dibsection_exit( HBITMAP *h, n_bmp *b )
{

	if ( h != NULL )
	{
		DeleteObject( (*h) );
		(*h) = NULL;
	}


	// [!] : don't use n_bmp_free() : double-free

	n_bmp_zero( b );


	return;
}

void
n_win64_dibsection_init( HBITMAP *h, n_bmp *b, HWND hwnd, HDC hdc, n_type_gfx sx, n_type_gfx sy )
{

	n_posix_bool upsidedown = ( sy < 0 );

	if ( upsidedown ) { sy = abs( sy ); }


	// [!] : fail-safe

	if ( ( sx <= 0 )||( sy <= 0 ) )
	{
//n_posix_debug_literal( "Invalid Size : %d : %d", (int) sx, (int) sy );

		return;
	}


	n_win64_dibsection_exit( h, b );


	n_bmp_header( b, sx,sy );


	n_posix_bool getdc_onoff = n_posix_false;

	if ( hdc == NULL )
	{
		getdc_onoff = n_posix_true;
		hdc = GetDC( hwnd );
	}

	BITMAPINFO bi = { N_BMP_INFOH( b ), { { 0,0,0,0 } } };

	if ( upsidedown ) { bi.bmiHeader.biHeight *= -1; }

	(*h) = CreateDIBSection
	(
		hdc,
		&bi,
		DIB_RGB_COLORS,
		(void**) &N_BMP_PTR( b ),
		NULL,
		0
	);

	if ( getdc_onoff )
	{
		ReleaseDC( hwnd, hdc );
	}


	return;
}


#endif // _H_NONNON_WIN64_GDI_DIBSECTION

