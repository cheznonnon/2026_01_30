// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_RESOURCE
#define _H_NONNON_WIN64_RESOURCE




#include "../neutral/posix.c"


#include "../neutral/bmp/all.c"
#include "../neutral/wav.c"




BOOL
n_win64_resource_load
(
	const n_posix_char  *name,
	const n_posix_char  *sect,
	                u8 **rc,
	      n_type_int    *rc_byte
)
{

	HINSTANCE hinst = GetModuleHandle( NULL );


	HRSRC hrc = FindResource( hinst, name, sect );
	if ( hrc == NULL ) { return TRUE; }


	HGLOBAL hglobal = LoadResource( hinst, hrc );
	if ( hglobal == NULL )
	{
		CloseHandle( hrc );

		return TRUE;
	}


	u8         *ptr      = LockResource( hglobal );
	n_type_int  ptr_byte = SizeofResource( hinst, hrc );

	if ( rc != NULL )
	{
		(*rc) = n_memory_new( ptr_byte );
		n_memory_copy( ptr, (*rc), ptr_byte );
	}

	if ( rc_byte != NULL )
	{
		(*rc_byte) = ptr_byte;
	}

	// [!] : -Wall says "no effect"
	//UnlockResource( hglobal );


	FreeResource( hglobal );


	//CloseHandle( hrc );


	return FALSE;
}

BOOL
n_win64_resource_load_nbmp( const n_posix_char *name, n_bmp *bmp )
{

	u8         *ptr;
	n_type_int  byte;

	BOOL ret = n_win64_resource_load( name, n_posix_literal( "DATA" ), &ptr, &byte );
	if ( ret ) { return TRUE; }


	ret = n_bmp_load_onmemory( bmp, ptr, byte );
	if ( ret ) { return TRUE; }


	return ret;
}

BOOL
n_win64_resource_load_nwav( const n_posix_char *name, n_wav *wav )
{

	u8         *ptr;
	n_type_int  byte;

	BOOL ret = n_win64_resource_load( name, n_posix_literal( "DATA" ), &ptr, &byte );
	if ( ret ) { return TRUE; }


	ret = n_wav_load_onmemory( wav, ptr, byte );
	if ( ret ) { return TRUE; }


	return ret;
}

#define n_win64_resource_save_literal( a,b,c ) n_win64_resource_save( n_posix_literal( a ), n_posix_literal( b ), n_posix_literal( c ) )

BOOL
n_win64_resource_save
(
	const n_posix_char *name,
	const n_posix_char *sect,
	const n_posix_char *fname
)
{

	FILE *fp = n_posix_fopen_write( fname );
	if ( fp == NULL ) { return TRUE; }


	u8         *ptr;
	n_type_int  byte;

	BOOL ret = n_win64_resource_load( name, sect, &ptr, &byte );

	n_posix_fwrite( ptr, byte, 1, fp );

	n_memory_free_closed( ptr );


	n_posix_fclose( fp );


	return ret;
}


#endif // _H_NONNON_WIN64_RESOURCE

