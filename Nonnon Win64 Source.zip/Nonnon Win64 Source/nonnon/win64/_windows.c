// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_WINDOWS
#define _H_NONNON_WIN64_WINDOWS




#include "../neutral/posix.c"




#include <imm.h>




#include "../neutral/string_path.c"






#define n_win64_hwndprintf_literal( h, f, ... ) n_win64_hwndprintf( h, n_posix_literal( f ), ##__VA_ARGS__ )

void
n_win64_hwndprintf( HWND hwnd, const n_posix_char *format, ... )
{

	n_posix_char str[ 1024 ];


	va_list vl;


	va_start( vl, format );

#ifdef N_POSIX_PLATFORM_MINGW64
#ifdef UNICODE
	n_posix_vsprintf( str, 1024, format, vl );
#else
	n_posix_vsprintf( str,       format, vl );
#endif
#else
	n_posix_vsprintf( str,       format, vl );
#endif

	va_end( vl );


	SetWindowText( hwnd, str );


	return;
}

// internal
void
n_win64_debug_count( HWND hwnd )
{

	static n_type_int i = 0;

	n_win64_hwndprintf_literal( hwnd, "%lld", i );

	i++;

	return;
}




void
n_win64_refresh( HWND hwnd, n_posix_bool strong_mode )
{
//return;

	if ( hwnd == NULL ) { return; }
	if ( n_posix_false == IsWindow( hwnd ) ) { return; }


	InvalidateRect( hwnd, NULL, strong_mode );


	return;
}




#define n_win64_message_send( h, m, w, l ) SendMessage( h, m, (WPARAM) (w), (LPARAM) (l) )
#define n_win64_message_post( h, m, w, l ) PostMessage( h, m, (WPARAM) (w), (LPARAM) (l) )

BOOL
n_win64_message_peek( MSG *msg )
{
	return PeekMessage( msg, NULL, 0, 0, PM_REMOVE );
}

MSG
n_win64_message_remove( void )
{

	MSG msg;

	PeekMessage( &msg, NULL, 0, 0, PM_REMOVE );

	return msg;
}




void
n_win64_rect_expand_size( RECT *r, n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	RECT r_zero = { 0,0,0,0 };
	if ( r == NULL ) { r = &r_zero; }

	if (  x != NULL ) { (* x) = r->left;             }
	if (  y != NULL ) { (* y) = r->top;              }
	if ( sx != NULL ) { (*sx) = r->right  - r->left; }
	if ( sy != NULL ) { (*sy) = r->bottom - r->top;  }


	return;
}




static UINT n_win64_timer_id = 0;

UINT
n_win64_timer_id_get( void )
{
	n_win64_timer_id++;
	return n_win64_timer_id;
}

void
n_win64_timer_init( HWND hwnd, UINT id, DWORD msec )
{

	// [!] : prevent handle leak
	KillTimer( hwnd, id );

	SetTimer( hwnd, id, msec, NULL );

	return;
}

void
n_win64_timer_exit( HWND hwnd, UINT id )
{

	KillTimer( hwnd, id );

	return;
}




n_posix_bool
n_win64_is_input_raw( int vk )
{
	return ( n_posix_false != ( 0x8000 & GetAsyncKeyState( vk ) ) );
}

n_posix_bool
n_win64_is_input( int vk )
{

	if ( vk == VK_LBUTTON )
	{
		if ( GetSystemMetrics( SM_SWAPBUTTON ) ) { vk = VK_RBUTTON; }
	} else
	if ( vk == VK_RBUTTON )
	{
		if ( GetSystemMetrics( SM_SWAPBUTTON ) ) { vk = VK_LBUTTON; }
	}


	return n_win64_is_input_raw( vk );
}

void
n_win64_input( int vk1, int vk2 )
{

	const int u = KEYEVENTF_KEYUP;


	if ( vk1 ) { keybd_event( vk1, 0, 0, 0 ); }
	if ( vk2 ) { keybd_event( vk2, 0, 0, 0 ); }
	if ( vk1 ) { keybd_event( vk1, 0, u, 0 ); }
	if ( vk2 ) { keybd_event( vk2, 0, u, 0 ); }


	return;
}




#define n_win64_cursor_position( x, y ) n_win64_cursor_position_relative( NULL, x, y )

void
n_win64_cursor_position_relative( HWND hwnd_parent, n_type_gfx *x, n_type_gfx *y )
{

	POINT p; GetCursorPos( &p );

	ScreenToClient( hwnd_parent, &p );

	if ( x != NULL ) { (*x) = p.x; }
	if ( y != NULL ) { (*y) = p.y; }


	return;
}

POINT
n_win64_cursor_position_relative_POINT( HWND hwnd_parent )
{

	POINT p; GetCursorPos( &p );

	ScreenToClient( hwnd_parent, &p );

	return p;
}




n_type_int
n_win64_exepath_cch( void )
{

	// [x] : WinXP or earlier : GetModuleFileName() always succeed
	//
	//	GetLastError() returns zero

	n_type_int cch = MAX_PATH;
	n_posix_loop
	{//break;

		DWORD dw_ret = 0;

		n_posix_char *str = n_string_new( cch );

		if ( str != NULL )
		{
			GetModuleFileName( NULL, str, (DWORD) cch );
			dw_ret = GetLastError();
		}

		n_string_free( str );

		if ( dw_ret == ERROR_INSUFFICIENT_BUFFER )
		{
			cch++;
		} else {
//n_posix_debug_litral( " %d ", (int) dw_ret );
			break;
		}

	}


	return cch;
}

void
n_win64_exepath( n_posix_char *str, n_type_int cch )
{

	if ( str == NULL ) { return; }
	if ( cch <= 0 ) { n_string_truncate( str ); return; }


	n_string_zero( str, cch );


	// [Mechanism] : GetLastError()
	//
	//	ERROR_FILE_NOT_FOUND(2) will be returned in some versions
	//
	//	9x	ERROR_SUCCESS
	//	NT4.0	ERROR_FILE_NOT_FOUND
	//	2000	ERROR_FILE_NOT_FOUND
	//	XP	ERROR_FILE_NOT_FOUND
	//	8.1	ERROR_SUCCESS
	//
	//	ERROR_INSUFFICIENT_BUFFER(122) will be returned when lack of buffer

	DWORD ret = GetModuleFileName( NULL, str, (DWORD) cch );
	DWORD err = GetLastError();
//n_posix_debug_literal( "%s : %d : %d", str, ret, err );

	if ( ( ret == 0 )||( err == ERROR_INSUFFICIENT_BUFFER ) ) { n_string_truncate( str ); }


	return;
}

n_posix_char*
n_win64_exepath_new( void )
{

	// [!] : you need to n_string_path_free() a returned variable

	n_type_int    cch = n_win64_exepath_cch();
	n_posix_char *ret = n_string_path_new( cch );


	n_win64_exepath( ret, cch );


	return ret;
}

void
n_win64_exedir2curdir( void )
{

	n_posix_char *exe = n_win64_exepath_new();
//n_posix_debug( exe );

	n_string_path_folder_change( exe );

	n_string_path_free( exe );


	return;
}




void
n_win64_ime_onoff( HWND hwnd, BOOL onoff )
{

	if ( onoff )
	{
		ImmAssociateContext( hwnd, ImmCreateContext() );
	} else {
		ImmAssociateContext( hwnd, NULL );
	}


	return;
}




#define n_win64_style(   h, s, o ) n_win64_style_set( h, s, o, n_posix_false )
#define n_win64_exstyle( h, s, o ) n_win64_style_set( h, s, o, n_posix_true  )

#define N_WIN64_STYLE_NEW 0
#define N_WIN64_STYLE_ADD 1
#define N_WIN64_STYLE_DEL 2

#define n_win64_style_new(   h, s ) n_win64_style(   h, s, N_WIN64_STYLE_NEW )
#define n_win64_style_add(   h, s ) n_win64_style(   h, s, N_WIN64_STYLE_ADD )
#define n_win64_style_del(   h, s ) n_win64_style(   h, s, N_WIN64_STYLE_DEL )
#define n_win64_exstyle_new( h, s ) n_win64_exstyle( h, s, N_WIN64_STYLE_NEW )
#define n_win64_exstyle_add( h, s ) n_win64_exstyle( h, s, N_WIN64_STYLE_ADD )
#define n_win64_exstyle_del( h, s ) n_win64_exstyle( h, s, N_WIN64_STYLE_DEL )

#define n_win64_style_get(   h ) GetWindowLong( h, GWL_STYLE   )
#define n_win64_exstyle_get( h ) GetWindowLong( h, GWL_EXSTYLE )

void
n_win64_style_set( HWND hwnd, DWORD style, int option, n_posix_bool is_ex )
{

	int gwl = GWL_STYLE;
	if ( is_ex ) { gwl = GWL_EXSTYLE; }


	if ( option == N_WIN64_STYLE_ADD )
	{

		style |= GetWindowLong( hwnd, gwl );

	} else
	if ( option == N_WIN64_STYLE_DEL )
	{

		// [Mechanism]
		//
		//	             : & : | : ^
		//	#1 : 0-0     : 0 : 0 : 0
		//	#2 : 1-1     : 1 : 1 : 0
		//	#3 : 0-1/1-0 : 0 : 1 : 1
		//
		//	1001 = GetWindowLong()
		//	1000 = style
		//
		//	BINARY :  1000 ^ 1111 = 0111
		//	BINARY : ~1000        = 0111
		//	BINARY :  1001 & 0111 = 0001

		style = GetWindowLong( hwnd, gwl ) & (~style);

	}

	SetWindowLong( hwnd, gwl, style );


	return;
}





void
n_win64_on_mousemove( HWND hwnd )
{

	// [ Mechanism ]
	//
	//	call this module in WM_MOUSEMOVE
	//	then WM_MOUSEHOVER and WM_MOUSELEAVE are sent


	// [MSDN] : use tme.dwHoverTime = HOVER_DEFAULT;
	//
	//	but WinXP/Vista/7 always use 1


	TRACKMOUSEEVENT tme;

	tme.cbSize      = sizeof( TRACKMOUSEEVENT );
	tme.dwFlags     = TME_HOVER | TME_LEAVE;
	tme.hwndTrack   = hwnd;
	tme.dwHoverTime = 1;//HOVER_DEFAULT;

	TrackMouseEvent( &tme );


	return;
}




int
n_win64_scroll_wheeldelta( WPARAM wparam, UINT unit )
{

	int delta = (s16) HIWORD( wparam ) / WHEEL_DELTA;
	if ( delta == 0 ) { return 0; } else { delta *= -1; }


	if ( unit == 0 )
	{
		SystemParametersInfo( SPI_GETWHEELSCROLLLINES, 0, &unit, 0 );
	}


	return unit * delta;
}


#endif // _H_NONNON_WIN64_WINDOWS


