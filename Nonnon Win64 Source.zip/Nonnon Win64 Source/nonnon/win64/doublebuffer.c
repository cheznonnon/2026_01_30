// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Ownerdrawn Control ]
//
//	use at WM_DRAWITEM
//
//	[ Upside Down ]
//
//	you can use two way
//
//	+ 1 : set "sy" minus value
//	+ 2 : set ".upsidedown" TRUE




#ifndef _H_NONNON_WIN64_DOUBLEBUFFER
#define _H_NONNON_WIN64_DOUBLEBUFFER




#include "../neutral/bmp/all.c"


#include "./dibsection.c"




typedef struct {

	HWND         hgui;
	HDC          hdc;
	HDC          hdc_compat;
	int          bpp;
	n_type_gfx   sx;
	n_type_gfx   sy;
	HBITMAP      hbmp;
	HBITMAP      hbmp_old;
	n_bmp        bmp;
	BOOL         upsidedown;
	BOOL         hdc_release;

} n_win64_doublebuffer;

#define n_win64_doublebuffer_zero( p ) n_memory_zero( p, sizeof( n_win64_doublebuffer ) )




static n_win64_doublebuffer n_win64_doublebuffer_instance;

#define n_win64_doublebuffer_simple_init( hgui, sx, sy ) n_win64_doublebuffer_init( &n_win64_doublebuffer_instance, hgui, NULL, sx, sy )
#define n_win64_doublebuffer_simple_exit(              ) n_win64_doublebuffer_exit( &n_win64_doublebuffer_instance                     )
#define n_win64_doublebuffer_simple_fill( colorref     ) n_win64_doublebuffer_fill( &n_win64_doublebuffer_instance,           colorref )

void
n_win64_doublebuffer_simple_zero( void )
{

	// [!] : for gcc warning

	n_win64_doublebuffer_zero( &n_win64_doublebuffer_instance );

	return;
}

#define n_win64_doublebuffer_simple_cleanup() n_win64_doublebuffer_cleanup( &n_win64_doublebuffer_instance )

#define n_win64_doublebuffer_simple_visible() n_win64_doublebuffer_visible( &n_win64_doublebuffer_instance )

#define n_win64_doublebuffer_simple_exit_partial( x,y,sx,sy ) n_win64_doublebuffer_exit_partial( &n_win64_doublebuffer_instance, x,y,sx,sy )




HDC
n_win64_doublebuffer_init( n_win64_doublebuffer *p, HWND hgui, HDC hdc, n_type_gfx sx, n_type_gfx sy )
{

	// [!] : use returned HDC to draw


	// [!] : race condition : prevent GDI handle leak

	if ( p->hdc != NULL ) { return p->hdc_compat; }


	// Init

	n_win64_doublebuffer_zero( p );

	if ( hdc == NULL )
	{
		hdc = GetDC( hgui );
		p->hdc_release = n_posix_true;
	} else {
		p->hdc_release = n_posix_false;
	}

	p->hgui       = hgui;
	p->hdc        = hdc;
	p->hdc_compat = CreateCompatibleDC( p->hdc );
	p->bpp        = 32;//GetDeviceCaps( p->hdc, BITSPIXEL );
	p->sx         = n_posix_max_n_type_gfx( 1, abs( sx ) );
	p->sy         = n_posix_max_n_type_gfx( 1, abs( sy ) );


	n_type_gfx upsidedown = 1; if ( sy < 0 ) { upsidedown = -1; }


	n_win64_dibsection_zero( &p->hbmp, &p->bmp );
	n_win64_dibsection_init( &p->hbmp, &p->bmp, p->hgui, p->hdc_compat, p->sx, p->sy * upsidedown );


	p->hbmp_old = SelectObject( p->hdc_compat, p->hbmp );


	return p->hdc_compat;
}

void
n_win64_doublebuffer_cleanup( n_win64_doublebuffer *p )
{

	SelectObject( p->hdc_compat, p->hbmp_old );

	n_win64_dibsection_exit( &p->hbmp, &p->bmp );


	DeleteDC( p->hdc_compat );

	if ( p->hdc_release )
	{
		ReleaseDC( p->hgui, p->hdc );
	}


	n_win64_doublebuffer_zero( p );


	return;
}

#define n_win64_doublebuffer_presync(  p ) n_win64_doublebuffer_sync_partial( p, 0,0,(p)->sx,(p)->sy, n_posix_true  )
#define n_win64_doublebuffer_postsync( p ) n_win64_doublebuffer_sync_partial( p, 0,0,(p)->sx,(p)->sy, n_posix_false )

void
n_win64_doublebuffer_sync_partial( n_win64_doublebuffer *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool is_pre )
{

	// [Mechanism]
	//
	//	Pre  : Window      => Back Buffer
	//	Post : Back Buffer => Window

	if ( p->upsidedown )
	{

		n_type_gfx ty = 0;
		n_posix_loop
		{

			n_type_gfx target_fy = y + sy - 1 - ty;
			n_type_gfx target_ty = y + ty;

			if ( is_pre )
			{
				BitBlt( p->hdc_compat, x,target_fy,sx,1, p->hdc       , x,target_ty, SRCCOPY );
			} else {
				BitBlt( p->hdc       , x,target_fy,sx,1, p->hdc_compat, x,target_ty, SRCCOPY );
			}

			ty++;
			if ( ty >= sy ) { break; }
		}

	} else {

		if ( is_pre )
		{
			BitBlt( p->hdc_compat, x,y,sx,sy, p->hdc       , x,y, SRCCOPY );
		} else {
			BitBlt( p->hdc       , x,y,sx,sy, p->hdc_compat, x,y, SRCCOPY );
		}

	}


	return;
}

#define n_win64_doublebuffer_exit( p ) n_win64_doublebuffer_exit_partial( p, 0,0,(p)->sx,(p)->sy )

void
n_win64_doublebuffer_exit_partial( n_win64_doublebuffer *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	// Post Sync

	n_win64_doublebuffer_sync_partial( p, x,y,sx,sy, n_posix_false );

	n_win64_doublebuffer_cleanup( p );


	return;
}




u32
n_win64_doublebuffer_colorref2argb( HWND hwnd, COLORREF color )
{

	n_win64_doublebuffer db; n_win64_doublebuffer_zero( &db );

	n_win64_doublebuffer_init( &db, hwnd, NULL, 1,1 );

	color = n_bmp_colorref2argb( color );

	n_win64_doublebuffer_cleanup( &db );


	return n_bmp_alpha_visible_pixel( color );
}

void
n_win64_doublebuffer_fill( n_win64_doublebuffer *p, COLORREF color )
{

	n_bmp_flush( &p->bmp, n_win64_doublebuffer_colorref2argb( p->hgui, color ) );

	return;
}

void
n_win64_doublebuffer_mix( n_win64_doublebuffer *p, COLORREF color_t, double blend )
{

	n_bmp_flush_mixer( &p->bmp, n_win64_doublebuffer_colorref2argb( p->hgui, color_t ), blend );

	return;
}

void
n_win64_doublebuffer_visible( n_win64_doublebuffer *p )
{

	n_bmp_alpha_visible( &p->bmp );

	return;
}


#endif // _H_NONNON_WIN64_DOUBLEBUFFER

