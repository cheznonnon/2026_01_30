// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Win11 : not working



// [!] : <shellapi.h>




#ifndef _H_NONNON_WIN64_SYSTEMTRAY
#define _H_NONNON_WIN64_SYSTEMTRAY




#include "../neutral/posix.c"




// [!] : don't use WM_USER

#define N_WIN64_SYSTEMTRAY_MESSAGE WM_APP




#define n_win64_systemtray_init_literal( a,b,c,d,e,f ) n_win64_systemtray_init( a, b, c, n_posix_literal( d ), n_posix_literal( e ), f )

void
n_win64_systemtray_init
(
	      NOTIFYICONDATA *nid,
	                HWND  hwnd,
	                UINT  id,
	        n_posix_char *icon,
	const   n_posix_char *tip,
	                BOOL  draw
)
{

	if ( nid == NULL ) { return; }


	// [Mechanism]
	//
	//	icon : icon resource name


	HINSTANCE hinst = GetModuleHandle( NULL );


	nid->cbSize           = sizeof( NOTIFYICONDATA );
	nid->hWnd             = hwnd;
	nid->uID              = id;
	nid->uFlags           = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	nid->uCallbackMessage = N_WIN64_SYSTEMTRAY_MESSAGE;
	nid->hIcon            = LoadImage( hinst, icon, IMAGE_ICON, 0,0, LR_DEFAULTCOLOR );


	// [!] : WinXP : notify area manager uses this data

	if ( 64 > n_posix_strlen( tip ) )
	{
		n_posix_sprintf_literal( nid->szTip, "%s", tip );
	}


	if ( draw )
	{
		Shell_NotifyIcon( NIM_ADD, nid );
	}


	return;
}

void
n_win64_systemtray_exit( NOTIFYICONDATA *nid )
{

	if ( nid == NULL ) { return; }


	Shell_NotifyIcon( NIM_DELETE, nid );


	// [Needed] : prevent handle leak

	DestroyIcon( nid->hIcon );


	ZeroMemory( nid, sizeof( NOTIFYICONDATA ) );


	return;
}

void
n_win64_systemtray_icon_change( NOTIFYICONDATA *nid, const n_posix_char *icon )
{

	if ( nid == NULL ) { return; }


	HINSTANCE hinst = GetModuleHandle( NULL );


	DestroyIcon( nid->hIcon );

	nid->hIcon = LoadImage( hinst, icon, IMAGE_ICON, 0,0, LR_DEFAULTCOLOR );

	Shell_NotifyIcon( NIM_MODIFY, nid );


	return;
}


#endif // _H_NONNON_WIN64_SYSTEMTRAY

