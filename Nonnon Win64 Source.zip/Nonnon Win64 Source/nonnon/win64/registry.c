// Marie Registry Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_REGISTRY
#define _H_NONNON_WIN64_REGISTRY




#include "../neutral/posix.c"




#define n_win64_registry_read_valuebyte_literal( a, b, c ) \
        n_win64_registry_read_valuebyte( a, n_posix_literal( b ), n_posix_literal( c ) )

DWORD
n_win64_registry_read_valuebyte
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval
)
{

	// [!] : REG_SZ : returned value includes size for NUL('\0')


	// [ MSDN ] : size limit
	//
	//	path :   255 characters
	//	lval : 16383 characters
	//	rval : available memory


	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		hive,
		path,
		0,
		KEY_READ,
		&hkey
	);

	if ( ret != ERROR_SUCCESS ) { return 0; }


	ret = 0;
	RegQueryValueEx( hkey, lval, NULL, NULL, (LPBYTE) NULL, &ret );


	RegCloseKey( hkey );


	return ret;
}

#define n_win64_registry_is_exist_literal( a, b, c ) \
        n_win64_registry_is_exist( a, n_posix_literal( b ), n_posix_literal( c ) )

DWORD
n_win64_registry_is_exist
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval
)
{

	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		hive,
		path,
		0,
		KEY_READ,
		&hkey
	);

	if ( ret == ERROR_SUCCESS )
	{

		// [!] : ERROR_SUCCESS will be returned when "lval" is NULL

		if ( lval == NULL )
		{
			ret = ERROR_FILE_NOT_FOUND;
		} else {
			ret = RegQueryValueEx( hkey, lval, NULL, NULL, NULL, NULL );
		}

	}

	RegCloseKey( hkey );


	return ( ret == ERROR_SUCCESS );
}

#define n_win64_registry_read_literal( a, b, c, d, e ) \
        n_win64_registry_read( a, n_posix_literal( b ), n_posix_literal( c ), d, e )

DWORD
n_win64_registry_read
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval,
	      void         *rval,
	      DWORD         byte
)
{

	// [!] : REG_SZ : "byte" includes size for NUL('\0')


	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		hive,
		path,
		0,
		KEY_READ,
		&hkey
	);

	if ( ret == ERROR_SUCCESS )
	{

		// [!] : ERROR_SUCCESS will be returned when "lval" is NULL

		if ( lval == NULL )
		{
			ret = ERROR_FILE_NOT_FOUND;
		} else {
			ret = RegQueryValueEx( hkey, lval, NULL, NULL, (void*) rval, &byte );
		}

	}

	RegCloseKey( hkey );


	return ret;
}

#define n_win64_registry_write_literal( a,b,c,d,e,f ) \
        n_win64_registry_write( a, n_posix_literal( b ), n_posix_literal( c ), d, e, f )

DWORD
n_win64_registry_write
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval,
	      DWORD         type,
	const void         *rval,
	      DWORD         byte
)
{

	HKEY  hkey;
	DWORD dw;
	DWORD ret = RegCreateKeyEx
	(
		hive,
		path,
		0, NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_WRITE,
		NULL,
		&hkey,
		&dw
	);

	if ( ret == ERROR_SUCCESS )
	{

		// [!] : ERROR_SUCCESS will be returned when "lval" is NULL

		if ( lval == NULL )
		{

			ret = ERROR_FILE_NOT_FOUND;

		} else {

			if ( type == REG_SZ    )
			{
				if ( rval == NULL )
				{
					byte = 0;
				} else {
					byte = (DWORD) n_posix_strlen( rval ) * sizeof( n_posix_char );
				}
			} else
			if ( type == REG_DWORD )
			{
				byte = sizeof( DWORD );
			}


			// [Needed] : in Win95

			RegDeleteValue( hkey, lval );


			// [!] : Win95 : error when "rval" is NULL

			ret = RegSetValueEx( hkey, lval, 0, type, rval, byte );

		}

	}

	RegCloseKey( hkey );


	return ret;
}

DWORD
n_win64_registry_delete_value
(
	      HKEY          hkey,
	const n_posix_char *path,
	const n_posix_char *lval
)
{

	HKEY  hkey_child;
	DWORD ret = RegOpenKeyEx
	(
		hkey,
		path,
		0,
		KEY_WRITE,
		&hkey_child
	);

	if ( ret != ERROR_SUCCESS ) { return ERROR_BADKEY; }

	ret = RegDeleteValue( hkey_child, lval );
//n_posix_debug_literal( " %d ", (int)ret );

	RegCloseKey( hkey_child );


	return ret;
}

#define n_win64_registry_delete_literal( a, b ) \
        n_win64_registry_delete( a, n_posix_literal( b ) )

DWORD
n_win64_registry_delete
(
	      HKEY          hkey,
	const n_posix_char *path
)
{

	HKEY  hkey_child;
	DWORD ret = RegOpenKeyEx
	(
		hkey,
		path,
		0,
		KEY_ENUMERATE_SUB_KEYS | DELETE,
		&hkey_child
	);

	if ( ret != ERROR_SUCCESS ) { return ERROR_BADKEY; }


	DWORD index = 0;
	n_posix_loop
	{

		n_posix_char path_child[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

		DWORD byte = N_REGISTRY_ASSOCIATION_CCH_MAX * sizeof( n_posix_char );
		ret = RegEnumKeyEx
		(
			hkey_child,
			index,
			path_child,
			&byte,
			NULL,
			NULL,
			NULL,
			NULL
		);


		if ( ret == ERROR_NO_MORE_ITEMS )
		{

			ret = RegDeleteKey( hkey, path );

			break;

		} else
		if( ret == ERROR_SUCCESS )
		{
//n_posix_debug( path );

			ret = n_win64_registry_delete( hkey_child, path_child );

		}


		// comment-out for debug recursive enumeration

		//index++;

	}


	RegCloseKey( hkey_child );


	return ret;
}


#endif // _H_NONNON_WIN64_REGISTRY

