// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_WINDOW
#define _H_NONNON_WIN64_WINDOW




#include <shellapi.h>


#include "../sysinfo/version.c"


#include "../_windows.c"
#include "../mutex.c"




#define N_WIN64_UI_WINDOW_FIXED ( WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX )




HWND
n_win64_ui_window( HWND hwnd_parent, WNDPROC func )
{

	const HINSTANCE hinst = GetModuleHandle( NULL );

	n_posix_char  str[ 256 ]; n_string_zero( str, 256 );
	n_posix_char  ico[ 256 ]; n_string_zero( ico, 256 );

	HWND  hwnd    = NULL;
	WORD  atom    = 0;
	DWORD style   = WS_CLIPCHILDREN | WS_CLIPSIBLINGS | N_WIN64_UI_WINDOW_FIXED;
	DWORD exstyle = 0;


	{

		WNDCLASSEX wc;


		ZeroMemory( &wc, sizeof( WNDCLASSEX ) );

		wc.cbSize      = sizeof( WNDCLASSEX );
		wc.style       = CS_DBLCLKS;
		wc.lpfnWndProc = func;
		wc.hInstance   = hinst;

		int i = 0;
		n_posix_loop
		{

			n_posix_sprintf_literal( str, "window #%d", i );

			UnregisterClass( str, hinst );

			wc.lpszClassName = str;

			atom = RegisterClassEx( &wc );

			if ( atom != 0 ) { break; }


			i++;
			if ( i >= SHRT_MAX ) { return NULL; }
 		}

	}


	hwnd = CreateWindowEx
	(
		exstyle,
		str,
		N_STRING_EMPTY,
		style,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);


	DragAcceptFiles( hwnd, TRUE );


	return hwnd;
}




#define n_win64_ui_window_init_literal( h,t,i,c ) n_win64_ui_window_init( h, n_posix_literal( t ), n_posix_literal( i ), n_posix_literal( c ) )

void
n_win64_ui_window_init
(
	              HWND  hwnd,
	const n_posix_char *title,
	const n_posix_char *rc_ico,
	const n_posix_char *rc_cur
)
{

	// [!] : if loading from resources, HINSTANCE is needed

	const HINSTANCE hinst = GetModuleHandle( NULL );


	HICON   hi;
	HCURSOR hc;


	SetWindowText( hwnd, title );


	hi = LoadIcon( hinst, rc_ico );


	if ( (DWORD_PTR) rc_cur <= SHRT_MAX )
	{

		// [!] : IDC_*

		hc = LoadCursor( NULL, rc_cur );

	} else
	if ( n_string_is_empty( rc_cur ) )
	{

		hc = LoadCursor( NULL, IDC_ARROW );

	} else {

		// [x] : Win9x : cursor flickers without LR_MONOCHROME

		hc = LoadImage
		(
			hinst,
			rc_cur,
			IMAGE_CURSOR,
			0,0, LR_VGACOLOR | LR_MONOCHROME
		);

	}


	// [!] : this is not "COLOR_BACKGROUND"

	// [MSDN] : don't use GetSysColorBrush( COLOR_BTNFACE );

	HBRUSH hb = (HBRUSH) ( COLOR_BTNFACE + 1 );


	SetClassLongPtr( hwnd, GCLP_HICON        , (LONG_PTR) hi );
	SetClassLongPtr( hwnd, GCLP_HCURSOR      , (LONG_PTR) hc );
	SetClassLongPtr( hwnd, GCLP_HBRBACKGROUND, (LONG_PTR) hb );


	return;
}




// internal
MSG
n_win64_msgloop( HWND hwnd )
{

	MSG msg; ZeroMemory( &msg, sizeof( MSG ) );

	while( 1 <= GetMessage( &msg, NULL, 0, 0 ) )
	{
		if ( msg.hwnd == hwnd )
		{
/*
			if ( msg.message == WM_CREATE )
			{
//n_posix_debug_literal( "WM_CREATE" );
				// [!] : never come
			} else
			if ( msg.message == WM_CLOSE )
			{
//n_posix_debug_literal( "WM_CLOSE" );
				// [!] : never come
			}// else
*/

		} else {

			if ( msg.message == WM_DROPFILES )
			{

				// [!] : for Windows95 without IE4

				msg.hwnd = hwnd;

			} else
			if (
				( msg.message >= WM_KEYFIRST )
				&&
				( msg.message <= WM_KEYLAST  )
			)
			{

				// [!] : keyboard input event redirector

				n_win64_message_send( hwnd, msg.message, msg.wParam, msg.lParam );

			}// else

		}


		TranslateMessage( &msg );
		DispatchMessage ( &msg );
	}


	return msg;
}

#define n_win64_ui_window_main_literal( a, b ) n_win64_ui_window_main( n_posix_literal( a ), b )

int
n_win64_ui_window_main( const n_posix_char *mutex, void *wndproc )
{

	HANDLE hmutex = NULL;

	if ( mutex != NULL )
	{
		hmutex = n_win64_mutex_init( hmutex, mutex );
		if ( hmutex == NULL ) { return 0; }
	}


	//n_win_dpi_autoscale_disable();


	HWND hwnd = n_win64_ui_window( NULL, wndproc );
	if ( hwnd == NULL ) { return 0; }


	WPARAM wparam = n_win64_msgloop( hwnd ).wParam;


	if ( mutex != NULL )
	{
		hmutex = n_win64_mutex_exit( hmutex );
	}


	n_memory_debug_refcount();


	return (int) wparam;
}




void
n_win64_ui_window_set( HWND hwnd, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, BOOL centering )
{

	if ( centering )
	{
		n_type_gfx desktop_sx = GetSystemMetrics( SM_CXMAXIMIZED );
		n_type_gfx desktop_sy = GetSystemMetrics( SM_CYMAXIMIZED );

		x = ( desktop_sx / 2 ) - ( sx / 2 );
		y = ( desktop_sy / 2 ) - ( sy / 2 );
	}

/*
	// [x] : not working
	DWORD style = GetWindowLong( hwnd, GWL_STYLE   );
	DWORD exstl = GetWindowLong( hwnd, GWL_EXSTYLE );

	RECT rect = { 0,0, sx, sy };
	AdjustWindowRectEx( &rect, style, FALSE, exstl );

	sx = rect.right;
	sy = rect.bottom;
*/

	MoveWindow( hwnd, 0,0, 100,100, FALSE );

	RECT w; GetWindowRect( hwnd, &w );
	RECT c; GetClientRect( hwnd, &c );

	sx += abs( w.right  - c.right  );
	sy += abs( w.bottom - c.bottom );


	UINT swp = SWP_NOACTIVATE | SWP_DRAWFRAME;

	SetWindowPos( hwnd, NULL, x,y, sx,sy, swp );


	return;
}


#endif // _H_NONNON_WIN64_WINDOW

