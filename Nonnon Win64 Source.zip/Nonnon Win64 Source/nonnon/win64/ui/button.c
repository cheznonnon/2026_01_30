// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_BUTTON
#define _H_NONNON_WIN64_UI_BUTTON




#include <commctrl.h>




#include "../../neutral/bmp/all.c"


#include "../_windows.c"
#include "../doublebuffer.c"

#include "../resource.c"
#include "../../bridge/gdi.c"





typedef struct {

	// [!] : internal

	HWND       hwnd;

	n_posix_char *label;
	n_posix_char *resource_name;

	n_bmp_fade fade;
	BOOL       fade_onoff;
	UINT       fade_timer_id;
	BOOL       fade_queue;

	BOOL         hot_onoff;
	BOOL       press_onoff;
	BOOL        gray_onoff;
	BOOL        fake_onoff;

} n_win64_ui_button;


#define n_win64_ui_button_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_button ) )




void
n_win64_ui_button_fade_go( n_win64_ui_button *p )
{

	u32 color;
	if ( p->fade.color_fg == n_bmp_white )
	{
		color = n_bmp_black;
	} else {
		color = n_bmp_white;
	}

	p->fade.stop = TRUE;

	n_bmp_fade_go( &p->fade, color );

	p->fade_queue = TRUE;


	return;
}




void
n_win64_ui_button_move( n_win64_ui_button *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, BOOL redraw )
{

	MoveWindow( p->hwnd, x,y,sx,sy, redraw );

	return;
}




void
n_win64_ui_button_gdi( n_win64_ui_button *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 bg, int label_color, int frame )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = bg;
	gdi.base_color_fg       = n_bmp_white_invisible;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = frame;
	gdi.frame_round         = 0;

	gdi.text                = p->label;
	gdi.text_font           = n_posix_literal( "Trebuchet MS" );
	//gdi.text_font           = n_posix_literal( "Arial" );
	gdi.text_size           = 16;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = label_color;

	gdi.icon                = p->resource_name;

	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_win64_ui_button_draw( n_win64_ui_button *p )
{

	RECT rect; GetClientRect( p->hwnd, &rect );

	n_type_gfx sx,sy; n_win64_rect_expand_size( &rect, NULL, NULL, &sx, &sy );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), "%d %d", sx, sy );


	n_win64_doublebuffer_simple_init( p->hwnd, sx,sy );


	// [!] : Metrics

	n_type_gfx scale       = 1;
	n_type_gfx offset_sink = scale;


	// Main

	n_bmp *bmp = &n_win64_doublebuffer_instance.bmp;
//n_bmp_box( bmp, 0,0,sx,sy, n_bmp_rgb( 0,200,255 ) );


	u32 lb, bg;
	if ( p->fake_onoff )
	{
		bg = n_bmp_rgb( 200,200,200 );
		lb = n_bmp_black;
	} else
	if ( p->hot_onoff )
	{
		bg = n_bmp_rgb( 255,255,255 );
		lb = n_bmp_black;
	} else
	if ( p->press_onoff )
	{
		bg = n_bmp_rgb( 200,200,200 );
		lb = n_bmp_black;
	} else {
		bg = n_bmp_rgb( 222,222,222 );
		lb = n_bmp_black;
	}


	int frame;
	if ( p->fake_onoff )
	{
		frame = N_GDI_FRAME_PUSH;
	} else
	if ( p->press_onoff )
	{
		frame = N_GDI_FRAME_PUSH;
	} else {
		frame = N_GDI_FRAME_BUTTON;
	}


	n_bmp icon; n_bmp_zero( &icon );
	n_win64_ui_button_gdi( p, &icon, sx, sy, bg, lb, frame );

	{
		n_type_gfx bmpsx = N_BMP_SX( &icon );
		n_type_gfx bmpsy = N_BMP_SY( &icon );

		n_type_gfx x = ( sx / 2 ) - ( bmpsx / 2 );
		n_type_gfx y = ( sy / 2 ) - ( bmpsy / 2 );

		if ( p->press_onoff )
		{
			x += offset_sink;
			y += offset_sink;
		}

		n_bmp_transcopy( &icon, bmp, 0,0,bmpsx,bmpsy, x,y );
	}

	n_bmp_free_fast( &icon );


	// Done!

	n_win64_doublebuffer_simple_exit();


	return;
}




// internal
LRESULT CALLBACK
n_win64_ui_button_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_button *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_MOUSEMOVE :

		// [!] : this code depends on SetCapture()/ReleaseCapture()

		n_win64_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :

		if ( p->hot_onoff == FALSE )
		{
			p->hot_onoff = TRUE;
			n_win64_refresh( p->hwnd, FALSE );
		}

	break;

	case WM_MOUSELEAVE :

		if ( p->hot_onoff != FALSE )
		{
			p->hot_onoff = FALSE;
			n_win64_refresh( p->hwnd, FALSE );
		}

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN :
//n_posix_debug_literal( "!" );

		SetCapture( p->hwnd );

		p->  hot_onoff = FALSE;
		p->press_onoff = TRUE;

		n_win64_refresh( p->hwnd, FALSE );

	break;

	case WM_LBUTTONUP :
//n_posix_debug_literal( "!" );

		ReleaseCapture();

		p->  hot_onoff = TRUE;
		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

		n_win64_message_send( GetParent( p->hwnd ), WM_COMMAND, 0, p->hwnd );

	break;


	case WM_RBUTTONDOWN :

	break;

	case WM_RBUTTONUP :

	break;

	} // switch


	return DefSubclassProc( hwnd, msg, wparam, lparam );
}




void
n_win64_ui_button_init( n_win64_ui_button *p, HWND hwnd_parent )
{

	n_win64_ui_button_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_button_subclass, 0, (DWORD_PTR) p );


	p->fade_timer_id = n_win64_timer_id_get();
	n_win64_timer_init( p->hwnd, p->fade_timer_id, 100 );


	return;
}

void
n_win64_ui_button_exit( n_win64_ui_button *p )
{

	n_win64_timer_exit( p->hwnd, p->fade_timer_id );

	DestroyWindow( p->hwnd );

	n_win64_ui_button_zero( p );


	return;
}




void
n_win64_ui_button_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_button *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }

		n_win64_ui_button_draw( p );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN64_UI_BUTTON


